/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

// Load environment configuration
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google Gen AI securely on the server-side
let ai: GoogleGenAI | null = null;
const apiKey = process.env.GEMINI_API_KEY;

if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI client:", error);
  }
} else {
  console.warn("GEMINI_API_KEY is not configured or contains placeholder value. AI features will run in educational sandbox mode.");
}

// ----------------------------------------------------
// 1. Secured server-side API endpoints for AI Assistant
// ----------------------------------------------------
app.post('/api/gemini/chat', async (req, res) => {
  const { messages, userProfile } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid messages body payload" });
  }

  // Fallback responses if the API key is not yet configured by the user in Settings > Secrets
  if (!ai) {
    const lastMsg = messages[messages.length - 1]?.text || "";
    return res.json({
      reply: `[PCM Plus Academy AI Assistant - Demo Mode]\n\nHello! I am your AI Study Assistant. Sushil Sir's PCM Plus Academy live AI features require your Google Gemini API Key. \nTo activate this feature, go to **Settings > Secrets** in your AI Studio dashboard and add the variable \`GEMINI_API_KEY\`.\n\n*Simulated answer for*: "${lastMsg.substring(0, 60)}${lastMsg.length > 60 ? '...' : ''}" \nTo study successfully, focus on conceptual clarity, solve previous years' papers, and practice daily MCQ mocks in the "Test Series" tab!`
    });
  }

  try {
    // Format conversation history for Gemini
    const contents = messages.map((m: any) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }]
    }));

    const studentInfo = userProfile 
      ? `Student Name: ${userProfile.name}, Goal: ${userProfile.goal || 'General Competitive Exams'}` 
      : 'Guest Student';

    const systemInstruction = `You are "Sushil Pandey Sir's PCM Plus Academy AI Study Assistant".
Your primary goal is to provide high-quality, encouraging, and accurate educational guidance to students preparing for Class 6-12, JEE, NEET, UPSC, SSC, Banking, Railways, and Computer Courses (Python, AI, Basic Computer, etc.).
Adapt your style to be a knowledgeable mentor (like Sushil Sir). Use Hindi, English, or simple Hinglish based on the student's question language, making complex academic concepts easy to grasp.
When appropriate, structure your guidance with bullet points, brief code snippets (for computer terms), or formatted scientific derivations using simple markdown. Keep responses concise, clear, and focused on helping students study successfully.
Current User Context: ${studentInfo}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    const replyText = response.text || "I apologize, but I am unable to generate a response at this moment. Let's try studying another topic!";
    res.json({ reply: replyText });

  } catch (error: any) {
    console.error("Error communicating with Gemini API:", error);
    res.status(500).json({ 
      error: "AI Model Execution failed",
      message: error instanceof Error ? error.message : String(error)
    });
  }
});

// ----------------------------------------------------
// 2. Front-end bundle & development environment integration
// ----------------------------------------------------
async function bootServer() {
  if (process.env.NODE_ENV !== 'production') {
    // Register Vite development server middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log("Vite development middleware mounted successfully.");
  } else {
    // Serve static built web bundle assets
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log("Production static server route registered.");
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PCM Plus Academy server running on port ${PORT}`);
  });
}

bootServer();
