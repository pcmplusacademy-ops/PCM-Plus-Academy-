/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Course, StudyNote, MCQTest, CurrentAffairsBulletin, BlogArticle } from './types';

// Pre-seeded, premium educational course options
export const SEED_COURSES: Course[] = [
  {
    id: 'jee_phys_electrostatics',
    title: 'JEE Main & Advanced: Electrostatics (स्थिरवैद्युतिकी)',
    description: 'Master electric forces, fields, Gauss law, potential, and capacitance. Highly optimized for JEE 2026.',
    subject: 'Physics',
    examType: 'JEE',
    classLevel: 'Class 12',
    bannerUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80&w=600',
    createdAt: '2026-06-15T12:00:00Z',
    lectures: [
      { id: 'l1', title: 'L1: Coulombs Law and Superposition Principle', duration: '45 mins', youtubeId: 'gZ_7_8vI3f0' },
      { id: 'l2', title: 'L2: Electric Field Intensity & Dipoles', duration: '50 mins', youtubeId: 'f9XvXG-9yW8' },
      { id: 'l3', title: 'L3: Gauss Law Applications in Sphere & Cylinders', duration: '55 mins', youtubeId: '2qY-0hshw7Q' }
    ]
  },
  {
    id: 'neet_bio_genetics',
    title: 'NEET: Principles of Inheritance and Variation (वंशानुगति के सिद्धांत)',
    description: 'Complete Mendelism, chromosomal disorders, pedigree charts, and molecular genetics with 3D diagram references.',
    subject: 'Biology',
    examType: 'NEET',
    classLevel: 'Class 12',
    bannerUrl: 'https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?auto=format&fit=crop&q=80&w=600',
    createdAt: '2026-06-14T12:00:00Z',
    lectures: [
      { id: 'l4', title: 'L1: Mendel Laws of Monohybrid and Dihybrid Cross', duration: '35 mins', youtubeId: 'bC7aZ8p1hUo' },
      { id: 'l5', title: 'L2: Sex Determination & Chromosomal Non-Disjunction', duration: '40 mins', youtubeId: 'pS-WbUjXpEs' }
    ]
  },
  {
    id: 'upsc_history_optional',
    title: 'UPSC IAS: Ancient India & Answer Writing Strategies',
    description: 'Detailed analysis of Mauryan polity, Indus Valley, and daily answer evaluation criteria for History Optional.',
    subject: 'History',
    examType: 'UPSC',
    bannerUrl: 'https://images.unsplash.com/photo-1461360370896-922624d12aa1?auto=format&fit=crop&q=80&w=600',
    createdAt: '2026-06-12T12:00:00Z',
    lectures: [
      { id: 'l6', title: 'Mauryan Administration and Ashoka Dhamma', duration: '60 mins', youtubeId: 'L-bH29W68W8' },
      { id: 'l7', title: 'Gupta Golden Age: Myth vs Reality', duration: '55 mins', youtubeId: 'T8XG19_ePZk' }
    ]
  },
  {
    id: 'computer_prompt_eng',
    title: 'Computer: Artificial Intelligence & Prompt Engineering',
    description: 'Learn the fundamentals of LLMs, designing professional prompts, system instruction building, and AI Web Dev.',
    subject: 'Computer Knowledge',
    examType: 'Computer Courses',
    bannerUrl: 'https://images.unsplash.com/photo-1677442136019-21780efad99a?auto=format&fit=crop&q=80&w=600',
    createdAt: '2026-06-11T12:00:00Z',
    lectures: [
      { id: 'l8', title: 'Introduction to Prompt Engineering & LLM architectures', duration: '50 mins', youtubeId: '5gK3K_5uD-0' },
      { id: 'l9', title: 'Writing Systems, Few-shot Prompts, and Chain-of-Thought', duration: '45 mins', youtubeId: 'v8JtG6a4Z2s' }
    ]
  },
  {
    id: 'ssc_cgl_reasoning',
    title: 'SSC CGL: Coding-Decoding & Critical Reasoning',
    description: 'Crack SSC logical reasoning including Syllogisms, Analogy, Matrix, and shortcut analytical logic tools.',
    subject: 'Reasoning',
    examType: 'SSC',
    bannerUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=600',
    createdAt: '2026-06-10T12:00:00Z',
    lectures: [
      { id: 'l10', title: 'Shortcuts for Blood Relations & Syllogism Problems', duration: '40 mins', youtubeId: 'W3_W3p61U8c' }
    ]
  }
];

// Pre-seeded premium study notes with markdown contents and simulated download PDFs
export const SEED_NOTES: StudyNote[] = [
  {
    id: 'pn1',
    title: 'Electric Flux & Gauss Law Handout (वैद्युत फ्लक्स और गॉस का नियम)',
    subject: 'Physics',
    category: 'Class 12',
    chapter: 'Electrostatics',
    contentMarkdown: `### Electrostatics: Electric Flux and Gauss Law (स्थिरवैद्युतिकी: गॉस का नियम)

#### 1. Electric Flux (वैद्युत फ्लक्स - $\\Phi_E$)
Electric flux measures the flow of electric field lines passing orthogonally through a specific area.
* Formula: $\\Phi_E = \\int \\mathbf{E} \\cdot d\\mathbf{A} = E A \\cos(\\theta)$
* SI Unit: $\\text{N} \\cdot \\text{m}^2/\\text{C}$

#### 2. Gauss's Law Statement (गॉस का नियम)
> The total electric flux through any closed, hypothetical surface (referred to as a Gaussian Surface) is exactly $1/\\varepsilon_0$ times the total net algebraic sum of electric charges enclosed within that dry boundary.

$$\\oint \\mathbf{E} \\cdot d\\mathbf{A} = \\frac{q_{\\text{encl}}}{\\varepsilon_0}$$

Where:
* $\\varepsilon_0$ = Permittivity of Free Space = $8.854 \\times 10^{-12} \\text{ C}^2/(\\text{N}\\cdot\\text{m}^2)$

#### 3. Core Applications (प्रमुख अनुप्रयोग)
1. **Infinitely Long Straight Wire**: Electric line field at distance $r$ is:
   $$E = \\frac{\\lambda}{2\\pi \\varepsilon_0 r}$$ (where $\\lambda$ is linear charge density).
2. **Infinite Thin Plane Sheet**: Electric field is uniform and constant:
   $$E = \\frac{\\sigma}{2 \\varepsilon_0}$$ (where $\\sigma$ is surface charge density).
3. **Thin Spherical Shell**:
   * *Outside ($r > R$)*: Acts as point charge: $E = \\frac{q}{4\\pi\\varepsilon_0 r^2}$
   * *Inside ($r < R$)*: Net enclosed charge is absolute zero: $E = 0$

---
*Created by Sushil Pandey. Feel free to download the fully formatted PDF handout above.*`,
    pdfUrl: 'https://arxiv.org/pdf/cond-mat/0101001.pdf', // Placeholder stable academic pdf link
    viewsCount: 1420
  },
  {
    id: 'pn2',
    title: 'Chemical Bonding: VSEPR Theory and Molecular Hybridization',
    subject: 'Chemistry',
    category: 'Class 11',
    chapter: 'Chemical Bonding',
    contentMarkdown: `### Valence Shell Electron Pair Repulsion (VSEPR) Theory (संयोजकता कोश इलेक्ट्रॉन युग्म प्रतिकर्षण सिद्धांत)

Presented by PCM Plus Academy to analyze geometry of covalent molecules.

#### Key Principles:
1. The structural layout of a molecule depends purely upon the total electron pairs (both bonding and non-bonding coordinate pairs) centered around the focal heavy atom.
2. Order of repulsive forces:
   $$\\text{Lone Pair - Lone Pair (lp-lp)} > \\text{Lone Pair - Bond Pair (lp-bp)} > \\text{Bond Pair - Bond Pair (bp-bp)}$$
3. These repulsion forces pull molecules into specialized configurations to minimize electrostatic stress.

#### Carbon Hybridization Schemes:
* **$sp^3$ Hybridization**: 4 hybrid fields. Geometry: **Tetrahedral** ($\approx 109.5^\\circ$). Example: $CH_4$.
* **$sp^2$ Hybridization**: 3 planar fields. Geometry: **Trigonal Planar** ($120^\\circ$). Example: $C_2H_4$.
* **$sp$ Hybridization**: 2 linear fields. Geometry: **Linear** ($180^\\circ$). Example: $C_2H_2$.`,
    pdfUrl: 'https://arxiv.org/pdf/hep-th/9711200.pdf',
    viewsCount: 980
  },
  {
    id: 'pn3',
    title: 'UPSC IAS History: Indus Valley Civilisation Architectural Marvels',
    subject: 'History',
    category: 'UPSC',
    chapter: 'Ancient India',
    contentMarkdown: `### Harappan Civilisation Urban Dynamics & Town Planning

A crucial guide for Mains General Studies paper and History Optional.

1. **Grid System**: Cities like Harappa and Mohenjo-Daro layout split in rectangular grids.
2. **Citadel vs Lower Town**:
   * **Citadel**: Placed on western platform, hosted granaries, great bath, administrative quarters.
   * **Lower Town**: Eastern habitation, constructed of standardized kiln-baked bricks.
3. **Advanced Underfloor Drainage**: Every house featured drainage tiles communicating into central masonry conduits underneath main streets, guarded by manhole covers.
4. **Dockyard at Lothal**: Solid proof of maritime foreign business with Mesopotamian ports.`,
    pdfUrl: 'https://arxiv.org/pdf/math/0311201.pdf',
    viewsCount: 2350
  },
  {
    id: 'pn4',
    title: 'Computer: MS Excel Formulas and Advanced Data Analytics',
    subject: 'Computer Knowledge',
    category: 'Computer Courses',
    chapter: 'MS Excel',
    contentMarkdown: `### Master MS Excel Essential Formula Sheet & VBA Introduction

Syllabus checklist for Professional Basic Computer Skills.

#### 1. Lookup Formulas
* **VLOOKUP**: \`=VLOOKUP(lookup_value, table_array, col_index_num, [range_lookup])\`
* **XLOOKUP** (Modern standard): \`=XLOOKUP(lookup_value, lookup_array, return_array)\`

#### 2. Logical Functions
* \`=IF(AND(A2>50, B2="Conf"), "Pass", "Check")\`
* \`=SUMIFS(sum_range, criteria_range1, criteria1, ...)\`

#### 3. Data Cleansing
* \`=TRIM(text)\`: Strips redundant trailing/leading space lines.
* \`=PROPER(text)\`: Capitalizes words correctly.`,
    pdfUrl: 'https://arxiv.org/pdf/quant-ph/0402100.pdf',
    viewsCount: 1780
  }
];

// Interactive mock assessment catalogs for Online Test Series
export const SEED_TESTS: MCQTest[] = [
  {
    id: 'test_jee_phys_1',
    title: 'JEE Electromagnetism & Field Theory - Practice Test 1',
    subject: 'Physics',
    category: 'JEE',
    durationMinutes: 10,
    questions: [
      {
        id: 'jq1',
        question: 'An electric dipole of dipole moment p is aligned parallel to a uniform electric field E. What is the work done to rotate the dipole by 180 degrees?',
        options: ['pE', '2pE', 'Zero', '-2pE'],
        correctIndex: 1,
        explanation: 'Work done W = U_final - U_initial = -pE cos(180) - (-pE cos(0)) = pE + pE = 2pE.'
      },
      {
        id: 'jq2',
        question: 'Two infinite parallel sheets have uniform surface charge densities +σ and -σ. What is the electric field inside the region between the sheets?',
        options: ['Zero', 'σ / ε0', 'σ / (2ε0)', '2σ / ε0'],
        correctIndex: 1,
        explanation: 'The electric field because of a single sheet is σ/(2ε0). In between the plate fields point in the same direction, so they add up: E = σ/(2ε0) + σ/(2ε0) = σ / ε0.'
      },
      {
        id: 'jq3',
        question: 'If a dielectric slab of dielectric constant K is inserted between the plates of a charged disconnected capacitor, the electric field will:',
        options: ['Increase by K times', 'Decrease by K times', 'Remain constant', 'Become zero'],
        correctIndex: 1,
        explanation: 'A disconnected capacitor has constant charge Q. When a dielectric is added, capacitance increases to KC. Potential decreases V = Q/C, and since E = V/d, the electric field decreases to E/K.'
      }
    ]
  },
  {
    id: 'test_neet_bio_1',
    title: 'NEET Mendelism & Chromosomes Genetics Quiz',
    subject: 'Biology',
    category: 'NEET',
    durationMinutes: 10,
    questions: [
      {
        id: 'nq1',
        question: 'Which of the following is an example of co-dominance in humans?',
        options: ['Skin Color', 'ABO Blood Grouping', 'Attached Earlobes', 'Hemophilia'],
        correctIndex: 1,
        explanation: 'In the ABO system, IA and IB alleles are both fully expressed in an IAIB individual, constituting a classical demonstration of co-dominance.'
      },
      {
        id: 'nq2',
        question: 'How many pairs of contrasting traits in pea plants were chosen by Gregor Mendel during his hybridization studies?',
        options: ['5', '7', '14', '12'],
        correctIndex: 1,
        explanation: 'Gregor Mendel carefully selected 7 distinct pairs of contrasting traits (for example: stem size, seed color, etc.) in Pisum Sativum.'
      }
    ]
  },
  {
    id: 'test_upsc_polity_1',
    title: 'UPSC Civil Services Prelims Mock: Polity & Constitution',
    subject: 'Polity',
    category: 'UPSC',
    durationMinutes: 15,
    questions: [
      {
        id: 'uq1',
        question: 'Under which Article of the Indian Constitution is the President of India empowered to proclaim a State Emergency (President’s Rule)?',
        options: ['Article 352', 'Article 356', 'Article 360', 'Article 368'],
        correctIndex: 1,
        explanation: 'Article 356 deals with the failure of constitutional machinery in a State, enabling India’s President to declare President’s Rule there.'
      },
      {
        id: 'uq2',
        question: 'Which constitutional amendment added the tier of Panchayats and Rural Municipal bodies into India’s governance?',
        options: ['42nd Amendment', '44th Amendment', '73rd Amendment', '86th Amendment'],
        correctIndex: 2,
        explanation: 'The 73rd Constitutional Amendment Act, 1992 endowed constitutional status to decentralized Panchayati Raj institutions.'
      }
    ]
  },
  {
    id: 'test_comp_js_1',
    title: 'Computer Knowledge: JavaScript & Web Dev Basics',
    subject: 'Computer Knowledge',
    category: 'Computer Courses',
    durationMinutes: 5,
    questions: [
      {
        id: 'cq1',
        question: 'Which keyword can be used to declare block-scoped variables in modern JavaScript (ES6+)?',
        options: ['var', 'let', 'define', 'global'],
        correctIndex: 1,
        explanation: '"let" and "const" allow developers to enforce pristine lexical/block scoping patterns, whereas "var" is function-scoped.'
      }
    ]
  }
];

// Pre-seeded, dynamic Current Affairs Bulletins
export const SEED_CURRENT_AFFAIRS: CurrentAffairsBulletin[] = [
  {
    id: 'ca1',
    title: 'Major Breakthrough: ISRO Successfully Deploys GSLV-MK3 Communications Satellite',
    content: `The Indian Space Research Organisation (ISRO) successfully launched its heavy-lift GSLV-MK3 vehicle today, placing G-SAT communications payload into Geostationary Transfer Orbit. This bolsters high-speed satellite broadband access in remote Himalayan and North-Eastern domains, paving the way for advanced telemedicine & online digital education channels.`,
    type: 'daily',
    publishedAt: '2026-06-16'
  },
  {
    id: 'ca2',
    title: 'Weekly National Economic Indicators Study & GST Revisions',
    content: `GST council declares lowering of tax slabs for essential digital educational portals and science equipment, decreasing the rate to 5%. GST collections for the last quarter hovered above ₹1.78 Lakh Crores, signaling stable domestic consumption loops. This is a crucial data point for UPSC Mains GS Paper-3 preparation.`,
    type: 'weekly',
    publishedAt: '2026-06-13'
  },
  {
    id: 'ca3',
    title: 'Monthly Global Multilateral Summit Roundup (G20 Coordination Draft)',
    content: `A complete compilation of strategic outcomes from the bilateral Climate Financing frameworks. Evaluates national timelines for Net Zero Carbon outputs, green hydrogen corridors, and clean solar grids. Essential reference documentation for competitive test aspirants studying International Relations.`,
    type: 'monthly',
    publishedAt: '2026-06-01'
  }
];

// Elite educational strategies and career blogs by Sushil Sir
export const SEED_BLOGS: BlogArticle[] = [
  {
    id: 'b1',
    title: 'How to Crack JEE Advanced Physics: Sushil Sir’s Ultimate Roadmap',
    contentMarkdown: `### Master JEE Advanced Physics: Conceptual Approach vs Cramming

Many students spend years solving complex numerical calculations without spending enough time building solid conceptual mental maps. Here's a 3-step solution to crack Advanced Physics:

#### 1. Prioritize Basic Intuition first
Before memorizing a formula like $v = u + at$, visualize why the rate of speed changes uniformly. Derive each electrostatic field formula using simple Gauss flux tubes. Understanding standard derivations of mathematical formulas is key.

#### 2. Pick High-Yield Chapters Strategy
Analyze weightage trends across previous years' JEE question papers:
* **Electrostatics & Electromagnetism**: 30% of standard tests.
* **Rotational Dynamics & Mechanics**: High conceptual overlap.
* **Modern Physics & Semiconductors**: High reward, direct formulas.

#### 3. Error Log Management
Maintain an active notebooks directory of failures. Every time you solve an MCQ wrong, record the concept gap in your notebook registry. Do not repeat the same class of faults twice!

*"Success is the sum of small effort cycles repeated day in and day out!"*`,
    authorName: 'Sushil Pandey',
    category: 'Exam Strategy',
    createdAt: '2026-06-15T09:00:00Z'
  },
  {
    id: 'b2',
    title: 'Pristine UPSC Mains Answer Structure: Secrets of Top Rent-Holders',
    contentMarkdown: `### The UPSC Mains Answer Writing Blueprint

An expert breakdown of scoring rules in General Studies and Optional answer templates.

#### 1. Introduction (10% of total length)
State the constitutional article, historical setting, or statistical status right away as soon as you begin the answer.
* For example, on a question on Cooperative Federalism, quote Article 263 (Inter-State Council) directly in your introduction.

#### 2. Core Body Breakdown (75%)
* Bulletize points using clear subheaders (e.g. Political impact, Fiscal strains).
* Include map sketches or schematic flowchart channels.
* Quote authentic Government reports (Sarkaria Commission, ARC recommendations).

#### 3. Optimistic Conclusion (15%)
End on a highly forward-looking, positive solution in conformity with the Indian Constitution's Directive Principles.`,
    authorName: 'Sushil Pandey',
    category: 'Career Guidance',
    createdAt: '2026-06-14T09:00:00Z'
  }
];
