/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { UserProfile, TestResult } from './types';
import AuthModule from './components/AuthModule';
import CourseDirectory from './components/CourseDirectory';
import NotesViewer from './components/NotesViewer';
import TestEngine from './components/TestEngine';
import CurrentAffairsSection from './components/CurrentAffairsSection';
import BlogSystem from './components/BlogSystem';
import StudentDashboard from './components/StudentDashboard';
import AdminDashboard from './components/AdminDashboard';
import AiAssistant from './components/AiAssistant';
import ComputerSkillsSection from './components/ComputerSkillsSection';
import { SEED_COURSES, SEED_NOTES, SEED_BLOGS } from './data';
import { firebaseService } from './firebaseService';
import { 
  Menu, X, Sun, Moon, GraduationCap, Home, BookOpen, FileText, Award, 
  Newspaper, HelpCircle, Phone, AwardIcon, Sparkles, Send, Download, Mail, MapPin, 
  CheckCircle, Globe, ChevronRight, MessageSquare, ShieldAlert, Star, Search,
  Youtube, Facebook, Twitter, Instagram, Linkedin
} from 'lucide-react';

export default function App() {
  // Global search bar state variables
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [searchTargetCourseId, setSearchTargetCourseId] = useState<string | null>(null);
  const [searchTargetNoteId, setSearchTargetNoteId] = useState<string | null>(null);
  const [searchTargetBlogId, setSearchTargetBlogId] = useState<string | null>(null);

  // Responsive navigation helpers
  const navigateToCourse = (courseId: string) => {
    setSearchTargetCourseId(courseId);
    setActiveTab('courses');
    setTimeout(() => setSearchTargetCourseId(null), 100);
  };

  const navigateToNote = (noteId: string) => {
    setSearchTargetNoteId(noteId);
    setActiveTab('notes');
    setTimeout(() => setSearchTargetNoteId(null), 100);
  };

  const navigateToBlog = (blogId: string) => {
    setSearchTargetBlogId(blogId);
    setActiveTab('blog');
    setTimeout(() => setSearchTargetBlogId(null), 100);
  };

  // Localization toggle ('en' | 'hi')
  const [lang, setLang] = useState<'en' | 'hi'>('en');

  // Dark / Light Theme state
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Authentic Student Profile state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<string>('home');
  // Secondary filter carried over (e.g. from nav clicks on "Class 10" or "JEE")
  const [drillFilter, setDrillFilter] = useState<string>('');

  // Mobile drawer trigger
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Newsletter form details
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  // Contact form details
  const [contactName, setContactName] = useState('');
  const [contactText, setContactText] = useState('');
  const [contactSuccess, setContactSuccess] = useState(false);

  // Live dynamic message broadcasts sent by Sushil Sir
  const [liveAlertText, setLiveAlertText] = useState<string>('');

  useEffect(() => {
    const fetchLiveBanners = async () => {
      try {
        const notifs = await firebaseService.getNotifications();
        if (notifs.length > 0) {
          const mostRecent = notifs[0];
          const text = lang === 'hi' ? (mostRecent.textHi || mostRecent.text) : mostRecent.text;
          setLiveAlertText(text);
        } else {
          setLiveAlertText('');
        }
      } catch (err) {
        console.warn("Live broadcast system sync omitted.");
      }
    };
    fetchLiveBanners();
    const timer = setInterval(fetchLiveBanners, 30000);
    return () => clearInterval(timer);
  }, [lang]);

  // Sync theme changes with CSS body elements
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Handle active Tab changes and clear navigation states
  const navigateToTab = (tab: string, filterStr = '') => {
    setActiveTab(tab);
    setDrillFilter(filterStr);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Callback to persist completed progress metrics
  const handleUpdateProgress = (courseId: string, percent: number) => {
    if (currentUser) {
      const nextProgress = { ...(currentUser.progress || {}), [courseId]: percent };
      setCurrentUser({ ...currentUser, progress: nextProgress });
    }
  };

  // Callback to persist notes bookmark actions
  const handleBookmarkChanged = (noteId: string, isBookmarked: boolean) => {
    if (currentUser) {
      let nextBookmarks = [...(currentUser.bookmarks || [])];
      if (isBookmarked) {
        if (!nextBookmarks.includes(noteId)) {
          nextBookmarks.push(noteId);
        }
      } else {
        nextBookmarks = nextBookmarks.filter(id => id !== noteId);
      }
      setCurrentUser({ ...currentUser, bookmarks: nextBookmarks });
    }
  };

  // Callback to append scoring records to active user dashboard
  const handleSaveResult = (result: TestResult) => {
    if (currentUser) {
      const currentProgress = { ...(currentUser.progress || {}) };
      // Increase progress indicator if user attempts test questions
      currentProgress[result.testId] = Math.max(currentProgress[result.testId] || 0, result.score);
      setCurrentUser({ ...currentUser, progress: currentProgress });
    }
  };

  // Multi-lingual dictionary
  const labelsMap = {
    en: {
      academyName: "PCM Plus Academy",
      brandTitle: "PCM Plus Academy by Sushil Pandey",
      tagline: "Learn Today, Lead Tomorrow",
      introDesc: "Welcome to India's premier educational hub. Specially tailored classrooms led by Sushil Pandey for Class 6-12, JEE Main & Advanced, NEET, UPSC Civil Services, SSC, Banking, Railways, and industry-oriented Computer Courses.",
      
      // Nav tabs
      home: "Home",
      courses: "Courses",
      notes: "Notes",
      testSeries: "Test Series",
      currentAffairs: "Current Affairs",
      computerSkills: "Computer Lab",
      class10: "Class 10",
      class11: "Class 11",
      class12: "Class 12",
      jee: "JEE",
      neet: "NEET",
      upsc: "UPSC",
      ssc: "SSC",
      banking: "Banking",
      railway: "Railway",
      computerCourses: "Computer Courses",
      blog: "Blog & Strategy",
      aboutUs: "About Us",
      contactUs: "Contact",
      studentPortal: "Student Portal",

      // Hero Elements
      exploreCourses: "Explore Syllabus",
      getFreeNotes: "Get Free PDF Notes",
      liveBanner: "🔴 Admissions Open for Academic Batch 2026-27 | Register to avail 30% Scholarships!",

      // Introduction
      aboutHeader: "Academy Vision & Mission",
      aboutDetail: "At PCM Plus Academy, we firmly believe core educational guidance shouldn't be governed by cramming formulas. Under Sushil Pandey Sir's expert supervision, we empower students to cultivate critical thinking, scientific inquiry, and analytical depth required to conquer competitive state-level and nationwide examinations with absolute ease.",

      // Featured subjects
      subjectsHeader: "Explore Key Disciplines",
      subjectsDesc: "Master core STEM subjects alongside general sciences and coding models under Sushil Sir's personalized syllabus.",

      // Mock lists
      successHeadline: "Recent Success Stories",
      storiesDetail: "Hear from Sushil Sir's former candidates who cleared India's hardest competitive hurdles.",
      testimonials: "Student Testimonials",
      appSlogan: "Study On the Go!",
      appDesc: "Download our PCM Plus Mobile application to access hand-written Notes offline, watch recorded video lectures seamlessly, and attempt MCQ live exams without disruption.",
      newsHeaderHeader: "Join Our Learning Newsletter",
      newsPlaceholder: "Enter scholastic email ID...",
      newsSubscribed: "Thank you! You are registered for Sushil Sir's weekly rank sheets.",
      contactHeader: "Get in Touch with Sushil Sir",
      contactNameLabel: "Your Name",
      contactMsgLabel: "Your Query/Admission Interest",
      contactSubmit: "Transmit Message Direct",
      contactDone: "Thank you! Our admission representative will trace back to your cell within 24 hours under code PCM-OK.",

      footerDesc: "Empowering next-generation science scholars and administrative leaders. Under Sushil Pandey Sir’s verified academic tutelage.",
      quickLinks: "Academy Directory"
    },
    hi: {
      academyName: "पीसीएम प्लस अकादमी",
      brandTitle: "सुशील पांडेय द्वारा पीसीएम प्लस अकादमी",
      tagline: "आज सीखें, कल नेतृत्व करें",
      introDesc: "भारत के उत्कृष्ट शैक्षणिक संस्थान में स्वागत है। कक्षा 6-12, जेईई, नीट, यूपीएससी सिविल सर्विसेज, एसएससी, बैंकिंग, रेलवे और कंप्यूटर कोर्सेज की तैयारी के लिए सुशील पांडेय सर के नेतृत्व में उन्नत डिजिटल अध्ययन मंच।",

      home: "मुख्य पृष्ठ",
      courses: "पाठ्यक्रम",
      notes: "अध्ययन नोट्स",
      testSeries: "टेस्ट सीरीज",
      currentAffairs: "करंत अफेयर्स",
      computerSkills: "कंप्यूटर लैब",
      class10: "कक्षा 10",
      class11: "कक्षा 11",
      class12: "कक्षा 12",
      jee: "जेईई (JEE)",
      neet: "नीट (NEET)",
      upsc: "यूपीएससी",
      ssc: "एसएससी",
      banking: "बैंकिंग",
      railway: "रेलवे (Railway)",
      computerCourses: "कंप्यूटर कोर्सेज",
      blog: "ब्लॉग और रणनीति",
      aboutUs: "हमारे बारे में",
      contactUs: "संपर्क करें",
      studentPortal: "छात्र पोर्टल",

      exploreCourses: "कोर्स देखें",
      getFreeNotes: "मुफ्त पीडीएफ नोट्स",
      liveBanner: "🔴 शैक्षणिक सत्र 2026-27 के लिए नए प्रवेश शुरू | 30% छात्रवृत्ति के लिए अभी नामांकन करें!",

      aboutHeader: "अकादमी की दृष्टि और उद्देश्य",
      aboutDetail: "पीसीएम प्लस अकादमी में हमारा दृढ़ विश्वास है कि शिक्षा मात्र सूत्रों को रटने तक सीमित नहीं होनी चाहिए। सुशील पांडेय सर के कुशल मार्गदर्शन में, हम छात्रों में तार्किक सोच, वैज्ञानिक दृष्टिकोण और विश्लेषात्मक क्षमता विकसित करते हैं, जो कठिन से कठिन परीक्षाओं को आसानी से उत्तीर्ण करने में सहायक सिद्ध होती है।",

      subjectsHeader: "हमारे मुख्य विषय",
      subjectsDesc: "सुशील सर के व्यक्तिगत मार्गदर्शन में विज्ञान, गणित, सामान्य ज्ञान और कोडिंग मॉडल सीखें।",
      successHeadline: "सफलता की कहानियां",
      storiesDetail: "सुशील सर के उन प्रतिभाशाली पूर्व छात्रों से मिलें जिन्होंने भारत की सबसे कठिन प्रतिस्पर्धी परीक्षाओं को उत्तीर्ण किया।",
      testimonials: "छात्रों के सराहना शब्द",
      appSlogan: "कहीं भी, कभी भी पढ़ें!",
      appDesc: "पीसीएम प्लस मोबाइल एप्लिकेशन डाउनलोड कर offline नोट्स पढ़ें, बेहतरीन वीडियो लेक्चर्स देखें और बिना रुकावट के मॉक टेस्ट दें।",
      newsHeaderHeader: "साप्ताहिक न्यूज़लेटर से जुड़ें",
      newsPlaceholder: "अपना ईमेल पता दर्ज करें...",
      newsSubscribed: "धन्यवाद! आप सुशील सर की साप्ताहिक रैंक शीट्स न्यूज़लेटर में जुड़ चुके हैं।",
      contactHeader: "सुशील सर से सीधे संपर्क करें",
      contactNameLabel: "आपका नाम",
      contactMsgLabel: "आपका प्रश्न या एडमिशन रुचि",
      contactSubmit: "संदेश भेजें",
      contactDone: "धन्यवाद! हमारी टीम 24 घंटे के अंदर आपसे संपर्क करेगी।",
      footerDesc: "भावी वैज्ञानिकों, इंजीनियरों और प्रशासनिक अधिकारियों को सशक्त बनाने के लिए सुशील पांडेय सर के नेतृत्व में समर्पित अकादमी।",
      quickLinks: "अकादमी निर्देशिका"
    }
  };

  const labels = labelsMap[lang];

  // Dynamic search predictions
  const filteredSearchCourses = searchQuery.trim() === '' ? [] : SEED_COURSES.filter(c => 
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.examType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredSearchNotes = searchQuery.trim() === '' ? [] : SEED_NOTES.filter(n => 
    n.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    n.chapter.toLowerCase().includes(searchQuery.toLowerCase()) ||
    n.contentMarkdown.toLowerCase().includes(searchQuery.toLowerCase()) ||
    n.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    n.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredSearchBlogs = searchQuery.trim() === '' ? [] : SEED_BLOGS.filter(b => 
    b.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    b.contentMarkdown.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalResultsCount = filteredSearchCourses.length + filteredSearchNotes.length + filteredSearchBlogs.length;

  return (
    <div id="pcm-plus-root" className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-[#090d16] dark:text-slate-100 selection:bg-amber-500 font-sans transition-colors duration-300">
      
      {/* 1. TOP HEADER BANNER NOTIFICATION */}
      <div id="scholarship-alert-banner" className="bg-gradient-to-r from-blue-955 via-amber-600 to-blue-955 text-white text-[11px] font-bold text-center py-2 px-4 shadow-inner border-b border-amber-500/20 transition-all">
        <span>{liveAlertText || labels.liveBanner}</span>
      </div>

      {/* 2. NAVIGATION BAR */}
      <header id="main-navigation-header" className="sticky top-0 z-40 bg-slate-900/95 text-white border-b border-slate-800 transition-all font-sans shadow-lg backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-16">
          
          {/* Brand Logo & Title links home */}
          <div 
            onClick={() => navigateToTab('home')} 
            className="flex items-center space-x-2.5 cursor-pointer hover:opacity-90 transition-opacity shrink-0"
          >
            <div className="bg-amber-400 w-10 h-10 rounded-lg flex items-center justify-center font-bold text-blue-900 text-xl border border-amber-300 shadow shadow-amber-400/25 shrink-0">
              <GraduationCap className="h-6 w-6 text-blue-900" />
            </div>
            <div>
              <h1 id="brand-academy-title" className="text-base sm:text-lg font-extrabold leading-none uppercase tracking-tight text-white select-none">
                PCM Plus Academy
              </h1>
              <p className="text-[10px] text-amber-400 font-medium tracking-widest uppercase mt-0.5 select-none">By Sushil Pandey</p>
            </div>
          </div>

          {/* DESKTOP GLOBAL SEARCH ENGINE BAR */}
          <div className="hidden md:block relative max-w-xs lg:max-w-sm w-full mx-4" id="global-desktop-search-container">
            <div className="relative">
              <Search className="absolute left-3.5 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setShowSearchResults(true)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowSearchResults(true);
                }}
                onBlur={() => setTimeout(() => setShowSearchResults(false), 250)}
                placeholder={lang === 'en' ? "Search courses, notes, articles..." : "कोर्स, नोट्स, रणनीति खोजें..."}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl py-2 pl-10 pr-8 text-xs text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-400 hover:border-slate-700 transition-all font-sans"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-2 text-slate-400 hover:text-white font-mono text-[10px]"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Prediction Dropdown results */}
            {showSearchResults && searchQuery.trim() !== '' && (
              <div 
                id="search-results-overlay-desktop"
                className="absolute top-11 left-0 right-0 max-h-[350px] overflow-y-auto bg-slate-900 border border-slate-850 rounded-xl shadow-2xl p-3 z-50 text-xs text-slate-300 space-y-3 font-sans"
              >
                <div className="flex justify-between items-center text-[10px] text-slate-400 uppercase tracking-widest font-bold pb-1.5 border-b border-slate-800">
                  <span>Results ({totalResultsCount})</span>
                </div>

                {totalResultsCount === 0 ? (
                  <p className="text-slate-500 font-semibold py-4 text-center">No matches found. Try spelling class, chapter or subject!</p>
                ) : (
                  <div className="space-y-3 divide-y divide-slate-850">
                    {/* Courses matches */}
                    {filteredSearchCourses.length > 0 && (
                      <div className="pt-2">
                        <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block mb-1">Courses & Videos</span>
                        <div className="space-y-1">
                          {filteredSearchCourses.map(course => (
                            <button
                              key={course.id}
                              onClick={() => navigateToCourse(course.id)}
                              className="w-full text-left p-1.5 rounded-lg hover:bg-white/5 transition-colors flex items-center justify-between group"
                            >
                              <div className="min-w-0 pr-2">
                                <p className="font-semibold text-slate-200 group-hover:text-amber-400 transition-colors truncate">{course.title}</p>
                                <p className="text-[10px] text-slate-400 truncate">{course.subject}</p>
                              </div>
                              <span className="text-[9px] uppercase font-bold text-slate-300 bg-blue-955/40 px-1.5 py-0.5 rounded border border-blue-900 shrink-0">{course.examType}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Notes matches */}
                    {filteredSearchNotes.length > 0 && (
                      <div className="pt-2">
                        <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block mb-1">Study Notes PDFs</span>
                        <div className="space-y-1">
                          {filteredSearchNotes.map(note => (
                            <button
                              key={note.id}
                              onClick={() => navigateToNote(note.id)}
                              className="w-full text-left p-1.5 rounded-lg hover:bg-white/5 transition-colors flex items-center justify-between group"
                            >
                              <div className="min-w-0 pr-2">
                                <p className="font-semibold text-slate-200 group-hover:text-amber-400 transition-colors truncate">{note.title}</p>
                                <p className="text-[10px] text-slate-400 truncate">{note.subject} • Chapter: {note.chapter}</p>
                              </div>
                              <span className="text-[9px] uppercase font-bold text-slate-300 bg-amber-950/20 px-1.5 py-0.5 rounded border border-amber-900 shrink-0">{note.category}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Blogs matches */}
                    {filteredSearchBlogs.length > 0 && (
                      <div className="pt-2">
                        <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block mb-1">Strategy Blogs & Tips</span>
                        <div className="space-y-1">
                          {filteredSearchBlogs.map(blog => (
                            <button
                              key={blog.id}
                              onClick={() => navigateToBlog(blog.id)}
                              className="w-full text-left p-1.5 rounded-lg hover:bg-white/5 transition-colors flex items-center justify-between group"
                            >
                              <div className="min-w-0 pr-2">
                                <p className="font-semibold text-slate-200 group-hover:text-amber-400 transition-colors truncate">{blog.title}</p>
                                <p className="text-[10px] text-slate-400 truncate">Category: {blog.category}</p>
                              </div>
                              <span className="text-[9px] uppercase font-bold text-slate-350 bg-slate-800 px-1.5 py-0.5 rounded shrink-0">Blog</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Desktop Navigation Row (Sub-Group Selection) */}
          <nav id="desktop-nav-menu" className="hidden lg:flex items-center space-x-6 text-sm font-medium">
            <button 
              id="nav-btn-home"
              onClick={() => navigateToTab('home')} 
              className={`pb-1 transition-all hover:text-amber-200 text-xs font-semibold uppercase tracking-wider outline-none border-b-2 ${activeTab === 'home' ? 'text-amber-400 border-amber-400 font-bold' : 'text-slate-100 border-transparent hover:border-amber-400/50'}`}
            >
              {labels.home}
            </button>
            <button 
              id="nav-btn-courses"
              onClick={() => navigateToTab('courses')} 
              className={`pb-1 transition-all hover:text-amber-200 text-xs font-semibold uppercase tracking-wider outline-none border-b-2 ${activeTab === 'courses' ? 'text-amber-400 border-amber-400 font-bold' : 'text-slate-100 border-transparent hover:border-amber-400/50'}`}
            >
              {labels.courses}
            </button>
            <button 
              id="nav-btn-notes"
              onClick={() => navigateToTab('notes')} 
              className={`pb-1 transition-all hover:text-amber-200 text-xs font-semibold uppercase tracking-wider outline-none border-b-2 ${activeTab === 'notes' ? 'text-amber-400 border-amber-400 font-bold' : 'text-slate-100 border-transparent hover:border-amber-400/50'}`}
            >
              {labels.notes}
            </button>
            <button 
              id="nav-btn-tests"
              onClick={() => navigateToTab('tests')} 
              className={`pb-1 transition-all hover:text-amber-200 text-xs font-semibold uppercase tracking-wider outline-none border-b-2 ${activeTab === 'tests' ? 'text-amber-400 border-amber-400 font-bold' : 'text-slate-100 border-transparent hover:border-amber-400/50'}`}
            >
              {labels.testSeries}
            </button>
            <button 
              id="nav-btn-current-affairs"
              onClick={() => navigateToTab('current-affairs')} 
              className={`pb-1 transition-all hover:text-amber-200 text-xs font-semibold uppercase tracking-wider outline-none border-b-2 ${activeTab === 'current-affairs' ? 'text-amber-400 border-amber-400 font-bold' : 'text-slate-100 border-transparent hover:border-amber-400/50'}`}
            >
              {labels.currentAffairs}
            </button>
            <button 
              id="nav-btn-blog"
              onClick={() => navigateToTab('blog')} 
              className={`pb-1 transition-all hover:text-amber-200 text-xs font-semibold uppercase tracking-wider outline-none border-b-2 ${activeTab === 'blog' ? 'text-amber-400 border-amber-400 font-bold' : 'text-slate-105 border-transparent hover:border-amber-400/50'}`}
            >
              {labels.blog}
            </button>
            <button 
              id="nav-btn-computer-skills"
              onClick={() => navigateToTab('computer-skills')} 
              className={`pb-1 transition-all hover:text-amber-200 text-xs font-semibold uppercase tracking-wider outline-none border-b-2 ${activeTab === 'computer-skills' ? 'text-amber-400 border-amber-400 font-bold' : 'text-slate-105 border-transparent hover:border-amber-400/50'}`}
            >
              {labels.computerSkills}
            </button>

            {/* Quick dashboard tabs */}
            {currentUser && (
              <button 
                id="nav-btn-dashboard"
                onClick={() => navigateToTab('dashboard')} 
                className={`pb-1 transition-all hover:text-amber-200 text-xs font-semibold uppercase tracking-wider outline-none border-b-2 ${activeTab === 'dashboard' ? 'text-amber-400 border-amber-400 font-bold' : 'text-slate-105 border-transparent hover:border-amber-400/50'}`}
              >
                Dashboard
              </button>
            )}

            {currentUser?.email?.toLowerCase().trim() === 'pcmplusacademy@gmail.com' && (
              <button 
                id="nav-btn-admin"
                onClick={() => navigateToTab('admin')} 
                className="px-3 py-1 rounded bg-amber-500 hover:bg-amber-600 dark:bg-amber-600 dark:hover:bg-amber-700 text-slate-900 dark:text-white font-bold text-xs uppercase transition-colors border border-amber-400"
              >
                Admin Board
              </button>
            )}
          </nav>

          {/* Quick Controls Layout (Language + Theme + Student Registration Portal) */}
          <div className="flex items-center space-x-2.5">
            {/* Live Now Indicator Badge */}
            <div className="hidden md:flex bg-white/10 px-3 py-1.5 rounded-full items-center gap-2 border border-white/20 select-none">
              <div className="w-2 h-2 bg-green-400 rounded-full shadow-[0_0_8px_rgba(74,222,128,0.8)] animate-pulse"></div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-100 font-mono">Live Now</span>
            </div>

            {/* Multilingual Switcher */}
            <button
              id="btn-language-switch"
              onClick={() => setLang(lang === 'en' ? 'hi' : 'en')}
              className="p-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 text-xs font-bold text-slate-100 flex items-center space-x-1"
              title="Toggle Hindi/English Language"
            >
              <Globe className="h-4 w-4 text-amber-400" />
              <span>{lang === 'en' ? 'EN' : 'HI'}</span>
            </button>

            {/* Theme Toggle Button */}
            <button
              id="btn-theme-toggle"
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              className="p-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 text-slate-100"
              title="Toggle Dark/Light Mode"
            >
              {theme === 'light' ? <Moon className="h-4 w-4 text-amber-400" /> : <Sun className="h-4 w-4 text-amber-400" />}
            </button>

            {/* Portal Action Trigger Button */}
            <button
              id="btn-student-doorway"
              onClick={() => navigateToTab('portal')}
              className="hidden sm:inline-flex bg-amber-400 text-slate-900 px-5 py-2 rounded-lg font-bold text-xs hover:bg-white transition-colors shadow-lg shadow-amber-400/20"
            >
              {currentUser ? currentUser.name.split(' ')[0] : labels.studentPortal}
            </button>

            {/* Mobile Menu Toggle burger */}
            <button
              id="btn-mobile-menu"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-105 rounded"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Dynamic Horizontal Quick Navigation Links for Academic filters */}
        <div id="quick-subjects-subnavigation" className="bg-slate-950 border-t border-b border-slate-800 py-2.5">
          <div className="max-w-7xl mx-auto px-4 overflow-x-auto whitespace-nowrap flex gap-3 text-xs font-medium scrollbar-none">
            <span className="text-slate-400 uppercase font-mono tracking-wider font-bold pr-1.5 self-center">Smart Filter:</span>
            {[
              { id: 'Class 10', label: labels.class10, tab: 'courses' },
              { id: 'Class 11', label: labels.class11, tab: 'courses' },
              { id: 'Class 12', label: labels.class12, tab: 'courses' },
              { id: 'JEE', label: labels.jee, tab: 'courses' },
              { id: 'NEET', label: labels.neet, tab: 'courses' },
              { id: 'UPSC', label: labels.upsc, tab: 'courses' },
              { id: 'SSC', label: labels.ssc, tab: 'notes' },
              { id: 'Banking', label: labels.banking, tab: 'notes' },
              { id: 'Railway', label: labels.railway, tab: 'notes' },
              { id: 'Computer Courses', label: labels.computerCourses, tab: 'courses' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => navigateToTab(item.tab, item.id)}
                className="text-[11px] bg-slate-905 hover:bg-slate-850 hover:border-amber-500 border border-slate-800 text-slate-305 px-3 py-1 rounded-full transition-all hover:scale-105"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {/* Mobile Navigation Drawer Panels */}
        {mobileMenuOpen && (
          <div id="mobile-menu-drawer" className="lg:hidden bg-slate-900 border-b border-slate-800 p-4 space-y-3 text-sm font-semibold text-slate-200">
            {/* Mobile search bar */}
            <div className="relative pb-3 border-b border-slate-800" id="global-mobile-search-container">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={lang === 'en' ? "Search courses, notes, articles..." : "कोर्स, नोट्स, रणनीति खोजें..."}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 pl-9 pr-8 text-xs text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-2 text-slate-400 font-mono text-[10px]"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Mobile search results preview */}
              {searchQuery.trim() !== '' && (
                <div className="mt-2.5 bg-slate-950 rounded-xl border border-slate-850 p-2.5 max-h-60 overflow-y-auto space-y-2 text-xs">
                  <div className="text-[9px] uppercase font-bold text-slate-405 pb-1 border-b border-slate-900 flex justify-between">
                    <span>Results ({totalResultsCount})</span>
                  </div>
                  
                  {totalResultsCount === 0 ? (
                    <p className="text-slate-600 text-[11px] text-center py-2">No results found.</p>
                  ) : (
                    <div className="space-y-2">
                      {/* Course lists */}
                      {filteredSearchCourses.map(course => (
                        <div
                          key={course.id}
                          onClick={() => {
                            navigateToCourse(course.id);
                            setSearchQuery('');
                          }}
                          className="p-1.5 hover:bg-white/5 transition-colors rounded cursor-pointer border-b border-slate-900 last:border-0"
                        >
                          <p className="font-semibold text-slate-200 truncate">{course.title}</p>
                          <span className="text-[9px] text-amber-400 font-bold block uppercase mt-0.5">Course • {course.subject}</span>
                        </div>
                      ))}

                      {/* Notes lists */}
                      {filteredSearchNotes.map(note => (
                        <div
                          key={note.id}
                          onClick={() => {
                            navigateToNote(note.id);
                            setSearchQuery('');
                          }}
                          className="p-1.5 hover:bg-white/5 transition-colors rounded cursor-pointer border-b border-slate-900 last:border-0"
                        >
                          <p className="font-semibold text-slate-200 truncate">{note.title}</p>
                          <span className="text-[9px] text-amber-400 font-bold block uppercase mt-0.5">Notes • {note.chapter}</span>
                        </div>
                      ))}

                      {/* Blog lists */}
                      {filteredSearchBlogs.map(blog => (
                        <div
                          key={blog.id}
                          onClick={() => {
                            navigateToBlog(blog.id);
                            setSearchQuery('');
                          }}
                          className="p-1.5 hover:bg-white/5 transition-colors rounded cursor-pointer border-b border-slate-900 last:border-0"
                        >
                          <p className="font-semibold text-slate-200 truncate">{blog.title}</p>
                          <span className="text-[9px] text-amber-400 font-bold block uppercase mt-0.5">Strategy Blog</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            <button onClick={() => navigateToTab('home')} className="w-full text-left py-2 border-b border-slate-800">{labels.home}</button>
            <button onClick={() => navigateToTab('courses')} className="w-full text-left py-2 border-b border-slate-800">{labels.courses}</button>
            <button onClick={() => navigateToTab('notes')} className="w-full text-left py-2 border-b border-slate-800">{labels.notes}</button>
            <button onClick={() => navigateToTab('tests')} className="w-full text-left py-2 border-b border-slate-800">{labels.testSeries}</button>
            <button onClick={() => navigateToTab('current-affairs')} className="w-full text-left py-2 border-b border-slate-800">{labels.currentAffairs}</button>
            <button onClick={() => navigateToTab('computer-skills')} className="w-full text-left py-2 border-b border-slate-800">{labels.computerSkills}</button>
            <button onClick={() => navigateToTab('blog')} className="w-full text-left py-2 border-b border-slate-800">{labels.blog}</button>
            <button onClick={() => navigateToTab('portal')} className="w-full text-left py-2 border-b border-slate-800">{labels.studentPortal}</button>
            {currentUser && (
              <button onClick={() => navigateToTab('dashboard')} className="w-full text-left py-2 text-amber-400 font-bold">Dashboard</button>
            )}
            {currentUser?.email?.toLowerCase().trim() === 'pcmplusacademy@gmail.com' && (
              <button onClick={() => navigateToTab('admin')} className="w-full text-left py-2 text-amber-500 font-bold border-t border-slate-800">Admin Control Box</button>
            )}
          </div>
        )}
      </header>

      {/* 3. MAIN CONTAINER CONTAINER */}
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        
        {/* TAB 1: HOME PANEL */}
        {activeTab === 'home' && (
          <div id="home-view-panel" className="space-y-16">
            
            {/* HERO SECTION DESIGN WITH GLASSMORPHISM AND AMBIENT OUTLINE */}
            <section id="hero-banner-main" className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center py-12">
              <div className="lg:col-span-7 space-y-6">
                <div className="inline-flex items-center space-x-1.5 bg-gradient-to-tr from-amber-550 to-amber-600 text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow">
                  <Sparkles className="h-3.5 w-3.5" />
                  <span>Learn Today, Lead Tomorrow</span>
                </div>

                <h1 className="text-3xl sm:text-4xl md:text-5xl font-outfit font-extrabold tracking-tight text-slate-900 dark:text-white leading-tight">
                  {lang === 'hi' ? 'सीखें आज, नेतृत्व करें कल। सुशील पांडेय सर के साथ' : 'Unlock Your Academic & Competitive Edge'}
                  <br />
                  <span className="bg-gradient-to-r from-blue-900 via-amber-500 to-indigo-900 bg-clip-text text-transparent">
                    PCM Plus Academy
                  </span>
                </h1>

                <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 leading-relaxed max-w-xl">
                  {labels.introDesc}
                </p>

                <div className="flex flex-wrap gap-3 pt-2">
                  <button
                    id="hero-btn-syllabus"
                    onClick={() => navigateToTab('courses')}
                    className="bg-blue-955 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all border border-blue-900 flex items-center gap-1 hover:border-amber-500"
                  >
                    <span>{labels.exploreCourses}</span>
                    <ChevronRight className="h-4.5 w-4.5" />
                  </button>
                  <button
                    id="hero-btn-notes"
                    onClick={() => navigateToTab('notes')}
                    className="bg-white hover:bg-[#fdd205]/10 text-slate-800 dark:bg-slate-900 dark:text-slate-100 font-semibold text-xs sm:text-sm px-6 py-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow transition-all flex items-center gap-1.5"
                  >
                    <Download className="h-4.5 w-4.5 text-amber-500" />
                    <span>{labels.getFreeNotes}</span>
                  </button>
                </div>
              </div>

              {/* Dynamic Mock app display right-side component on Home page */}
              <div className="lg:col-span-5 relative">
                <div className="absolute inset-0 bg-gradient-to-tr from-blue-900 to-amber-500 rounded-2xl blur-2xl opacity-15 animate-pulse-slow shrink-0" />
                <div className="relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-2xl space-y-4">
                  <div className="flex justify-between items-center text-xs text-slate-400 font-semibold border-b border-slate-100 dark:border-slate-805 pb-2.5">
                    <span>🔴 Direct Board Broadcast</span>
                    <span>Class Batch 2026</span>
                  </div>
                  
                  <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl space-y-1">
                    <span className="text-[10px] text-amber-500 font-bold uppercase block">Today\'s Scholastic Question</span>
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                      Why does a dielectric insertion inside a isolated charging cap reduce total electrical field strength?
                    </p>
                  </div>

                  <button
                    onClick={() => navigateToTab('tests', 'JEE')}
                    className="w-full bg-slate-100 hover:bg-amber-500 hover:text-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1"
                  >
                    <span>Attempt Daily Challenge</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </section>

            {/* ACADEMY INTRODUCTION */}
            <section id="about-academy-introduction" className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800/80 p-8 sm:p-12 rounded-3xl shadow-xl space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 h-44 w-44 bg-blue-900/10 rounded-full blur-3xl" />
              <div className="max-w-3xl">
                <span className="text-[10px] uppercase font-mono tracking-widest text-amber-600 font-bold block mb-1">
                  ABOUT THE FOUNDER
                </span>
                <h3 className="text-2xl sm:text-3xl font-outfit font-bold text-slate-955 dark:text-white leading-tight">
                  {labels.aboutHeader}
                </h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-4 leading-relaxed font-sans">
                  {labels.aboutDetail}
                </p>
                <div className="flex items-center space-x-3.5 pt-6">
                  <div className="h-12 w-12 rounded-full bg-blue-900 border-2 border-amber-400 flex items-center justify-center text-white font-bold text-sm">
                    S P
                  </div>
                  <div>
                    <h5 className="text-sm font-bold text-slate-905 dark:text-white">Sushil Pandey (PCM Sir)</h5>
                    <p className="text-[11px] text-slate-400">Chief Educator & Academic Visionary</p>
                  </div>
                </div>
              </div>
            </section>

            {/* FEATURED SUBJECTS GRID */}
            <section id="featured-subjects-board" className="space-y-8">
              <div className="text-center space-y-2">
                <span className="text-[10px] uppercase font-bold text-amber-600 tracking-widest block font-mono">
                  PCM CLASSROOMS
                </span>
                <h3 className="text-2xl sm:text-3xl font-outfit font-bold text-slate-955 dark:text-white">
                  {labels.subjectsHeader}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">{labels.subjectsDesc}</p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { name: "Physics", count: "12 chapters", badge: "Class 11/12 JEE NEET" },
                  { name: "Chemistry", count: "10 chapters", badge: "Class 11/12 JEE" },
                  { name: "Mathematics", count: "15 chapters", badge: "Class 12 JEE" },
                  { name: "Biology", count: "8 chapters", badge: "Class 11/12 NEET" },
                  { name: "History", count: "25 study drafts", badge: "UPSC GS/Optional" },
                  { name: "Polity", count: "18 handouts", badge: "UPSC Prelims" },
                  { name: "Computer Knowledge", count: "12 frameworks", badge: "Basic to AI" },
                  { name: "Reasoning", count: "14 mocks", badge: "SSC/Banking/Railway" },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => navigateToTab(item.name === 'Computer Knowledge' ? 'courses' : 'notes', item.name)}
                    className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-sm hover:shadow-[0_22px_45px_rgba(245,158,11,0.14)] hover:border-amber-400 hover:scale-[1.05] hover:-translate-y-1.5 cursor-pointer transition-all duration-500 ease-in-out flex flex-col justify-between group"
                  >
                    <div>
                      <h4 className="font-outfit font-bold text-sm sm:text-base text-slate-900 dark:text-slate-100 group-hover:text-blue-950 dark:group-hover:text-amber-400 transition-colors">
                        {item.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-1 font-mono">{item.count}</p>
                    </div>

                    <span className="text-[9px] uppercase font-mono tracking-wider font-bold text-amber-600 mt-4 block">
                      {item.badge}
                    </span>
                  </div>
                ))}
              </div>
            </section>

            {/* RECENT SUCCESS STORIES SLIDERS */}
            <section id="success-stories-slider" className="space-y-8">
              <div className="text-center space-y-2">
                <h3 className="text-2xl sm:text-3xl font-outfit font-bold text-slate-900 dark:text-white">
                  {labels.successHeadline}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">{labels.storiesDetail}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { name: "Vikas Yadav", exam: "JEE Advanced 2025", rank: "AIR 411", text: "Sushil Sir's conceptual explanation in Electrostatics and Gauss Law is the reason I scored 95/100 in Physics. Truly life-transforming!" },
                  { name: "Ananya Mishra", exam: "UPSC Civil Services 2025", rank: "IAS (Rank 42)", text: "Ancient India History Optional is highly demanding, but Sushil Sir's point-wise answer writing maps helped me finish papers comfortably on time." },
                  { name: "Sumit Meena", exam: "NEET Physics/Biology 2025", rank: "Score 685/720", text: "The Online Test Series is 100% simulated to exact NEET standard parameters. Must-take mock exams for every sincere medical aspirant." }
                ].map((st, i) => (
                  <div key={i} className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 p-6 rounded-2xl shadow-lg relative flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-[11px] font-bold text-amber-500 uppercase">{st.exam}</span>
                        <span className="text-xs bg-blue-955 text-white font-mono px-2 py-0.5 rounded font-bold">{st.rank}</span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-sans italic">
                        "{st.text}"
                      </p>
                    </div>
                    <div className="mt-5 pt-4 border-t border-slate-50 dark:border-slate-805 flex items-center space-x-2">
                      <div className="h-7 w-7 rounded-full bg-indigo-100 flex items-center justify-center font-bold text-xs text-indigo-900">
                        {st.name.charAt(0)}
                      </div>
                      <span className="text-xs font-semibold text-slate-800 dark:text-slate-100">{st.name}</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* DOWNLOAD MOBILE APPLICATION BANNER MOCK FRAME */}
            <section id="download-app-section" className="bg-gradient-to-tr from-blue-955 via-blue-900 to-indigo-950 p-8 sm:p-12 rounded-3xl text-white shadow-2xl grid grid-cols-1 md:grid-cols-12 gap-8 items-center border border-amber-400/20">
              <div className="md:col-span-7 space-y-4">
                <span className="bg-amber-500 text-white font-mono text-[9px] font-bold tracking-widest px-2 py-0.5 rounded shadow">
                  OFFLINE LEARNING SYSTEM
                </span>
                <h3 className="text-2xl sm:text-3xl font-outfit font-extrabold">{labels.appSlogan}</h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-lg">
                  {labels.appDesc}
                </p>

                <div className="pt-3 flex flex-wrap gap-2.5">
                  <button className="bg-slate-900 hover:bg-black text-white px-5 py-2.5 rounded-xl text-xs font-bold border border-slate-800 flex items-center gap-1.5 shadow duration-200">
                    <span>Google Play Store</span>
                  </button>
                  <button className="bg-white/10 hover:bg-white/20 text-white px-5 py-2.5 rounded-xl text-xs font-bold border border-white/10 flex items-center gap-1.5 duration-205">
                    <span>iOS App Store</span>
                  </button>
                </div>
              </div>

              {/* Graphical QR module on Home page */}
              <div className="md:col-span-5 flex flex-col items-center justify-center text-center p-6 bg-white/5 rounded-2xl border border-white/10 backdrop-blur shrink-0 select-none">
                <div className="bg-white p-3.5 rounded-xl border-4 border-amber-500">
                  {/* Styled fallback standard canvas SVG QR model representation */}
                  <svg className="h-28 w-28 text-slate-900" viewBox="0 0 100 100">
                    <rect x="10" y="10" width="20" height="20" fill="currentColor"/>
                    <rect x="14" y="14" width="12" height="12" fill="white"/>
                    <rect x="70" y="10" width="20" height="20" fill="currentColor"/>
                    <rect x="74" y="14" width="12" height="12" fill="white"/>
                    <rect x="10" y="70" width="20" height="20" fill="currentColor"/>
                    <rect x="14" y="74" width="12" height="12" fill="white"/>
                    <rect x="40" y="40" width="20" height="20" fill="currentColor"/>
                    <rect x="70" y="70" width="20" height="20" fill="currentColor"/>
                    <rect x="74" y="74" width="12" height="12" fill="white"/>
                    <rect x="45" y="15" width="10" height="10" fill="currentColor"/>
                    <rect x="15" y="45" width="10" height="10" fill="currentColor"/>
                  </svg>
                </div>
                <p className="text-[11px] text-slate-300 font-medium font-outfit mt-3">Scan QR to Join Telegram Channels & WhatsApp Groups direct!</p>
              </div>
            </section>

            {/* CONTACT ME FORM AND NEWLETTER BOX */}
            <section id="contact-and-newsletters-trays" className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
              
              {/* Client inquiries direct transmission */}
              <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-805 p-6 sm:p-8 rounded-2xl shadow-xl space-y-4">
                <h4 className="font-outfit font-bold text-lg text-slate-900 dark:text-white">{labels.contactHeader}</h4>
                
                {contactSuccess ? (
                  <div className="p-4 bg-green-50 text-green-700 text-xs rounded-xl flex items-center shadow-inner">
                    <span>{labels.contactDone}</span>
                  </div>
                ) : (
                  <form onSubmit={(e) => { e.preventDefault(); setContactSuccess(true); }} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">{labels.contactNameLabel}</label>
                      <input
                        type="text"
                        placeholder="John Doe"
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-850 border border-slate-205 dark:border-slate-705 p-2.5 rounded-xl text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-900"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">{labels.contactMsgLabel}</label>
                      <textarea
                        rows={3}
                        placeholder={lang === 'hi' ? 'कक्षा 12 छात्रवृत्ति बैच में एडमिशन कैसे लें?' : 'Inquire about online test configurations...'}
                        value={contactText}
                        onChange={(e) => setContactText(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-855 border border-slate-205 dark:border-slate-705 p-3 rounded-xl text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-900"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-gradient-to-tr from-blue-900 to-indigo-950 text-white font-bold py-2.5 rounded-xl text-xs transition-colors shadow-sm"
                    >
                      {labels.contactSubmit}
                    </button>
                  </form>
                )}
              </div>

              {/* Newsletter subscribe column */}
              <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 p-6 sm:p-8 rounded-2xl shadow-xl flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="bg-amber-105 p-2 rounded-lg inline-block">
                    <Mail className="h-5 w-5 text-amber-500" />
                  </div>
                  <h4 className="font-outfit font-bold text-lg text-slate-900 dark:text-white">{labels.newsHeaderHeader}</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-sans">
                    Register to get monthly compilations of Current Affairs, Arxiv PDF handouts, and NEET state rankings directly in your focal inbox.
                  </p>
                </div>

                <div className="pt-6">
                  {newsletterSubscribed ? (
                    <div className="p-3.5 bg-green-50 text-green-700 text-xs rounded-xl">
                      <span>{labels.newsSubscribed}</span>
                    </div>
                  ) : (
                    <form onSubmit={(e) => { e.preventDefault(); setNewsletterSubscribed(true); }} className="flex gap-2">
                      <input
                        type="email"
                        placeholder={labels.newsPlaceholder}
                        value={newsletterEmail}
                        onChange={(e) => setNewsletterEmail(e.target.value)}
                        className="flex-grow bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-705 px-3.5 py-2.5 rounded-xl text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-900"
                        required
                      />
                      <button
                        type="submit"
                        className="bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-colors shrink-0 shadow-md"
                      >
                        Register
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </section>
          </div>
        )}

        {/* TAB 2: PORTAL ENTRY SCREEN FOR SECURE LOGIN FORM */}
        {activeTab === 'portal' && (
          <div id="student-portal-section" className="max-w-lg mx-auto py-8">
            <AuthModule
              currentUser={currentUser}
              onUserChanged={(user) => {
                const isAdmin = user && user.email.toLowerCase().trim() === 'pcmplusacademy@gmail.com';
                if (user) {
                  user.role = isAdmin ? 'admin' : 'student';
                }
                setCurrentUser(user);
                if (user) {
                  setActiveTab(isAdmin ? 'admin' : 'dashboard');
                }
              }}
              lang={lang}
            />
          </div>
        )}

        {/* TAB 3: DYNAMIC COURSES LECTURES SCREEN */}
        {activeTab === 'courses' && (
          <div id="courses-section" className="space-y-4">
            <div className="pb-4 border-b border-slate-150">
              <h2 className="text-2xl font-outfit font-bold text-slate-955 dark:text-white">PCM Academy HD Courses</h2>
              <p className="text-xs text-slate-500 mt-1">Syllabi catalogs featuring Class 11, Class 12, JEE Mains, NEET, and Professional Computer tools.</p>
            </div>
            <CourseDirectory
              currentUser={currentUser}
              onUpdateProgress={handleUpdateProgress}
              lang={lang}
              initialExamFilter={drillFilter}
              activeCourseId={searchTargetCourseId}
            />
          </div>
        )}

        {/* TAB 4: STUDY HANDOUTS NOTES LISTER SCREEN */}
        {activeTab === 'notes' && (
          <div id="notes-section" className="space-y-4">
            <div className="pb-4 border-b border-slate-150">
              <h2 className="text-2xl font-outfit font-bold text-slate-955 dark:text-white">PCM Chapter Wise Study Handouts</h2>
              <p className="text-xs text-slate-500 mt-1">Confer with authentic notes summaries and direct scientific formulations in Physics, Chemistry and Ancient History.</p>
            </div>
            <NotesViewer
              currentUser={currentUser}
              onBookmarkChanged={handleBookmarkChanged}
              lang={lang}
              initialSubjectFilter={drillFilter}
              activeNoteId={searchTargetNoteId}
            />
          </div>
        )}

        {/* TAB 5: ONLINE TEST SERIES ASSESSMENT SHEETS */}
        {activeTab === 'tests' && (
          <div id="tests-section" className="space-y-4">
            <div className="pb-4 border-b border-slate-150">
              <h2 className="text-2xl font-outfit font-bold text-slate-955 dark:text-white">Online MCQ Mock Assessment Sheets</h2>
              <p className="text-xs text-slate-500 mt-1">Fully interactive assessments featuring precise timing, scorecard feedback, rank system, and solutions.</p>
            </div>
            <TestEngine
              currentUser={currentUser}
              onSaveResult={handleSaveResult}
              lang={lang}
              initialCategoryFilter={drillFilter}
            />
          </div>
        )}

        {/* TAB 6: CURRENT AFFAIRS DESK */}
        {activeTab === 'current-affairs' && (
          <div id="current-affairs-section">
            <CurrentAffairsSection lang={lang} />
          </div>
        )}

        {/* TAB 7: CAREER STRATEGIES BLOG SYSTEM */}
        {activeTab === 'blog' && (
          <div id="blog-section">
            <BlogSystem lang={lang} activeBlogId={searchTargetBlogId} />
          </div>
        )}

        {/* TAB 8: ENROLLED STUDENT DATA DASHBOARD */}
        {activeTab === 'dashboard' && currentUser && (
          <div id="student-dashboard-tab">
            <StudentDashboard
              currentUser={currentUser}
              lang={lang}
              onGoToTab={navigateToTab}
            />
          </div>
        )}

        {/* TAB 9: ADMINISTRATOR SUSHIL SIR CONTROL UNIT SCREEN */}
        {activeTab === 'admin' && (
          currentUser?.email?.toLowerCase().trim() === 'pcmplusacademy@gmail.com' ? (
            <div id="admin-control-tab">
              <AdminDashboard lang={lang} currentUser={currentUser} />
            </div>
          ) : (
            <div id="access-denied-view" className="max-w-xl mx-auto my-12 p-8 bg-white dark:bg-slate-900 border border-red-200 dark:border-red-950/55 rounded-2xl shadow-xl text-center space-y-6">
              <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900">
                <ShieldAlert className="h-8 w-8 text-red-500" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-outfit font-bold text-slate-900 dark:text-white">Access Denied</h3>
                <p className="text-sm font-semibold text-red-600 dark:text-red-400">
                  Access Denied: Only the Official PCM Plus Academy Administrator can access this panel.
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto leading-relaxed">
                  Your current session is unauthorized. Blocked from uploading notes, editing/deleting content, accessing admin settings, or managing users.
                </p>
              </div>
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => navigateToTab('dashboard')}
                  className="bg-slate-900 dark:bg-slate-800 text-white hover:bg-slate-800 dark:hover:bg-slate-700 px-6 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-colors inline-flex items-center gap-1.5 shadow-md"
                >
                  Go to Student Dashboard
                </button>
              </div>
            </div>
          )
        )}

        {/* TAB 10: INTERACTIVE COMPUTER SKILLS CORNER */}
        {activeTab === 'computer-skills' && (
          <div id="computer-skills-section">
            <ComputerSkillsSection lang={lang} currentUser={currentUser} />
          </div>
        )}

      </main>

      {/* 4. FOOTER */}
      <footer id="main-academy-footer" className="bg-slate-900 text-white mt-16 py-12 border-t border-amber-500/10 font-sans">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8 text-xs leading-relaxed text-slate-400">
          
          <div className="space-y-4 col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2">
              <div className="bg-amber-500 rounded p-1.5 shrink-0">
                <GraduationCap className="h-5 w-5 text-slate-900" />
              </div>
              <span className="font-outfit font-bold text-sm text-white">{labels.brandTitle}</span>
            </div>
            <p className="max-w-sm leading-relaxed">{labels.footerDesc}</p>

            {/* Professional Social Media Links (Requirement 20) */}
            <div className="flex items-center space-x-3 pt-1 pb-2" id="footer-social-media-links">
              <a href="https://youtube.com/@pcmplusacademy" target="_blank" rel="noreferrer" className="h-8 w-8 rounded-full bg-slate-800 hover:bg-rose-600 hover:text-white flex items-center justify-center transition-all border border-slate-700 hover:border-transparent text-slate-300 transform hover:scale-105" title="Subscribe on Youtube">
                <Youtube className="h-4.5 w-4.5" />
              </a>
              <a href="https://www.facebook.com/share/1E8LjAgDU4/" target="_blank" rel="noreferrer" className="h-8 w-8 rounded-full bg-slate-800 hover:bg-blue-600 hover:text-white flex items-center justify-center transition-all border border-slate-700 hover:border-transparent text-slate-300 transform hover:scale-105" title="Follow us on Facebook">
                <Facebook className="h-4.5 w-4.5" />
              </a>
              <a href="https://x.com/PCMPlusAcademy1" target="_blank" rel="noreferrer" className="h-8 w-8 rounded-full bg-slate-800 hover:bg-sky-500 hover:text-white flex items-center justify-center transition-all border border-slate-700 hover:border-transparent text-slate-300 transform hover:scale-105" title="Follow us on Twitter/X">
                <Twitter className="h-4.5 w-4.5" />
              </a>
              <a href="https://www.instagram.com/pcm_plus_academy?igsh=MWJ6MWFsd2o0ZWkwMg==" target="_blank" rel="noreferrer" className="h-8 w-8 rounded-full bg-slate-800 hover:bg-gradient-to-tr hover:from-amber-500 hover:to-indigo-650 hover:text-white flex items-center justify-center transition-all border border-slate-700 hover:border-transparent text-slate-300 transform hover:scale-105" title="Follow us on Instagram">
                <Instagram className="h-4.5 w-4.5" />
              </a>
              <a href="https://linkedin.com/school/pcmplus" target="_blank" rel="noreferrer" className="h-8 w-8 rounded-full bg-slate-800 hover:bg-blue-700 hover:text-white flex items-center justify-center transition-all border border-slate-700 hover:border-transparent text-slate-300 transform hover:scale-105" title="Connect with us on LinkedIn">
                <Linkedin className="h-4.5 w-4.5" />
              </a>
              <a href="https://t.me/scienceducation" target="_blank" rel="noreferrer" className="h-8 w-8 rounded-full bg-slate-800 hover:bg-sky-650 hover:text-white flex items-center justify-center transition-all border border-slate-700 hover:border-transparent text-slate-300 transform hover:scale-105" title="Join Telegram Channel">
                <Send className="h-4.5 w-4.5" />
              </a>
            </div>

            <p className="text-[10px] font-mono text-slate-500 font-bold">"Learn Today, Lead Tomorrow" • PCM Academy © 2026. All Rights Reserved.</p>
          </div>

          <div className="space-y-3">
            <h4 className="font-outfit font-bold text-xs text-white uppercase tracking-wider">{labels.quickLinks}</h4>
            <div className="space-y-1.5 flex flex-col items-start">
              <button onClick={() => navigateToTab('home')} className="hover:text-amber-400">Home Landing</button>
              <button onClick={() => navigateToTab('courses')} className="hover:text-amber-400">HD Courses Catalogue</button>
              <button onClick={() => navigateToTab('notes')} className="hover:text-amber-400">Hand-written Notes Drafts</button>
              <button onClick={() => navigateToTab('tests')} className="hover:text-amber-400">Mock Test Series</button>
              <button onClick={() => navigateToTab('current-affairs')} className="hover:text-amber-400">Bulletins Feed</button>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-outfit font-bold text-xs text-white uppercase tracking-wider">Academic Channels</h4>
            <div className="space-y-1.5 font-sans">
              <p className="flex items-center gap-1.5">
                <Mail className="h-4 w-4 text-amber-500" />
                <span>Email: pcmplusacademy@gmail.com</span>
              </p>
              <p className="flex items-center gap-1.5">
                <MapPin className="h-4 w-4 text-amber-500" />
                <span>Campus: Near Banda chauraha, Umari, Pratapgarh, UP</span>
              </p>
              <p className="p-2.5 bg-slate-950 rounded border border-slate-800 tracking-wider">
                📞 Admission Desk: +91 92199 99378
              </p>
            </div>
          </div>
        </div>
      </footer>

      {/* 14. FLOATING WHATSAPP CHAT BUTTON (Requirement 14) */}
      <a
        id="floating-whatsapp-btn"
        href="https://wa.me/919219999378?text=Hello%20Sushil%20Sir%2C%20I%20am%2520interested%2520in%2520PCM%2520Plus%2520Academy%2520Ultimate%2520Ultra%2520Pro%252520courses%252521"
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-24 right-6 z-50 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full p-4 shadow-2xl hover:scale-110 active:scale-95 transition-all duration-300 flex items-center justify-center border-2 border-emerald-300 group"
        title="Chat with Sushil Pandey Sir on WhatsApp"
      >
        <MessageSquare className="h-6 w-6 text-white" />
        <span className="absolute right-14 bg-slate-905 border border-slate-800 text-white text-[11px] px-3 py-1.5 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity font-medium shadow-xl">
          {lang === 'hi' ? 'व्हाट्सएप सहायता' : 'WhatsApp Support'}
        </span>
      </a>

      {/* FLOAT SECURED GEMINI STUDY DESK WIDGET COPIES */}
      <AiAssistant currentUser={currentUser} lang={lang} />
    </div>
  );
}
