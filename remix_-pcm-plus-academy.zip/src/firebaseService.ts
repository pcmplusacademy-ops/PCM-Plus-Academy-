/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  addDoc, 
  deleteDoc, 
  updateDoc, 
  query, 
  where,
  orderBy
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { Course, StudyNote, MCQTest, TestResult, BlogArticle, CurrentAffairsBulletin, UserProfile } from './types';
import { 
  SEED_COURSES, 
  SEED_NOTES, 
  SEED_TESTS, 
  SEED_BLOGS, 
  SEED_CURRENT_AFFAIRS 
} from './data';
import firebaseConfig from './firebase-applet-config.json';

// Helper to determine if we are running in real Firebase or dummy development sandbox
const isDummyConfig = () => {
  return !firebaseConfig.apiKey || 
         firebaseConfig.apiKey.includes('dummy-') || 
         firebaseConfig.apiKey.includes('remixed-');
};

// -------------------------------------------------------------
// FIREBASE PERSISTENCE & LOCAL FALLBACK MANAGER
// -------------------------------------------------------------

// LocalStorage caching keys
const CACHE_KEYS = {
  COURSES: 'pcm_courses_cache',
  NOTES: 'pcm_notes_cache',
  TESTS: 'pcm_tests_cache',
  TEST_RESULTS: 'pcm_test_results_cache',
  BLOGS: 'pcm_blogs_cache',
  CURRENT_AFFAIRS: 'pcm_current_affairs_cache',
  USERS: 'pcm_users_cache',
  NOTIFICATIONS: 'pcm_notifications_cache'
};

export interface SystemNotification {
  id: string;
  text: string;
  textHi?: string;
  type: 'info' | 'warning' | 'success';
  createdAt: string;
}

export const firebaseService = {
  // 1. COURSES MANAGER
  async getCourses(): Promise<Course[]> {
    if (isDummyConfig()) {
      const offline = localStorage.getItem(CACHE_KEYS.COURSES);
      if (offline) return JSON.parse(offline);
      localStorage.setItem(CACHE_KEYS.COURSES, JSON.stringify(SEED_COURSES));
      return SEED_COURSES;
    }

    try {
      const snap = await getDocs(collection(db, 'courses'));
      if (snap.empty) {
        // Automatically seed Firestore with starting PCM catalog
        for (const c of SEED_COURSES) {
          await setDoc(doc(db, 'courses', c.id), c);
        }
        localStorage.setItem(CACHE_KEYS.COURSES, JSON.stringify(SEED_COURSES));
        return SEED_COURSES;
      }
      const data = snap.docs.map(d => d.data() as Course);
      localStorage.setItem(CACHE_KEYS.COURSES, JSON.stringify(data));
      return data;
    } catch (err) {
      console.warn("Firestore count fetch failed. Reading courses cache.", err);
      const cached = localStorage.getItem(CACHE_KEYS.COURSES);
      return cached ? JSON.parse(cached) : SEED_COURSES;
    }
  },

  async saveCourse(course: Course): Promise<void> {
    if (isDummyConfig()) {
      const list = await this.getCourses();
      const updated = list.filter(c => c.id !== course.id);
      updated.unshift(course);
      localStorage.setItem(CACHE_KEYS.COURSES, JSON.stringify(updated));
      return;
    }

    try {
      await setDoc(doc(db, 'courses', course.id), course);
      const list = await this.getCourses();
      const updated = list.filter(c => c.id !== course.id);
      updated.unshift(course);
      localStorage.setItem(CACHE_KEYS.COURSES, JSON.stringify(updated));
    } catch (err) {
      console.error("Firestore save course failed", err);
      throw err;
    }
  },

  // 2. NOTES SUMMARY MANAGER (PDF Study Notes Download System)
  async getNotes(): Promise<StudyNote[]> {
    if (isDummyConfig()) {
      const offline = localStorage.getItem(CACHE_KEYS.NOTES);
      if (offline) return JSON.parse(offline);
      localStorage.setItem(CACHE_KEYS.NOTES, JSON.stringify(SEED_NOTES));
      return SEED_NOTES;
    }

    try {
      const snap = await getDocs(collection(db, 'notes'));
      if (snap.empty) {
        // Automatically seed dry database notes
        for (const n of SEED_NOTES) {
          await setDoc(doc(db, 'notes', n.id), n);
        }
        localStorage.setItem(CACHE_KEYS.NOTES, JSON.stringify(SEED_NOTES));
        return SEED_NOTES;
      }
      const data = snap.docs.map(d => d.data() as StudyNote);
      localStorage.setItem(CACHE_KEYS.NOTES, JSON.stringify(data));
      return data;
    } catch (err) {
      console.warn("Firestore notes fetch failed. Mocking from system copy.", err);
      const cached = localStorage.getItem(CACHE_KEYS.NOTES);
      return cached ? JSON.parse(cached) : SEED_NOTES;
    }
  },

  async saveNote(note: StudyNote): Promise<void> {
    if (isDummyConfig()) {
      const list = await this.getNotes();
      const updated = list.filter(n => n.id !== note.id);
      updated.unshift(note);
      localStorage.setItem(CACHE_KEYS.NOTES, JSON.stringify(updated));
      return;
    }

    try {
      await setDoc(doc(db, 'notes', note.id), note);
      const list = await this.getNotes();
      const updated = list.filter(n => n.id !== note.id);
      updated.unshift(note);
      localStorage.setItem(CACHE_KEYS.NOTES, JSON.stringify(updated));
    } catch (err) {
      console.error("Firestore save note failed", err);
      throw err;
    }
  },

  // 3. ONLINE TEST SERIES MANAGER
  async getTests(): Promise<MCQTest[]> {
    if (isDummyConfig()) {
      const offline = localStorage.getItem(CACHE_KEYS.TESTS);
      if (offline) return JSON.parse(offline);
      localStorage.setItem(CACHE_KEYS.TESTS, JSON.stringify(SEED_TESTS));
      return SEED_TESTS;
    }

    try {
      const snap = await getDocs(collection(db, 'tests'));
      if (snap.empty) {
        for (const t of SEED_TESTS) {
          await setDoc(doc(db, 'tests', t.id), t);
        }
        localStorage.setItem(CACHE_KEYS.TESTS, JSON.stringify(SEED_TESTS));
        return SEED_TESTS;
      }
      const data = snap.docs.map(d => d.data() as MCQTest);
      localStorage.setItem(CACHE_KEYS.TESTS, JSON.stringify(data));
      return data;
    } catch (err) {
      console.warn("Firestore test queries failed", err);
      const cached = localStorage.getItem(CACHE_KEYS.TESTS);
      return cached ? JSON.parse(cached) : SEED_TESTS;
    }
  },

  async saveTest(test: MCQTest): Promise<void> {
    if (isDummyConfig()) {
      const list = await this.getTests();
      const updated = list.filter(t => t.id !== test.id);
      updated.unshift(test);
      localStorage.setItem(CACHE_KEYS.TESTS, JSON.stringify(updated));
      return;
    }

    try {
      await setDoc(doc(db, 'tests', test.id), test);
      const list = await this.getTests();
      const updated = list.filter(t => t.id !== test.id);
      updated.unshift(test);
      localStorage.setItem(CACHE_KEYS.TESTS, JSON.stringify(updated));
    } catch (err) {
      console.error("Firestore save test mock failed", err);
      throw err;
    }
  },

  // 4. TEST RESULTS HISTORIES MANAGER (Results Tracker)
  async getTestResults(uid?: string): Promise<TestResult[]> {
    if (isDummyConfig()) {
      const mockResultCache = localStorage.getItem(CACHE_KEYS.TEST_RESULTS);
      const defaultResults: TestResult[] = uid ? [
        {
          id: "res1",
          userId: uid,
          userName: "PCM Scholar Student",
          testId: "test_jee_phys_1",
          testTitle: "JEE Electromagnetism & Field Theory - Practice Test 1",
          category: "JEE",
          score: 66,
          correctCount: 2,
          wrongCount: 1,
          totalQuestions: 3,
          takenAt: "2026-06-15T15:00:00Z"
        },
        {
          id: "res2",
          userId: uid,
          userName: "PCM Scholar Student",
          testId: "test_comp_js_1",
          testTitle: "Computer Knowledge: JavaScript & Web Dev Basics",
          category: "Computer Courses",
          score: 100,
          correctCount: 1,
          wrongCount: 0,
          totalQuestions: 1,
          takenAt: "2026-06-16T08:30:00Z"
        }
      ] : [];
      if (mockResultCache) {
        const parsed = JSON.parse(mockResultCache) as TestResult[];
        return uid ? parsed.filter(p => p.userId === uid) : parsed;
      }
      return defaultResults;
    }

    try {
      const colRef = collection(db, 'testResults');
      const snap = await getDocs(colRef);
      const list = snap.docs.map(d => d.data() as TestResult);
      localStorage.setItem(CACHE_KEYS.TEST_RESULTS, JSON.stringify(list));
      if (uid) {
        return list.filter(r => r.userId === uid);
      }
      return list;
    } catch (err) {
      console.warn("Firestore testResults retrieval error", err);
      const cached = localStorage.getItem(CACHE_KEYS.TEST_RESULTS);
      if (cached) {
        const parsed = JSON.parse(cached) as TestResult[];
        return uid ? parsed.filter(p => p.userId === uid) : parsed;
      }
      return [];
    }
  },

  async saveTestResult(result: TestResult): Promise<void> {
    if (isDummyConfig()) {
      const cache = localStorage.getItem(CACHE_KEYS.TEST_RESULTS);
      const list = cache ? JSON.parse(cache) : [];
      list.unshift(result);
      localStorage.setItem(CACHE_KEYS.TEST_RESULTS, JSON.stringify(list));
      return;
    }

    try {
      await setDoc(doc(db, 'testResults', result.id), result);
      const cache = localStorage.getItem(CACHE_KEYS.TEST_RESULTS);
      const list = cache ? JSON.parse(cache) : [];
      list.unshift(result);
      localStorage.setItem(CACHE_KEYS.TEST_RESULTS, JSON.stringify(list));
    } catch (err) {
      console.error("Firestore testResults post error", err);
      throw err;
    }
  },

  // 5. REGISTERED STUDENTS MANAGER (Manage Students)
  async getStudents(): Promise<UserProfile[]> {
    if (isDummyConfig()) {
      const cached = localStorage.getItem(CACHE_KEYS.USERS);
      if (cached) return JSON.parse(cached);
      // Construct a default students catalog list
      const defaults: UserProfile[] = [
        {
          uid: "student_abc123",
          name: "Rohan Gupta",
          email: "rohan.gupta99@gmail.com",
          role: "student",
          createdAt: "2026-05-10T12:00:20Z",
          progress: { "course_jee_physics": 75, "course_comp_basics": 100 }
        },
        {
          uid: "student_xyz789",
          name: "Simran Verma",
          email: "simran.neet@gmail.com",
          role: "student",
          createdAt: "2026-06-01T14:22:15Z",
          progress: { "course_neet_chem": 40 }
        },
        {
          uid: "student_uvw456",
          name: "Abhishek Pandey",
          email: "abhishek88@gmail.com",
          role: "student",
          createdAt: "2026-06-12T09:12:00Z",
          progress: { "course_upsc_history": 15 }
        }
      ];
      localStorage.setItem(CACHE_KEYS.USERS, JSON.stringify(defaults));
      return defaults;
    }

    try {
      const snap = await getDocs(collection(db, 'users'));
      const list = snap.docs.map(d => d.data() as UserProfile);
      localStorage.setItem(CACHE_KEYS.USERS, JSON.stringify(list));
      return list;
    } catch (err) {
      console.error("Firestore users list retrieval failed", err);
      const cached = localStorage.getItem(CACHE_KEYS.USERS);
      return cached ? JSON.parse(cached) : [];
    }
  },

  async saveStudentProfile(student: UserProfile): Promise<void> {
    if (isDummyConfig()) {
      const list = await this.getStudents();
      const updated = list.filter(s => s.uid !== student.uid);
      updated.unshift(student);
      localStorage.setItem(CACHE_KEYS.USERS, JSON.stringify(updated));
      return;
    }

    try {
      await setDoc(doc(db, 'users', student.uid), student);
      const list = await this.getStudents();
      const updated = list.filter(s => s.uid !== student.uid);
      updated.unshift(student);
      localStorage.setItem(CACHE_KEYS.USERS, JSON.stringify(updated));
    } catch (err) {
      console.error("Firestore student profile write failed", err);
    }
  },

  // 6. BROADCAST NOTIFICATIONS SYSTEM
  async getNotifications(): Promise<SystemNotification[]> {
    const defaultNotifs: SystemNotification[] = [
      {
        id: "notif_1",
        text: "🚨 Sushil Pandey Sir is conducting a live mock solution review session for JEE & NEET Chemistry on Sunday at 10 AM!",
        textHi: "🚨 सुशील पांडेय सर द्वारा रविवार सुबह 10 बजे जेईई और नीट केमिस्ट्री के लिए लाइव मॉक उत्तर सत्र आयोजित किया जा रहा है!",
        type: "info",
        createdAt: "2026-06-16T12:00:00Z"
      },
      {
        id: "notif_2",
        text: "📚 Check out the newly uploaded UPSC IAS GS Paper-I syllabus and free Handouts booklet on Ancient Indian History!",
        textHi: "📚 संघ लोक सेवा आयोग (UPSC) आईएएस सामान्य अध्ययन पेपर-I हेतु नया पाठ्यक्रम और प्राचीन भारतीय इतिहास पर फ्री बुकलेट देखें!",
        type: "success",
        createdAt: "2026-06-15T09:30:00Z"
      }
    ];

    if (isDummyConfig()) {
      const cached = localStorage.getItem(CACHE_KEYS.NOTIFICATIONS);
      if (cached) return JSON.parse(cached);
      localStorage.setItem(CACHE_KEYS.NOTIFICATIONS, JSON.stringify(defaultNotifs));
      return defaultNotifs;
    }

    try {
      const snap = await getDocs(collection(db, 'notifications'));
      if (snap.empty) {
        for (const n of defaultNotifs) {
          await setDoc(doc(db, 'notifications', n.id), n);
        }
        localStorage.setItem(CACHE_KEYS.NOTIFICATIONS, JSON.stringify(defaultNotifs));
        return defaultNotifs;
      }
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }) as SystemNotification);
      localStorage.setItem(CACHE_KEYS.NOTIFICATIONS, JSON.stringify(data));
      return data;
    } catch (err) {
      console.warn("Firestore notifications query failure", err);
      const cached = localStorage.getItem(CACHE_KEYS.NOTIFICATIONS);
      return cached ? JSON.parse(cached) : defaultNotifs;
    }
  },

  async sendNotification(text: string, textHi: string, type: 'info' | 'warning' | 'success'): Promise<void> {
    const notif: SystemNotification = {
      id: `notif_${Date.now()}`,
      text,
      textHi,
      type,
      createdAt: new Date().toISOString()
    };

    if (isDummyConfig()) {
      const list = await this.getNotifications();
      list.unshift(notif);
      localStorage.setItem(CACHE_KEYS.NOTIFICATIONS, JSON.stringify(list));
      return;
    }

    try {
      await setDoc(doc(db, 'notifications', notif.id), notif);
      const list = await this.getNotifications();
      list.unshift(notif);
      localStorage.setItem(CACHE_KEYS.NOTIFICATIONS, JSON.stringify(list));
    } catch (err) {
      console.error("Firestore post notification failed", err);
      throw err;
    }
  },

  async clearNotification(id: string): Promise<void> {
    if (isDummyConfig()) {
      const list = await this.getNotifications();
      const filtered = list.filter(n => n.id !== id);
      localStorage.setItem(CACHE_KEYS.NOTIFICATIONS, JSON.stringify(filtered));
      return;
    }

    try {
      await deleteDoc(doc(db, 'notifications', id));
      const list = await this.getNotifications();
      const filtered = list.filter(n => n.id !== id);
      localStorage.setItem(CACHE_KEYS.NOTIFICATIONS, JSON.stringify(filtered));
    } catch (err) {
      console.error("Firestore remove notification err", err);
    }
  }
};
