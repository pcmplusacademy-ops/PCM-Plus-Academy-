/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Course, Lecture, UserProfile } from '../types';
import { SEED_COURSES } from '../data';
import { Search, BookOpen, Clock, PlayCircle, Eye, CheckCircle2, ChevronRight, GraduationCap } from 'lucide-react';
import { firebaseService } from '../firebaseService';
import FocusTimer from './FocusTimer';

interface CourseDirectoryProps {
  currentUser: UserProfile | null;
  onUpdateProgress: (courseId: string, percent: number) => void;
  lang: 'en' | 'hi';
  initialExamFilter?: string; // Optional filtering when clicked from main navbar
  activeCourseId?: string | null;
}

export default function CourseDirectory({ currentUser, onUpdateProgress, lang, initialExamFilter, activeCourseId }: CourseDirectoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [selectedExam, setSelectedExam] = useState(initialExamFilter || 'All');
  const [activeCourse, setActiveCourse] = useState<Course | null>(null);
  const [activeLecture, setActiveLecture] = useState<Lecture | null>(null);
  const [coursesList, setCoursesList] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);

  // Sync courses with dynamic DB
  useEffect(() => {
    const fetchCoursesSync = async () => {
      try {
        const syncRes = await firebaseService.getCourses();
        setCoursesList(syncRes);
      } catch (err) {
        console.warn("Fallback to offline courses list", err);
        setCoursesList(SEED_COURSES);
      } finally {
        setLoading(false);
      }
    };
    fetchCoursesSync();
  }, []);

  // Sync active course from exterior search trigger
  useEffect(() => {
    if (activeCourseId && coursesList.length > 0) {
      const match = coursesList.find(c => c.id === activeCourseId);
      if (match) {
        setActiveCourse(match);
        setActiveLecture(match.lectures[0] || null);
      }
    }
  }, [activeCourseId, coursesList]);

  // Sync with prop if changed from exterior route
  useEffect(() => {
    if (initialExamFilter) {
      setSelectedExam(initialExamFilter);
    }
  }, [initialExamFilter]);

  // Subjects lists
  const subjects = ['All', 'Physics', 'Chemistry', 'Mathematics', 'Biology', 'History', 'Polity', 'Reasoning', 'Computer Knowledge'];

  // Competitive exam triggers
  const examCategories = [
    'All', 'Class 10', 'Class 11', 'Class 12', 'JEE', 'NEET', 'UPSC', 'SSC', 'Banking', 'Railway', 'Computer Courses'
  ];

  // Filtering implementation
  const filteredCourses = coursesList.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          course.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = selectedSubject === 'All' || course.subject === selectedSubject;
    const matchesExam = selectedExam === 'All' || course.examType === selectedExam;
    return matchesSearch && matchesSubject && matchesExam;
  });

  // Track completed lectures locally to compute percentages
  const [completedLectures, setCompletedLectures] = useState<Record<string, boolean>>({});

  const toggleLectureCompleted = (courseId: string, lectureId: string) => {
    const key = `${courseId}_${lectureId}`;
    const nextCompleted = { ...completedLectures, [key]: !completedLectures[key] };
    setCompletedLectures(nextCompleted);

    // Compute progress score
    const targetCourse = coursesList.find(c => c.id === courseId);
    if (targetCourse) {
      const courseLecturesKeys = targetCourse.lectures.map(l => `${courseId}_${l.id}`);
      const completedCount = courseLecturesKeys.filter(k => nextCompleted[k]).length;
      const percentage = Math.round((completedCount / courseLecturesKeys.length) * 100);
      onUpdateProgress(courseId, percentage);
    }
  };

  const labels = {
    en: {
      searchPlaceholder: "Search educational catalog or topic...",
      allSubjects: "All Subjects",
      allExams: "All Exams & Classes",
      startLearning: "Start Learning",
      lectureProgress: "Syllabus Completed",
      lecturesList: "Lectures Course Curriculum",
      youtubeNote: "Interactive HD Video Class",
      completedCheckbox: "Mark Completed",
      noCourses: "No courses found matching criteria. Ask Sushil Sir's Assistant to explain this topic!"
    },
    hi: {
      searchPlaceholder: "शैक्षणिक पाठ्यक्रम या विषय खोजें...",
      allSubjects: "सभी विषय",
      allExams: "सभी परीक्षाएं और कक्षाएं",
      startLearning: "पढ़ना शुरू करें",
      lectureProgress: "पाठ्यक्रम पूरा हुआ",
      lecturesList: "लेक्चर पाठ्यक्रम अनुसूची",
      youtubeNote: "इंटरैक्टिव एचडी वीडियो क्लास",
      completedCheckbox: "मार्क पूरा हुआ",
      noCourses: "कोई कोर्स नहीं मिला। सुशील सर के सहायक से इस विषय को समझाने को कहें!"
    }
  }[lang];

  return (
    <div id="course-directory-root" className="space-y-6">
      {!activeCourse ? (
        <>
          {/* Controls tray */}
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-md space-y-4">
            <div className="relative">
              <Search className="absolute left-3.5 top-3.5 h-5 w-5 text-slate-400" />
              <input
                type="text"
                placeholder={labels.searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl py-3 pl-11 pr-4 text-sm text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-900"
              />
            </div>

            <div className="space-y-3">
              {/* Subjects scrolling filters */}
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 block mb-2">{labels.allSubjects}</span>
                <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
                  {subjects.map(subj => (
                    <button
                      key={subj}
                      onClick={() => setSelectedSubject(subj)}
                      className={`text-xs px-3.5 py-1.5 rounded-full font-medium border transition-all ${
                        selectedSubject === subj
                          ? 'bg-blue-950 text-white border-blue-950 shadow-md'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-900'
                      }`}
                    >
                      {subj}
                    </button>
                  ))}
                </div>
              </div>

              {/* Exams list */}
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 block mb-2">{labels.allExams}</span>
                <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
                  {examCategories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setSelectedExam(cat)}
                      className={`text-xs px-3.5 py-1.5 rounded-full font-medium border transition-all ${
                        selectedExam === cat
                          ? 'bg-gradient-to-tr from-amber-500 to-amber-600 text-white border-amber-600 shadow-md'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-amber-500'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Courses listings */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.map(course => {
              // Calculate user's completed percentage if logged in
              const percentage = currentUser?.progress?.[course.id] || 0;

              return (
                <div 
                  key={course.id}
                  id={`course-card-${course.id}`}
                  className="bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-100 dark:border-slate-800 shadow-lg hover:shadow-xl transition-all flex flex-col group"
                >
                  <div className="relative h-44 overflow-hidden">
                    <img 
                      src={course.bannerUrl} 
                      alt={course.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <span className="absolute top-3 left-3 bg-blue-950 border border-amber-400 text-white text-[10px] font-bold px-2.5 py-1 rounded shadow-md uppercase">
                      {course.examType}
                    </span>
                    <span className="absolute bottom-3 right-3 text-white text-xs font-semibold flex items-center bg-slate-900/80 px-2 py-0.5 rounded backdrop-blur">
                      <BookOpen className="h-3 w-3 mr-1 text-amber-500" />
                      {course.lectures.length} Lectures
                    </span>
                  </div>

                  <div className="p-5 flex-grow flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-widest text-amber-600 dark:text-amber-400 font-bold block mb-1">
                        {course.subject}
                      </span>
                      <h4 className="text-base font-outfit font-semibold text-slate-900 dark:text-slate-100 group-hover:text-blue-900 dark:group-hover:text-amber-400 transition-colors line-clamp-2">
                        {course.title}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                        {course.description}
                      </p>
                    </div>

                    <div className="mt-5 pt-4 border-t border-slate-50 dark:border-slate-800">
                      {percentage > 0 && (
                        <div className="mb-3">
                          <div className="flex justify-between text-[10px] text-slate-400 font-semibold mb-1">
                            <span>{labels.lectureProgress}</span>
                            <span>{percentage}%</span>
                          </div>
                          <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div className="bg-amber-500 h-full rounded-full transition-all" style={{ width: `${percentage}%` }} />
                          </div>
                        </div>
                      )}

                      <button
                        onClick={() => {
                          setActiveCourse(course);
                          setActiveLecture(course.lectures[0] || null);
                        }}
                        className="w-full bg-gradient-to-tr from-blue-900 to-indigo-900 dark:from-slate-800 dark:to-slate-800 hover:from-blue-950 dark:hover:bg-slate-705 text-white/95 hover:text-white py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1 shadow transition-all border border-transparent hover:border-amber-500"
                      >
                        <span>{labels.startLearning}</span>
                        <ChevronRight className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredCourses.length === 0 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-center p-12 rounded-2xl max-w-lg mx-auto shadow">
              <GraduationCap className="h-12 w-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
              <p className="text-sm font-medium text-slate-600 dark:text-slate-400 leading-relaxed">{labels.noCourses}</p>
            </div>
          )}
        </>
      ) : (
        /* Video Player Screen layout */
        <div id="course-classroom-active" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between">
              <button
                onClick={() => {
                  setActiveCourse(null);
                  setActiveLecture(null);
                }}
                className="text-xs font-semibold text-blue-900 dark:text-amber-400 hover:underline flex items-center gap-1"
              >
                ← Back to Syllabus Directory
              </button>
              <span className="text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-3 py-1 rounded">
                {activeCourse.examType} / {activeCourse.subject}
              </span>
            </div>

            {/* Embedded video player */}
            {activeLecture ? (
              <div className="bg-black aspect-video rounded-2xl overflow-hidden shadow-2xl relative border-2 border-amber-500/30">
                <iframe
                  id="lecture-embed-video"
                  title={activeLecture.title}
                  src={`https://www.youtube.com/embed/${activeLecture.youtubeId}?autoplay=0&rel=0&modestbranding=1`}
                  className="w-full h-full"
                  allowFullScreen
                  referrerPolicy="no-referrer"
                />
              </div>
            ) : (
              <div className="bg-slate-900 aspect-video rounded-2xl flex items-center justify-center text-white italic">
                No active lectures found.
              </div>
            )}

            {/* Active details mapping */}
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 shadow-lg">
              <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider block mb-1">
                Currently Playing Lecture
              </span>
              <h3 className="text-xl font-outfit font-bold text-slate-900 dark:text-slate-100">
                {activeLecture?.title || activeCourse.title}
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                {activeCourse.description}
              </p>

              <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-4 items-center justify-between">
                <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400 font-semibold">
                  <Clock className="h-4 w-4 text-slate-400" />
                  <span>Duration: {activeLecture?.duration || '40 mins'}</span>
                </div>

                {activeLecture && (
                  <button
                    onClick={() => toggleLectureCompleted(activeCourse.id, activeLecture.id)}
                    className={`text-xs font-semibold px-4 py-2 rounded-xl border flex items-center gap-2 transition-all ${
                      completedLectures[`${activeCourse.id}_${activeLecture.id}`]
                        ? 'bg-amber-100 dark:bg-amber-950/40 border-amber-300 text-amber-800 dark:text-amber-400'
                        : 'bg-white hover:bg-slate-50 dark:bg-slate-905 dark:hover:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <CheckCircle2 className={`h-4.5 w-4.5 ${
                      completedLectures[`${activeCourse.id}_${activeLecture.id}`] ? 'text-amber-600 dark:text-amber-400' : 'text-slate-300'
                    }`} />
                    <span>{labels.completedCheckbox}</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Video Playlists playlist sidebar panel & Focus Timer */}
          <div className="space-y-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-lg max-h-[350px] overflow-y-auto">
              <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-amber-500" />
                <span>{labels.lecturesList}</span>
              </h4>

              <div className="space-y-2">
                {activeCourse.lectures.map((lec, index) => {
                  const isCompleted = completedLectures[`${activeCourse.id}_${lec.id}`];
                  const isActive = activeLecture?.id === lec.id;

                  return (
                    <div
                      key={lec.id}
                      onClick={() => setActiveLecture(lec)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center gap-3 relative overflow-hidden group/item ${
                        isActive
                          ? 'bg-blue-50/50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900 shadow-sm'
                          : 'bg-white dark:bg-transparent border-slate-100 hover:border-slate-300 dark:border-slate-800 dark:hover:border-slate-700'
                      }`}
                    >
                      {isActive && (
                        <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-900" />
                      )}

                      <div className="shrink-0">
                        {isCompleted ? (
                          <CheckCircle2 className="h-5 w-5 text-amber-600 dark:text-amber-500" />
                        ) : (
                          <PlayCircle className={`h-5 w-5 ${isActive ? 'text-blue-900' : 'text-slate-300 hover:text-slate-500'}`} />
                        )}
                      </div>

                      <div className="flex-grow min-w-0">
                        <p className={`text-xs font-semibold truncate ${isActive ? 'text-blue-955 dark:text-amber-400' : 'text-slate-800 dark:text-slate-200'}`}>
                          {lec.title}
                        </p>
                        <span className="text-[10px] text-slate-400 block mt-0.5">{lec.duration}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Focus Study Timer Widget */}
            <FocusTimer lang={lang} />
          </div>
        </div>
      )}
    </div>
  );
}
