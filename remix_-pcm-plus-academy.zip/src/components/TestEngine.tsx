/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { MCQTest, TestQuestion, TestResult, UserProfile } from '../types';
import { SEED_TESTS } from '../data';
import { Award, Timer, CheckCircle, XCircle, Search, HelpCircle, ArrowRight, Play, RefreshCw, Trophy, Users } from 'lucide-react';
import { firebaseService } from '../firebaseService';

interface TestEngineProps {
  currentUser: UserProfile | null;
  onSaveResult: (result: TestResult) => void;
  lang: 'en' | 'hi';
  initialCategoryFilter?: string; // e.g. 'JEE' clicked in main nav
}

export default function TestEngine({ currentUser, onSaveResult, lang, initialCategoryFilter }: TestEngineProps) {
  const [selectedCategory, setSelectedCategory] = useState(initialCategoryFilter || 'All');
  const [activeTest, setActiveTest] = useState<MCQTest | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [testsList, setTestsList] = useState<MCQTest[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Timer attributes
  const [timeLeft, setTimeLeft] = useState(0);
  const [timerActive, setTimerActive] = useState(false);

  // Sync assessments on mount
  useEffect(() => {
    const fetchTestsSync = async () => {
      try {
        const syncTests = await firebaseService.getTests();
        setTestsList(syncTests);
      } catch (err) {
        console.warn("Fallback to predefined assessments lists", err);
        setTestsList(SEED_TESTS);
      } finally {
        setLoading(false);
      }
    };
    fetchTestsSync();
  }, []);

  useEffect(() => {
    if (initialCategoryFilter) {
      setSelectedCategory(initialCategoryFilter);
    }
  }, [initialCategoryFilter]);

  // Handle countdown effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && timerActive) {
      setTimerActive(false);
      handleSubmitTest();
    }
    return () => clearInterval(interval);
  }, [timerActive, timeLeft]);

  // Hardcode precompiled leaderboard simulator for each MCQ test!
  const mockLeaderboard: Record<string, { rank: number; name: string; score: number; state: string }[]> = {
    test_jee_phys_1: [
      { rank: 1, name: "Prateek Yadav (UP)", score: 100, state: "UP" },
      { rank: 2, name: "Nandini Mishra (Bihar)", score: 100, state: "Bihar" },
      { rank: 3, name: "Amol Sharma (MP)", score: 66, state: "MP" },
      { rank: 4, name: "Tushar Gupta", score: 66, state: "Raj" }
    ],
    test_neet_bio_1: [
      { rank: 1, name: "Dr Ranjit Pal", score: 100, state: "WB" },
      { rank: 2, name: "Suresh Meena", score: 100, state: "Raj" },
      { rank: 3, name: "Kirti Agrawal", score: 50, state: "HP" }
    ]
  };

  const handleStartTest = (test: MCQTest) => {
    setActiveTest(test);
    setCurrentIdx(0);
    setSelectedAnswers({});
    setIsSubmitted(false);
    setTimeLeft(test.durationMinutes * 60);
    setTimerActive(true);
  };

  const handleSubmitTest = () => {
    if (!activeTest) return;
    setTimerActive(false);
    setIsSubmitted(true);

    // Score calculations
    let correctCount = 0;
    let wrongCount = 0;

    activeTest.questions.forEach(q => {
      const selected = selectedAnswers[q.id];
      if (selected !== undefined) {
        if (selected === q.correctIndex) {
          correctCount++;
        } else {
          wrongCount++;
        }
      } else {
        wrongCount++; // count blank answers as incorrect for simple grade computation
      }
    });

    const totalQuestions = activeTest.questions.length;
    const finalScore = Math.round((correctCount / totalQuestions) * 100);

    const result: TestResult = {
      id: `res_${Math.random().toString(36).substr(2, 9)}`,
      userId: currentUser?.uid || 'guest_user',
      userName: currentUser?.name || 'PCM Guest Student',
      testId: activeTest.id,
      testTitle: activeTest.title,
      category: activeTest.category,
      score: finalScore,
      correctCount,
      wrongCount,
      totalQuestions,
      takenAt: new Date().toISOString()
    };

    firebaseService.saveTestResult(result).catch(err => {
      console.error("Firestore result cataloging failed", err);
    });

    onSaveResult(result);
  };

  const formatTime = (secs: number) => {
    const mm = Math.floor(secs / 60);
    const ss = secs % 60;
    return `${mm}:${ss < 10 ? '0' : ''}${ss}`;
  };

  const categories = ['All', 'Class 10', 'Class 11', 'Class 12', 'JEE', 'NEET', 'UPSC', 'SSC'];
  const filteredTests = testsList.filter(t => selectedCategory === 'All' || t.category === selectedCategory);

  const labels = {
    en: {
      selectCategory: "Select Topic Category",
      startTestBtn: "Begin Live Assessment",
      duration: "Duration",
      questions: "questions total",
      timeLeft: "Time Remaining",
      submitBtn: "Submit Test Sheet",
      quizProgress: "Question Progress",
      scoreTitle: "Your Mock Assessment Verdict",
      scoreReport: "Score Card",
      correct: "Correct Answers",
      wrong: "Wrong Credentials",
      explanation: "PCM Sir Solution & Explanation Note:",
      retry: "Retry Test",
      leaderboard: "Academy Rank System",
      rankName: "Leader Candidate",
      points: "Score Rate"
    },
    hi: {
      selectCategory: "विषय श्रेणी चुनें",
      startTestBtn: "लाइव टेस्ट शुरू करें",
      duration: "समय",
      questions: "कुल प्रश्न",
      timeLeft: "बचा हुआ समय",
      submitBtn: "टेस्ट जमा करें",
      quizProgress: "प्रश्न प्रगति",
      scoreTitle: "आपका मॉक छात्र मूल्यांकन",
      scoreReport: "स्कोर कार्ड रिपोर्ट",
      correct: "सही उत्तर",
      wrong: "गलत उत्तर",
      explanation: "सुशील सर का विस्तृत हल:",
      retry: "पुनः प्रयास करें",
      leaderboard: "अकादमी रैंक प्रणाली",
      rankName: "श्रेणी छात्र",
      points: "स्कोर दर"
    }
  }[lang];

  return (
    <div id="test-series-root" className="space-y-6">
      {!activeTest ? (
        /* Display List of tests */
        <>
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-md">
            <h4 className="font-outfit font-bold text-sm text-slate-800 dark:text-slate-100 mb-3">{labels.selectCategory}</h4>
            <div className="flex gap-1.5 overflow-x-auto pb-1">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-xs px-4 py-2 rounded-xl border transition-all shrink-0 font-medium ${
                    selectedCategory === cat
                      ? 'bg-blue-950 text-white border-blue-950 shadow-md'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-blue-950'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredTests.map(test => (
              <div
                key={test.id}
                id={`test-box-${test.id}`}
                className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between hover:border-amber-500/40 transition-colors group"
              >
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-amber-600 font-bold bg-amber-500/5 border border-amber-500/20 px-2 py-0.5 rounded">
                      {test.category}
                    </span>
                    <span className="text-xs text-slate-400 capitalize">{test.subject}</span>
                  </div>

                  <h4 className="text-base font-outfit font-bold text-slate-900 dark:text-white group-hover:text-blue-950 dark:group-hover:text-amber-400 transition-colors">
                    {test.title}
                  </h4>

                  <div className="flex items-center gap-4 mt-4 text-xs text-slate-500 dark:text-slate-405 font-medium">
                    <div className="flex items-center gap-1.5">
                      <Timer className="h-4 w-4 text-slate-400" />
                      <span>{test.durationMinutes} mins</span>
                    </div>
                    <span>•</span>
                    <span>{test.questions.length} Questions</span>
                  </div>
                </div>

                <button
                  onClick={() => handleStartTest(test)}
                  className="mt-6 w-full bg-slate-50 dark:bg-slate-800 hover:bg-gradient-to-tr hover:from-blue-900 hover:to-indigo-900 hover:text-white text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-705 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
                >
                  <Play className="h-4.5 w-4.5" />
                  <span>{labels.startTestBtn}</span>
                </button>
              </div>
            ))}
          </div>
        </>
      ) : (
        /* Core test exam panel sheets */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {/* Countdown / Assessment metadata */}
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 rounded-2xl flex justify-between items-center shadow">
              <div className="min-w-0">
                <p className="text-[10px] text-slate-400 font-semibold uppercase truncate">{activeTest.title}</p>
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 mt-0.5 whitespace-nowrap">
                  {labels.quizProgress}: {currentIdx + 1} / {activeTest.questions.length}
                </h4>
              </div>

              {!isSubmitted ? (
                <div className="flex items-center space-x-2 bg-red-50 dark:bg-red-950/40 px-3.5 py-1.5 rounded-xl border border-red-200 dark:border-red-900 shrink-0">
                  <Timer className="h-4 w-4 text-red-600 animate-pulse" />
                  <span className="font-mono font-bold text-xs text-red-700 dark:text-red-400">
                    {formatTime(timeLeft)}
                  </span>
                </div>
              ) : (
                <span className="text-xs bg-green-100 text-green-800 font-bold px-3 py-1 rounded">
                  Graded Success
                </span>
              )}
            </div>

            {/* Simulated assessment questionnaire block */}
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
              {(() => {
                const question: TestQuestion = activeTest.questions[currentIdx];
                const optSelected = selectedAnswers[question.id];

                return (
                  <div className="space-y-4">
                    <p className="text-sm font-outfit font-semibold text-slate-950 dark:text-slate-100 leading-relaxed">
                      Q{currentIdx + 1}. {question.question}
                    </p>

                    <div className="space-y-2 pt-2">
                      {question.options.map((opt, oIdx) => {
                        let btnStyle = "bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-200";
                        
                        if (!isSubmitted) {
                          if (optSelected === oIdx) {
                            btnStyle = "bg-blue-105 select-none border-blue-900 text-blue-900 dark:bg-blue-950 dark:border-amber-400 dark:text-amber-400 ring-2 ring-blue-900/10";
                          }
                        } else {
                          // Post submission markers
                          if (oIdx === question.correctIndex) {
                            btnStyle = "bg-green-50 border-green-500 text-green-800 dark:bg-green-950 dark:border-green-600 dark:text-green-305 ring-2 ring-green-900/15";
                          } else if (optSelected === oIdx) {
                            btnStyle = "bg-red-50 border-red-400 text-red-800 dark:bg-red-950 dark:border-red-900 dark:text-red-400";
                          }
                        }

                        return (
                          <button
                            key={oIdx}
                            disabled={isSubmitted}
                            onClick={() => setSelectedAnswers({ ...selectedAnswers, [question.id]: oIdx })}
                            className={`w-full text-left p-3 rounded-xl border-2 text-xs font-medium transition-all flex items-center justify-between ${btnStyle}`}
                          >
                            <span>{opt}</span>
                            {isSubmitted && oIdx === question.correctIndex && (
                              <CheckCircle className="h-4.5 w-4.5 text-green-600" />
                            )}
                            {isSubmitted && optSelected === oIdx && oIdx !== question.correctIndex && (
                              <XCircle className="h-4.5 w-4.5 text-red-600" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Explanation text block */}
                    {isSubmitted && (
                      <div className="mt-4 p-4 bg-slate-50 dark:bg-slate-955 rounded-xl border border-slate-100 dark:border-slate-800 space-y-1.5">
                        <span className="text-[10px] font-bold text-amber-600 uppercase tracking-widest block">{labels.explanation}</span>
                        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-sans">{question.explanation}</p>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Action routing buttons inside active test */}
              <div className="flex justify-between items-center pt-5 border-t border-slate-100 dark:border-slate-800">
                <button
                  disabled={currentIdx === 0}
                  onClick={() => setCurrentIdx(prev => prev - 1)}
                  className="text-xs text-slate-500 disabled:opacity-40 hover:underline"
                >
                  ← Previous
                </button>

                {!isSubmitted ? (
                  currentIdx === activeTest.questions.length - 1 ? (
                    <button
                      onClick={handleSubmitTest}
                      className="bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs px-5 py-2 rounded-xl transition-all shadow-md flex items-center space-x-1.5"
                    >
                      <Award className="h-4 w-4" />
                      <span>{labels.submitBtn}</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => setCurrentIdx(prev => prev + 1)}
                      className="bg-blue-900 text-white text-xs px-5 py-2 rounded-xl hover:bg-blue-950 transition-colors"
                    >
                      Next Question
                    </button>
                  )
                ) : (
                  currentIdx === activeTest.questions.length - 1 ? (
                    <button
                      onClick={() => {
                        setActiveTest(null);
                        setIsSubmitted(false);
                      }}
                      className="bg-slate-900 text-white text-xs px-5 py-2 rounded-xl hover:bg-slate-850"
                    >
                      Exit Mock Review
                    </button>
                  ) : (
                    <button
                      onClick={() => setCurrentIdx(prev => prev + 1)}
                      className="bg-slate-105 text-slate-700 dark:bg-slate-800 dark:text-slate-300 text-xs px-5 py-2 rounded-xl"
                    >
                      Next Solution →
                    </button>
                  )
                )}
              </div>
            </div>
          </div>

          {/* Right sidebar results panel or static preloaded highscore lists */}
          <div className="space-y-4">
            {isSubmitted && (
              <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-850 p-5 rounded-2xl shadow-xl space-y-4 text-center">
                <div className="inline-flex bg-amber-50 rounded-full p-4 border border-amber-200">
                  <Trophy className="h-8 w-8 text-amber-500" />
                </div>
                <h4 className="font-outfit font-bold text-md text-slate-900 dark:text-slate-100">{labels.scoreTitle}</h4>
                <div className="grid grid-cols-2 gap-2 border-t border-slate-50 pt-3">
                  <div className="bg-green-50/50 p-2 rounded-lg">
                    <span className="text-[10px] text-slate-400 block uppercase">{labels.correct}</span>
                    <span className="text-base font-bold text-green-600">
                      {activeTest.questions.filter((q) => selectedAnswers[q.id] === q.correctIndex).length}
                    </span>
                  </div>
                  <div className="bg-red-50/50 p-2 rounded-lg">
                    <span className="text-[10px] text-slate-400 block uppercase">{labels.wrong}</span>
                    <span className="text-base font-bold text-red-600">
                      {activeTest.questions.length - activeTest.questions.filter((q) => selectedAnswers[q.id] === q.correctIndex).length}
                    </span>
                  </div>
                </div>

                <div className="pt-2">
                  <span className="text-xs text-slate-400">{labels.scoreReport} Rate:</span>
                  <div className="text-3xl font-bold font-outfit text-blue-950 dark:text-amber-400">
                    {Math.round((activeTest.questions.filter((q) => selectedAnswers[q.id] === q.correctIndex).length / activeTest.questions.length) * 100)}%
                  </div>
                </div>

                <button
                  onClick={() => handleStartTest(activeTest)}
                  className="mt-2 w-full bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-705 dark:text-slate-205 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <RefreshCw className="h-4 w-4" />
                  <span>{labels.retry}</span>
                </button>
              </div>
            )}

            {mockLeaderboard[activeTest.id] && (
              <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-lg">
                <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-3.5 flex items-center gap-2">
                  <Users className="h-4.5 w-4.5 text-amber-500" />
                  <span>{labels.leaderboard}</span>
                </h4>

                <div className="space-y-2.5">
                  {mockLeaderboard[activeTest.id].map((candidate, keyId) => (
                    <div key={keyId} className="flex justify-between items-center text-xs pb-2 border-b border-slate-50 dark:border-slate-800/50 last:border-b-0 last:pb-0">
                      <div className="flex items-center space-x-2">
                        <span className={`h-5 w-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                          candidate.rank === 1 ? 'bg-amber-150 text-amber-800' : 'bg-slate-100 text-slate-500'
                        }`}>
                          #{candidate.rank}
                        </span>
                        <span className="font-semibold text-slate-700 dark:text-slate-300 truncate max-w-[120px]">{candidate.name}</span>
                      </div>
                      <span className="font-mono text-slate-500 dark:text-slate-400 font-bold">{candidate.score}%</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
