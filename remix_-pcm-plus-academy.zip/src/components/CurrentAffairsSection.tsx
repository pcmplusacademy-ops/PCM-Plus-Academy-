/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CurrentAffairsBulletin } from '../types';
import { SEED_CURRENT_AFFAIRS } from '../data';
import { Newspaper, Flame, Calendar, BookOpen, Clock, Heart, Share2, Check } from 'lucide-react';

interface CurrentAffairsProps {
  lang: 'en' | 'hi';
}

export default function CurrentAffairsSection({ lang }: CurrentAffairsProps) {
  const [activeFilter, setActiveFilter] = useState<'all' | 'daily' | 'weekly' | 'monthly'>('all');
  const [likedList, setLikedList] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Quick GK Quiz implementation embedded in current affairs tab
  const [selectedQuizIdx, setSelectedQuizIdx] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  const gkQuiz = {
    question: lang === 'hi' 
      ? "हाल ही में समाचारों में रहा 'आदित्य-L1' मिशन किससे संबंधित है?"
      : "The 'Aditya-L1' mission, recently in the news, is associated with studying which celestial body?",
    options: lang === 'hi'
      ? ["चंद्रमा", "मंगल ग्रह", "सूर्य (सौर वातावरण)", "बृहस्पति"]
      : ["Luna", "Mars", "Sun (Solar Core)", "Jupiter"],
    correctIdx: 2,
    explanation: lang === 'hi'
      ? "आदित्य-L1 मिशन भारतीय अंतरिक्ष अनुसंधान संगठन (ISRO) द्वारा सूर्य का अध्ययन करने वाला पहला वैज्ञानिक मिशन है।"
      : "Aditya-L1 is ISRO's primary sentinel mission positioned at Lagrangian Point L1 to survey solar storms and radiation coronal loops."
  };

  const filteredBulletins = SEED_CURRENT_AFFAIRS.filter(ca => {
    if (activeFilter === 'all') return true;
    return ca.type === activeFilter;
  });

  const handleCopyShare = (ca: CurrentAffairsBulletin) => {
    navigator.clipboard.writeText(`*${ca.title}*\n\n${ca.content}\n\nRead more at PCM Plus Academy!`);
    setCopiedId(ca.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const labels = {
    en: {
      headerTitle: "Daily Knowledge Bulletins",
      headerDesc: "Sushil Pandey Sir's concise national headlines and international developments curated for UPSC, SSC, and Banking candidates.",
      all: "All News",
      daily: "Daily Bulletins",
      weekly: "Weekly Summaries",
      monthly: "Monthly Magazines",
      quizHeader: "Daily General Knowledge Smart Quiz",
      quizBtn: "Register Choice",
      quizExpl: "Correct answer selected!",
      wrongQuiz: "Incorrect choice! Let's read the scientific explanation below:",
      socialShare: "WhatsApp Share Draft"
    },
    hi: {
      headerTitle: "दैनिक करंट अफेयर्स बुलेटिन",
      headerDesc: "यूपीएससी, एसएससी और बैंकिंग उम्मीदवारों के लिए सुशील पांडेय सर द्वारा चुनी गई महत्वपूर्ण राष्ट्रीय और अंतर्राष्ट्रीय जानकारियां।",
      all: "सभी ख़बरें",
      daily: "दैनिक बुलेटिन",
      weekly: "साप्ताहिक समीक्षा",
      monthly: "मासिक पत्रिकाएं",
      quizHeader: "दैनिक सामान्य ज्ञान स्मार्ट क्विज़",
      quizBtn: "अपना उत्तर चुनें",
      quizExpl: "बिल्कुल सही विकल्प!",
      wrongQuiz: "गलत विकल्प! आइए सुशील सर का विस्तृत हल देखें:",
      socialShare: "व्हाट्सएप पर साझा करें"
    }
  }[lang];

  return (
    <div id="current-affairs-root" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        {/* Header header info card */}
        <div className="bg-gradient-to-tr from-blue-900 to-indigo-950 p-6 rounded-2xl text-white shadow-xl relative overflow-hidden border border-amber-500/20">
          <div className="absolute right-0 bottom-0 opacity-15">
            <Newspaper className="h-44 w-44" />
          </div>
          <span className="bg-amber-500 text-white font-mono text-[9px] font-bold tracking-widest px-2.5 py-1 rounded shadow uppercase">
            LIVE GK FEED
          </span>
          <h3 className="text-xl font-outfit font-bold mt-2 leading-snug">{labels.headerTitle}</h3>
          <p className="text-xs text-slate-300 mt-1.5 leading-relaxed max-w-lg">{labels.headerDesc}</p>

          <div className="flex gap-2 mt-5 overflow-x-auto pb-1 scrollbar-none">
            {(['all', 'daily', 'weekly', 'monthly'] as const).map(f => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`text-[10px] uppercase font-bold px-3.5 py-1.5 rounded-lg border transition-all shrink-0 ${
                  activeFilter === f
                    ? 'bg-amber-500 text-white border-amber-500 shadow-md'
                    : 'bg-white/10 text-white/80 border-white/20 hover:bg-white/20'
                }`}
              >
                {labels[f]}
              </button>
            ))}
          </div>
        </div>

        {/* Dynamic news bulletins */}
        <div className="space-y-4">
          {filteredBulletins.map(ca => (
            <div
              key={ca.id}
              id={`bulletin-${ca.id}`}
              className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-3.5 hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-mono tracking-wider font-bold uppercase text-amber-600 bg-amber-500/5 px-2 py-0.5 rounded border border-amber-500/20">
                  {ca.type} Current Affairs
                </span>
                <div className="flex items-center space-x-1 text-[11px] text-slate-400">
                  <Calendar className="h-3.5 w-3.5" />
                  <span>{new Date(ca.publishedAt).toLocaleDateString()}</span>
                </div>
              </div>

              <h4 className="text-sm font-outfit font-bold text-slate-900 dark:text-white leading-relaxed">
                {ca.title}
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-sans">
                {ca.content}
              </p>

              <div className="flex justify-between items-center pt-3.5 border-t border-slate-50 dark:border-slate-800">
                <button
                  onClick={() => setLikedList({ ...likedList, [ca.id]: !likedList[ca.id] })}
                  className="flex items-center space-x-1.5 text-xs font-semibold text-slate-400 hover:text-red-500 transition-colors"
                >
                  <Heart className={`h-4.5 w-4.5 ${likedList[ca.id] ? 'fill-red-500 text-red-500' : ''}`} />
                  <span>Like Bulletin</span>
                </button>

                <button
                  onClick={() => handleCopyShare(ca)}
                  className="bg-slate-50 dark:bg-slate-850 hover:bg-slate-100 dark:hover:bg-slate-800 p-2 rounded-lg text-slate-500 dark:text-slate-400 hover:text-slate-800 transition-colors flex items-center space-x-1 text-xs font-bold border border-slate-105"
                >
                  {copiedId === ca.id ? (
                    <>
                      <Check className="h-4 w-4 text-green-500" />
                      <span className="text-green-600">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="h-4 w-4" />
                      <span>{labels.socialShare}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Daily General Knowledge Interactive Quiz Widget inside Right Column */}
      <div className="space-y-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-xl space-y-4">
          <div className="flex items-center space-x-2.5">
            <div className="bg-amber-100 dark:bg-amber-950 p-2 rounded-lg">
              <Flame className="h-4.5 w-4.5 text-amber-600" />
            </div>
            <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white">
              {labels.quizHeader}
            </h4>
          </div>

          <div className="p-3 bg-blue-950/5 rounded-xl border border-blue-900/10">
            <p className="text-xs font-medium text-slate-700 dark:text-slate-300 leading-relaxed">
              {gkQuiz.question}
            </p>
          </div>

          <div className="space-y-1.5 pt-1">
            {gkQuiz.options.map((option, idx) => {
              let btnStyle = "bg-slate-50 border-slate-200 hover:bg-slate-100 dark:bg-slate-800/60 dark:border-slate-750 dark:text-slate-300";
              if (selectedQuizIdx === idx) {
                btnStyle = "bg-blue-900 border-blue-900 text-white";
              }
              if (quizSubmitted) {
                if (idx === gkQuiz.correctIdx) {
                  btnStyle = "bg-green-100 border-green-500 text-green-800 dark:bg-green-950/40 dark:border-green-600 dark:text-green-300";
                } else if (selectedQuizIdx === idx) {
                  btnStyle = "bg-red-105 border-red-500 text-red-800 dark:bg-red-950/40 dark:border-red-900 dark:text-red-400";
                }
              }

              return (
                <button
                  key={idx}
                  disabled={quizSubmitted}
                  onClick={() => setSelectedQuizIdx(idx)}
                  className={`w-full text-left p-3 rounded-xl border text-xs font-semibold transition-colors ${btnStyle}`}
                >
                  {option}
                </button>
              );
            })}
          </div>

          {!quizSubmitted ? (
            <button
              disabled={selectedQuizIdx === null}
              onClick={() => setQuizSubmitted(true)}
              className="w-full bg-gradient-to-tr from-blue-900 to-indigo-900 hover:from-blue-950 text-white font-bold py-2.5 rounded-xl text-xs transition-colors shadow disabled:opacity-50"
            >
              Check Answer
            </button>
          ) : (
            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1 text-xs">
              <p className={`font-semibold ${selectedQuizIdx === gkQuiz.correctIdx ? 'text-green-600' : 'text-red-500'}`}>
                {selectedQuizIdx === gkQuiz.correctIdx ? labels.quizExpl : labels.wrongQuiz}
              </p>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed font-sans">{gkQuiz.explanation}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
