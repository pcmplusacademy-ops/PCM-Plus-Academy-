/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { SupportChatMessage, UserProfile } from '../types';
import { Send, Bot, User, Sparkles, X, MessageSquare, HelpCircle, Loader, Terminal } from 'lucide-react';

interface AiAssistantProps {
  currentUser: UserProfile | null;
  lang: 'en' | 'hi';
}

export default function AiAssistant({ currentUser, lang }: AiAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<SupportChatMessage[]>([
    {
      role: 'model',
      text: lang === 'hi' 
        ? "नमस्ते! मैं सुशील सर का पीसीएम प्लस एआई स्टडी असिस्टेंट हूँ। आज आप कौन सा विषय पढ़ना चाहते हैं?" 
        : "Hello! I am Sushil Sir's PCM Plus AI Study Assistant. What subject or concept would you like to master today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll on new messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputVal;
    if (!textToSend.trim()) return;

    if (!customText) {
      setInputVal('');
    }

    const userMsg: SupportChatMessage = {
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          userProfile: currentUser ? {
            name: currentUser.name,
            goal: currentUser.role === 'admin' ? 'Teaching' : 'Standard Exams'
          } : null
        })
      });

      if (!response.ok) {
        throw new Error("Local model query error");
      }

      const data = await response.json();
      const assistantMsg: SupportChatMessage = {
        role: 'model',
        text: data.reply || "I encountered a learning query break. Let's try another challenge!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      // Graceful local offline-fallback explanation
      const offlineMsg: SupportChatMessage = {
        role: 'model',
        text: lang === 'hi'
          ? "मुझे आपके प्रश्न का उत्तर देने में थोड़ी कठिनाई हो रही है। कृपया सुनिश्चित करें कि विकास सर्वर ठीक चल रहा है और जीमेल कुंजी (GEMINI_API_KEY) सक्रिय है!"
          : "I had a transient issue connecting to the learning pipeline. Ensure your GEMINI_API_KEY is supplied in the secrets menu!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, offlineMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const presetSuggestions = lang === 'hi' 
    ? [
        "स्थिरवैद्युतिकी (Electrostatics) का सूत्र समझाएं",
        "UPCS इतिहास उत्तर लेखन प्रारूप कैसा हो?",
        "HTML/CSS वेब डेवलपमेंट कैसे शुरू करें?"
      ]
    : [
        "Explain Gauss Law derivation clearly",
        "NEET Biology genetics important terms list",
        "Python function arguments with code sample"
      ];

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Floating launcher badge */}
      {!isOpen && (
        <button
          id="ai-assistant-launcher"
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-tr from-blue-900 via-blue-950 to-amber-600 text-white rounded-full p-4 shadow-2xl hover:scale-110 active:scale-95 transition-all duration-300 flex items-center justify-center border-2 border-amber-400 group relative"
        >
          <Bot className="h-6 w-6 text-white group-hover:rotate-12 transition-transform" />
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
          </span>
          <div className="absolute right-14 bg-slate-900 border border-slate-800 text-white text-xs px-3 py-1.5 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity font-medium shadow-xl">
            {lang === 'hi' ? 'सुशील सर एयर असिस्टेंट से पूछें!' : 'Ask Sushil Sir\'s AI Study Desk!'}
          </div>
        </button>
      )}

      {/* Main chat modal canvas */}
      {isOpen && (
        <div 
          id="ai-assistant-widget"
          className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-2xl w-96 max-w-[calc(100vw-2rem)] h-[550px] max-h-[80vh] flex flex-col overflow-hidden transition-all duration-300"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-900 via-blue-950 to-indigo-950 p-4 text-white flex justify-between items-center border-b border-amber-500/30">
            <div className="flex items-center space-x-2.5">
              <div className="bg-gradient-to-tr from-amber-400 to-amber-600 p-1.5 rounded-lg">
                <Bot className="h-5 w-5 text-blue-950" />
              </div>
              <div>
                <h4 className="font-outfit font-bold text-sm flex items-center gap-1">
                  PCM Plus AI Assistant
                  <Sparkles className="h-3.5 w-3.5 text-amber-400 animate-pulse" />
                </h4>
                <p className="text-[10px] text-slate-300">"Learn Today, Lead Tomorrow"</p>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-slate-300 hover:text-white p-1 hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Messages block */}
          <div className="flex-grow overflow-y-auto p-4 space-y-4 bg-slate-50 dark:bg-slate-950/40">
            {messages.map((m, idx) => (
              <div 
                key={idx} 
                className={`flex gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {m.role === 'model' && (
                  <div className="h-7 w-7 rounded-lg bg-blue-100 dark:bg-blue-900 flex items-center justify-center border border-blue-200 dark:border-blue-800 shrink-0">
                    <Bot className="h-4 w-4 text-blue-900 dark:text-blue-300" />
                  </div>
                )}
                
                <div className={`max-w-[75%] rounded-2xl p-3 text-xs leading-relaxed ${
                  m.role === 'user' 
                    ? 'bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-tr-none shadow-md shadow-blue-900/10'
                    : 'bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 text-slate-800 dark:text-slate-200 rounded-tl-none shadow-sm'
                }`}>
                  <p className="whitespace-pre-wrap">{m.text}</p>
                  <span className={`block text-[8px] text-right mt-1.5 ${m.role === 'user' ? 'text-blue-200' : 'text-slate-400'}`}>
                    {m.timestamp}
                  </span>
                </div>

                {m.role === 'user' && (
                  <div className="h-7 w-7 rounded-lg bg-amber-100 dark:bg-amber-950 flex items-center justify-center border border-amber-200 dark:border-amber-900 shrink-0">
                    <User className="h-4 w-4 text-amber-700 dark:text-amber-400" />
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-2.5 justify-start">
                <div className="h-7 w-7 rounded-lg bg-blue-100 dark:bg-blue-900 flex items-center justify-center border border-slate-200 dark:border-slate-800 animate-spin">
                  <Loader className="h-4 w-4 text-blue-900 dark:text-blue-300" />
                </div>
                <div className="max-w-[75%] rounded-2xl p-3 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-820 text-xs italic text-slate-500 rounded-tl-none">
                  {lang === 'hi' ? 'सुशील सर का सहायक सोच रहा है...' : 'Solving concept parameters...'}
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick presets area */}
          <div className="px-3 py-2 bg-slate-100/50 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-800/50 flex gap-1.5 overflow-x-auto whitespace-nowrap scrollbar-none">
            {presetSuggestions.map((ps, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(ps)}
                className="bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full px-3 py-1 text-[10px] font-medium border border-slate-200 dark:border-slate-700 hover:border-amber-500 hover:text-amber-500 dark:hover:text-amber-400 transition-colors shadow-sm shrink-0"
              >
                {ps}
              </button>
            ))}
          </div>

          {/* Input tray */}
          <div className="p-3 border-t border-slate-100 dark:border-slate-800 flex items-center bg-white dark:bg-slate-900 space-x-2">
            <input
              type="text"
              placeholder={lang === 'hi' ? 'भौतिकी, रसायन, सामान्य ज्ञान प्रश्न पूछें...' : 'Ask dynamic STEM & Competitive queries...'}
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-grow bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-blue-900 text-slate-800 dark:text-slate-200"
            />
            <button
              onClick={() => handleSendMessage()}
              className="bg-blue-900 hover:bg-blue-800 text-white rounded-xl p-2.5 transition-colors flex items-center justify-center"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
