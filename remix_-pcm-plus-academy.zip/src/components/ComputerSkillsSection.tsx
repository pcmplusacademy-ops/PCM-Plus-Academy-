/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Keyboard, Code, Sparkles, Terminal, Cpu, Copy, Check, Play, RefreshCw, 
  HelpCircle, Monitor, Info, ChevronRight, CheckCircle2, Sliders, Layers 
} from 'lucide-react';

interface ComputerSkillsProps {
  lang: 'en' | 'hi';
  currentUser?: any;
}

export default function ComputerSkillsSection({ lang, currentUser }: ComputerSkillsProps) {
  const [activeSubTab, setActiveSubTab] = useState<'shortcuts' | 'codelab' | 'prompt' | 'hardware'>('shortcuts');

  // Labels map
  const labels = {
    en: {
      headline: "PC & Code Lab Skills Center",
      subheadline: "Interactive training widgets for Office software, keyboard mastery, HTML/JS programming, and modern Prompt Engineering.",
      tabShortcuts: "Keyboard Shortcuts",
      tabCodeLab: "Web Coding Sandbox",
      tabPrompt: "AI Prompt Builder",
      tabHardware: "Hardware Diagram",
      copied: "Copied!",
      runCode: "Run Code",
      resetCode: "Reset Code"
    },
    hi: {
      headline: "पीसी और कोडिंग लैब स्किल्स सेंटर",
      subheadline: "कार्यालय सॉफ्टवेयर, कीबोर्ड शॉर्टकट, HTML/JS प्रोग्रामिंग, और आधुनिक प्रॉम्प्ट इंजीनियरिंग के लिए इंटरैक्टिव प्रशिक्षण सेट।",
      tabShortcuts: "कीबोर्ड शॉर्टकट्स",
      tabCodeLab: "वेब कोडिंग सैंडबॉक्स",
      tabPrompt: "AI प्रॉम्प्ट बिल्डर",
      tabHardware: "हार्डवेयर चित्र",
      copied: "कॉपी हो गया!",
      runCode: "कोड रन करें",
      resetCode: "रीसेट करें"
    }
  }[lang];

  // ---------------------------------------------------------
  // 1. KEYBOARD SHORTCUTS SUB-MODULE
  // ---------------------------------------------------------
  const SHORTCUT_GROUPS = [
    {
      id: 'word',
      name: lang === 'en' ? 'MS Word (Document Layouts)' : 'एमएस वर्ड (दस्तावेज़ संपादन)',
      shortcuts: [
        { keys: 'Ctrl + [', action: 'Decrease font size by 1 point', actionHi: 'फॉन्ट का आकार 1 पॉइंट घटाएं' },
        { keys: 'Ctrl + ]', action: 'Increase font size by 1 point', actionHi: 'फॉन्ट का आकार 1 पॉइंट बढ़ाएं' },
        { keys: 'Ctrl + E', action: 'Center align paragraph text', actionHi: 'पैराग्राफ टेक्स्ट को बीच में संरेखित करें' },
        { keys: 'Ctrl + J', action: 'Justify paragraph alignment', actionHi: 'पैराग्राफ को जस्टिफाई रूप में संरेखित करें' },
        { keys: 'Ctrl + K', action: 'Insert secure hyperlink link', actionHi: 'हाइपरलिंक या बाहरी लिंक जोड़ें' },
        { keys: 'Ctrl + Shift + C', action: 'Copy formatting only (Format Painter)', actionHi: 'फॉर्मेटिंग कॉपी करें (फॉर्मेट पेंटर)' }
      ]
    },
    {
      id: 'powerpoint',
      name: lang === 'en' ? 'MS PowerPoint (Slide Presentations)' : 'एमएस पावरपॉइंट (स्लाइड प्रस्तुति)',
      shortcuts: [
        { keys: 'F5', action: 'Start slide presentation from beginning', actionHi: 'प्रस्तुति को शुरुआत से शुरू करें' },
        { keys: 'Shift + F5', action: 'Start presentation from active slide', actionHi: 'सक्रिय स्लाइड से प्रस्तुति शुरू करें' },
        { keys: 'Ctrl + M', action: 'Insert a new presentation slide blank canvas', actionHi: 'एक नया खाली स्लाइड कैनवास डालें' },
        { keys: 'Ctrl + D', action: 'Duplicate selected presentation objects or slides', actionHi: 'चयनित स्लाइड या ऑब्जेक्ट की डुप्लिकेट कॉपी बनाएं' },
        { keys: 'B', action: 'Black out active screen during live presentation', actionHi: 'प्रस्तुति के दौरान सक्रिय स्क्रीन को ब्लैक करें' },
        { keys: 'W', action: 'White out active screen during live presentation', actionHi: 'प्रस्तुति के दौरान सक्रिय स्क्रीन को वाइट करें' }
      ]
    },
    {
      id: 'excel',
      name: lang === 'en' ? 'MS Excel (Essential Tools)' : 'एमएस एक्सेल (प्रमुख सूचक)',
      shortcuts: [
        { keys: 'Ctrl + ;', action: 'Insert current date', actionHi: 'वर्तमान तिथि दर्ज करें' },
        { keys: 'Ctrl + Shift + L', action: 'Apply / Remove spreadsheet Filters', actionHi: 'स्प्रेडशीट फिल्टर लागू करें/हटाएं' },
        { keys: 'F4', action: 'Cycle relative/absolute cell reference ($A$1)', actionHi: 'सेल संदर्भ ($A$1) को निरपेक्ष/सापेक्ष चक्रित करें' },
        { keys: 'Alt + =', action: 'Instant AutoSum adjacent column cells', actionHi: 'निकटवर्ती सेलों का त्वरित ऑटोसम' },
        { keys: 'Ctrl + T', action: 'Convert selection range to interactive Table', actionHi: 'चयनित रेंज को टेबल फॉर्मेट में बदलें' },
        { keys: 'Ctrl + Shift + $', action: 'Apply currency format with two decimals', actionHi: 'मुद्रा प्रारूप (दो दशमलव के साथ) लागू करें' }
      ]
    },
    {
      id: 'vscode',
      name: lang === 'en' ? 'VS Code & Coding' : 'वीएस कोड और प्रोग्रामिंग',
      shortcuts: [
        { keys: 'Ctrl + /', action: 'Toggle line comments', actionHi: 'लाइन कॉमेंट्स ऑन/ऑफ करें' },
        { keys: 'Alt + Up/Down', action: 'Move active line up or down', actionHi: 'सक्रिय लाइन को ऊपर या नीचे ले जाएं' },
        { keys: 'Ctrl + Space', action: 'Trigger IntelliSense code suggestions', actionHi: 'इंटेलिसेंस कोड सुझाव ट्रिगर करें' },
        { keys: 'Ctrl + P', action: 'Quick Open search library file directory', actionHi: 'फ़ाइल डायरेक्टरी त्वरित रूप से खोलें' },
        { keys: 'Ctrl + Shift + K', action: 'Delete entire active line', actionHi: 'पूरी सक्रिय लाइन मिटाएं' }
      ]
    },
    {
      id: 'windows',
      name: lang === 'en' ? 'Windows & General PC' : 'विंडोज और सामान्य पीसी',
      shortcuts: [
        { keys: 'Win + D', action: 'Minimize all and show Desktop', actionHi: 'सभी ऐप्स छुपाएं और डेस्कटॉप दिखाएं' },
        { keys: 'Win + Shift + S', action: 'Open snip screenshot selector', actionHi: 'स्क्रीनशॉट स्निप टूल खोलें' },
        { keys: 'Ctrl + Shift + Esc', action: 'Directly launch Windows Task Manager', actionHi: 'सीधे टास्क मैनेजर खोलें' },
        { keys: 'Win + L', action: 'Instantly lock operating system workstation', actionHi: 'कंप्यूटर को तुरंत लॉक करें' },
        { keys: 'Win + V', action: 'Access clipboard history memory panel', actionHi: 'क्लिपबोर्ड इतिहास का उपयोग करें' }
      ]
    }
  ];

  const [selectedGroup, setSelectedGroup] = useState<'excel' | 'word' | 'powerpoint' | 'vscode' | 'windows'>('excel');
  const [testMode, setTestMode] = useState(false);
  const [currentTestIndex, setCurrentTestIndex] = useState(0);
  const [selectedUserShortcutOption, setSelectedUserShortcutOption] = useState<string | null>(null);
  const [testScore, setTestScore] = useState(0);
  const [testFinished, setTestFinished] = useState(false);

  const activeShortcutsList = SHORTCUT_GROUPS.find(g => g.id === selectedGroup)?.shortcuts || [];

  // Generate multi-choice options for Shortcut Mock Test
  const getTestOptions = (correctKeys: string) => {
    const optionsSet = new Set<string>();
    optionsSet.add(correctKeys);
    
    // Fill up to 4 mock elements
    const allShortcutKeys = SHORTCUT_GROUPS.flatMap(g => g.shortcuts.map(s => s.keys));
    while(optionsSet.size < 4 && optionsSet.size < allShortcutKeys.length) {
      const idx = Math.floor(Math.random() * allShortcutKeys.length);
      optionsSet.add(allShortcutKeys[idx]);
    }
    return Array.from(optionsSet).sort(() => Math.random() - 0.5);
  };

  const handleTestAnswer = (opt: string) => {
    setSelectedUserShortcutOption(opt);
    const correctAns = activeShortcutsList[currentTestIndex]?.keys;
    if (opt === correctAns) {
      setTestScore(prev => prev + 1);
    }
  };

  const handleNextShortcutTest = () => {
    setSelectedUserShortcutOption(null);
    if (currentTestIndex + 1 < activeShortcutsList.length) {
      setCurrentTestIndex(prev => prev + 1);
    } else {
      setTestFinished(true);
    }
  };

  const resetShortcutTrial = () => {
    setCurrentTestIndex(0);
    setSelectedUserShortcutOption(null);
    setTestScore(0);
    setTestFinished(false);
    setTestMode(false);
  };


  // ---------------------------------------------------------
  // 2. WEB CODING SANDBOX SUB-MODULE
  // ---------------------------------------------------------
  const DEFAULT_HTML = `<div style="text-align: center; font-family: sans-serif; padding: 20px;">
  <!-- Try editing this code below and clicking 'Run Code'! -->
  <h2 style="color: #3b82f6; margin-bottom: 10px;">🌟 Hello World Sandbox 🌟</h2>
  <div style="background: linear-gradient(135deg, #1e3a8a, #3b82f6); color: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4); display: inline-block;">
    <h3 id="headline">PCM Plus Interactive Code</h3>
    <p style="font-size: 14px; opacity: 0.9;">Cultivating Scientific Inquiry under Sushil Pandey Sir's guidance.</p>
    <button onclick="showAlert()" style="background: #f59e0b; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: bold; cursor: pointer; transition: background 0.2s;">
      Click Me!
    </button>
  </div>
</div>

<script>
function showAlert() {
  const h = document.getElementById('headline');
  h.style.color = '#f59e0b';
  h.innerText = 'Interactive Action Complete!';
}
</script>`;

  const [sandboxCode, setSandboxCode] = useState(DEFAULT_HTML);
  const [outputIframeContent, setOutputIframeContent] = useState(DEFAULT_HTML);
  const [runSuccessBanner, setRunSuccessBanner] = useState(false);

  const handleRunCode = () => {
    setOutputIframeContent(sandboxCode);
    setRunSuccessBanner(true);
    setTimeout(() => setRunSuccessBanner(false), 2000);
  };

  const loadCodingSnippet = (type: 'card' | 'gradient' | 'table') => {
    let codeStr = '';
    if (type === 'card') {
      codeStr = `<div style="padding: 24px; background: #0f172a; color: #f8fafc; border: 1px solid #1e293b; border-radius: 16px; font-family: system-ui;">
  <span style="background: rgba(245, 158, 11, 0.2); color: #f59e0b; font-size: 11px; padding: 4px 8px; border-radius: 99px; text-transform: uppercase; font-weight: bold;">Computer Science</span>
  <h3 style="margin-top: 10px; font-size: 20px;">Dynamic UI Glow Card</h3>
  <p style="color: #94a3b8; font-size: 13px;">This clean layout represents structural glassmorphism.</p>
</div>`;
    } else if (type === 'gradient') {
      codeStr = `<div style="height: 150px; background: linear-gradient(to right, #ec4899, #8b5cf6, #3b82f6); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-family: system-ui; box-shadow: 0 4px 20px rgba(139, 92, 246, 0.45);">
  <h2 style="color: white; font-size: 24px; text-shadow: 1px 1px 4px rgba(0,0,0,0.3);">Colorful Mesh Background</h2>
</div>`;
    } else {
      codeStr = `<table style="width: 100%; border-collapse: collapse; font-family: system-ui; font-size: 13px;">
  <tr style="background: #1e3a8a; color: white;">
    <th style="padding: 10px; text-align: left;">Algorithm</th>
    <th style="padding: 10px; text-align: left;">Time Complexity</th>
    <th style="padding: 10px; text-align: left;">Best Scenario</th>
  </tr>
  <tr style="border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
    <td style="padding: 10px; font-weight: bold;">Binary Search</td>
    <td style="padding: 10px; font-family: monospace;">O(log N)</td>
    <td style="padding: 10px; color: green;">Sorted Lists</td>
  </tr>
  <tr style="border-bottom: 1px solid #e2e8f0;">
    <td style="padding: 10px; font-weight: bold;">Quick Sort</td>
    <td style="padding: 10px; font-family: monospace;">O(N log N)</td>
    <td style="padding: 10px; color: green;">Random Pivoted Array</td>
  </tr>
</table>`;
    }
    setSandboxCode(codeStr);
    setOutputIframeContent(codeStr);
  };


  // ---------------------------------------------------------
  // 3. AI PROMPT ENGINEERING BUILDER SUB-MODULE
  // ---------------------------------------------------------
  const [promptRole, setPromptRole] = useState('Physics Study Partner');
  const [promptQuality, setPromptQuality] = useState('Highly technical with formula breakdowns & real-world metaphors');
  const [promptGoal, setPromptGoal] = useState('');
  const [promptFormat, setPromptFormat] = useState('Step-by-step numbered guide with code snippets/tables');
  const [copyFeedback, setCopyFeedback] = useState(false);

  const rolesCatalog = [
    { name: 'Physics Study Partner', desc: 'Expert physics tutor with clear mathematical intuition' },
    { name: 'Excel Formula Wizard', desc: 'Prepares formulas, spreadsheets templates, and visual sheets' },
    { name: 'UPSC Mains Evaluator', desc: 'Gives rigid point-by-point critique of competitive answers' },
    { name: 'JavaScript Code Mentor', desc: 'Offers clean, performant React/JS logic scripts with comments' }
  ];

  const generatedPromptValue = `ACT AS A ${promptRole.toUpperCase()}:
[CONSTRAINTS & QUALITY]: You must write in a ${promptQuality} tone.
[MY OBJECTIVE]: Learn or complete this specific query: "${promptGoal || 'Explain the core mechanics of this topic'}"
[OUTPUT FORMAT MANDATE]: Please respond using format - ${promptFormat}.
Include clear real-world representations, common Student Pitfalls, and 1 core testing diagnostic metric question at the end to check my model's understanding. Ensure top clarity under code PCM-PLUS.`;

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(generatedPromptValue);
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2000);
  };


  // ---------------------------------------------------------
  // 4. HARDWARE COMPONENT HOVER VISUALIZER SUB-MODULE
  // ---------------------------------------------------------
  const [selectedHardware, setSelectedHardware] = useState<string | null>('cpu');

  const HARDWARE_PARTS = [
    {
      id: 'cpu',
      name: 'CPU (Central Processing Unit)',
      role: 'The primary electronic brain of the machine. Decodes numerical binary calculations and manages micro-signals across all connected systems.',
      benchmark: 'Measured in GHz & Multi-core Threading efficiency'
    },
    {
      id: 'ram',
      name: 'RAM (Random Access Memory)',
      role: 'High-speed temporary volatile cash desk. Holds operating memory and code active streams for instant retrieval by the CPU.',
      benchmark: 'DDR4 or DDR5 specifications (Measured in Gigabytes)'
    },
    {
      id: 'ssd',
      name: 'SSD (Solid State Drive)',
      role: 'High speed permanent storage device. Uses integrated circuit flash memory chips to load OS boot files and software suites instantly without moving mechanical platters.',
      benchmark: 'NVMe M.2 connectivity on PCIe Gen4 lanes'
    },
    {
      id: 'gpu',
      name: 'GPU (Graphics Processing Unit)',
      role: 'Highly parallel mathematical array processor. Responsible for physical rendering arrays, video outputs, high frame-rate rendering, and AI neural net training operations.',
      benchmark: 'Core counts, VRAM specifications, and Tensor units'
    },
    {
      id: 'motherboard',
      name: 'Motherboard',
      role: 'Central highway registry. The primary printed-circuit board that routes communication signals, high speed power lanes, and holds structural sockets.',
      benchmark: 'Chipsets, PCI slots, RAM DIMM limits, and power VRMs'
    }
  ];

  const hardwareDetail = HARDWARE_PARTS.find(part => part.id === selectedHardware) || HARDWARE_PARTS[0];

  return (
    <div id="comp-skills-view-wrapper" className="space-y-8 animate-fade-in">
      
      {/* Visual Header */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-slate-850 p-6 sm:p-8 rounded-2xl shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <div className="inline-flex items-center space-x-1.5 bg-amber-500/10 text-amber-500 border border-amber-500/25 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-2">
            <Monitor className="h-3 w-3" />
            <span>Practical IT Syllabi</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-outfit text-white tracking-tight flex items-center gap-2">
            <span>{labels.headline}</span>
            <Sparkles className="h-4.5 w-4.5 text-amber-400 animate-pulse" />
          </h2>
          <p className="text-xs text-slate-400 max-w-xl mt-1 leading-relaxed">
            {labels.subheadline}
          </p>
        </div>

        {/* Live Lab Stats info banner */}
        <div className="p-3.5 bg-slate-900/80 rounded-xl border border-slate-800 text-right select-none hidden sm:block shrink-0">
          <p className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">Active Laboratory Nodes</p>
          <p className="text-xs font-semibold text-white mt-1">4 Advanced Units Loaded</p>
          <span className="text-[9px] text-green-400 font-bold tracking-wider font-mono">● OFFLINE SECURED SYSTEM</span>
        </div>
      </div>

      {/* Sub navigation bar row inside the component */}
      <div className="flex bg-slate-200/60 dark:bg-slate-900/60 p-1 rounded-2xl border border-slate-300/40 dark:border-slate-800 tracking-wide overflow-x-auto gap-1">
        <button
          onClick={() => setActiveSubTab('shortcuts')}
          className={`flex items-center gap-1.5 text-xs font-bold px-4 py-2.5 rounded-xl transition-all whitespace-nowrap outline-none ${
            activeSubTab === 'shortcuts'
              ? 'bg-blue-900 text-white dark:bg-amber-500 dark:text-slate-950 shadow-md scale-102'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300/30 dark:hover:bg-slate-800/50'
          }`}
        >
          <Keyboard className="h-4 w-4" />
          <span>{labels.tabShortcuts}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('codelab')}
          className={`flex items-center gap-1.5 text-xs font-bold px-4 py-2.5 rounded-xl transition-all whitespace-nowrap outline-none ${
            activeSubTab === 'codelab'
              ? 'bg-blue-900 text-white dark:bg-amber-500 dark:text-slate-950 shadow-md scale-102'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300/30 dark:hover:bg-slate-800/50'
          }`}
        >
          <Code className="h-4 w-4" />
          <span>{labels.tabCodeLab}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('prompt')}
          className={`flex items-center gap-1.5 text-xs font-bold px-4 py-2.5 rounded-xl transition-all whitespace-nowrap outline-none ${
            activeSubTab === 'prompt'
              ? 'bg-blue-900 text-white dark:bg-amber-500 dark:text-slate-950 shadow-md scale-102'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300/30 dark:hover:bg-slate-800/50'
          }`}
        >
          <Sliders className="h-4 w-4" />
          <span>{labels.tabPrompt}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('hardware')}
          className={`flex items-center gap-1.5 text-xs font-bold px-4 py-2.5 rounded-xl transition-all whitespace-nowrap outline-none ${
            activeSubTab === 'hardware'
              ? 'bg-blue-900 text-white dark:bg-amber-500 dark:text-slate-950 shadow-md scale-102'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300/30 dark:hover:bg-slate-800/50'
          }`}
        >
          <Cpu className="h-4 w-4" />
          <span>{labels.tabHardware}</span>
        </button>
      </div>


      {/* ---------------------------------------------------------
          SUBTAB 1: KEYBOARD SHORTCUTS TRAINER
      --------------------------------------------------------- */}
      {activeSubTab === 'shortcuts' && (
        <div id="sub-shortcuts-module" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Shortcuts viewer & Group toggles */}
          <div className="lg:col-span-7 col-span-1 border border-slate-150 dark:border-slate-800/70 p-6 bg-white dark:bg-slate-900 rounded-2xl shadow-md space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h4 className="font-outfit font-bold text-sm sm:text-base text-slate-850 dark:text-white flex items-center gap-1.5">
                  <Keyboard className="h-5 w-5 text-amber-500" />
                  <span>Choose Professional Tool</span>
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Learn direct core speedrun keys on PC software.</p>
              </div>

              {/* Group Buttons */}
              <div className="flex bg-slate-100 dark:bg-slate-950 p-1 rounded-xl border border-slate-150 dark:border-slate-800 font-mono text-[10px] uppercase overflow-x-auto whitespace-nowrap">
                {SHORTCUT_GROUPS.map(grp => (
                  <button
                    key={grp.id}
                    onClick={() => { setSelectedGroup(grp.id as any); resetShortcutTrial(); }}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                      selectedGroup === grp.id
                        ? 'bg-slate-800 text-white dark:bg-amber-500 dark:text-slate-950 shadow-md'
                        : 'text-slate-500 hover:text-slate-700 dark:hover:text-amber-200'
                    }`}
                  >
                    {grp.id}
                  </button>
                ))}
              </div>
            </div>

            {/* List block */}
            <div className="space-y-3 pt-2">
              {activeShortcutsList.map((sc, i) => (
                <div 
                  key={i} 
                  className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-950 hover:bg-slate-100/40 dark:hover:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-xl"
                >
                  <div>
                    <h5 className="text-xs font-bold text-slate-850 dark:text-slate-100">
                      {lang === 'en' ? sc.action : sc.actionHi}
                    </h5>
                  </div>
                  <kbd className="bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-[11px] font-mono px-3 py-1 rounded-lg font-bold text-slate-700 dark:text-slate-100 shadow-sm flex items-center whitespace-nowrap">
                    {sc.keys}
                  </kbd>
                </div>
              ))}
            </div>

            <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-xl flex items-start gap-2 text-xs">
              <Info className="h-4.5 w-4.5 text-amber-500 shrink-0 mt-0.5" />
              <p className="text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed">
                {lang === 'en' 
                  ? "Keyboard shortcuts are requested in state recruitment Exams (like SSC CGL, Banking, O-Level Computer, CCC, Railways). Pro tip: practice these combinations on a real keyboard daily!"
                  : "कंप्यूटर कीबोर्ड शॉर्टकट्स का उपयोग प्रमुख प्रतियोगी परीक्षाओं (जैसे SSC, बैंकिंग, CCC, रेलवे और O-Level) में अनिवार्य रूप से पूछा जाता है। इन्हें स्मरण कर अपने प्रदर्शन को बेहतर बनाएं।"}
              </p>
            </div>
          </div>

          {/* Shortcuts interactive Mock Tester */}
          <div className="lg:col-span-5 col-span-1 border border-slate-150 dark:border-slate-800/70 p-6 bg-slate-50 dark:bg-slate-950 rounded-2xl shadow-md space-y-4">
            <div className="border-b border-slate-205 dark:border-slate-805 pb-3">
              <h4 className="font-outfit font-bold text-sm sm:text-base text-slate-905 dark:text-white flex items-center gap-1.5">
                <Terminal className="h-5 w-5 text-green-400" />
                <span>Interactive Shortcut Simulator</span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">Take active tests to prove your computer literacy.</p>
            </div>

            {!testMode ? (
              <div className="text-center py-10 space-y-4">
                <div className="h-14 w-14 bg-amber-500/15 text-amber-500 rounded-full flex items-center justify-center mx-auto border border-amber-500/25">
                  <Keyboard className="h-6 w-6" />
                </div>
                <div>
                  <h5 className="font-bold text-sm text-slate-800 dark:text-white">Active Test: {SHORTCUT_GROUPS.find(g => g.id === selectedGroup)?.name}</h5>
                  <p className="text-xs text-slate-500 mt-1">{activeShortcutsList.length} Questions on command speed keys.</p>
                </div>
                <button
                  onClick={() => { setTestMode(true); setCurrentTestIndex(0); setTestScore(0); setTestFinished(false); }}
                  className="bg-blue-900 border border-blue-950 hover:bg-blue-950 dark:bg-amber-500 dark:hover:bg-amber-600 hover:scale-103 dark:text-slate-900 font-bold text-xs px-5 py-2.5 rounded-xl transition-all"
                >
                  Start Assessment Now!
                </button>
              </div>
            ) : testFinished ? (
              <div className="text-center py-8 space-y-4">
                <div className="h-14 w-14 bg-green-500/10 text-green-400 rounded-full flex items-center justify-center mx-auto border border-green-500/25">
                  <CheckCircle2 className="h-6 w-6" />
                </div>
                <div>
                  <h5 className="font-bold text-sm text-slate-800 dark:text-white">Assessment Completed!</h5>
                  <p className="text-xs text-slate-500 mt-1">
                    Your final score is <span className="text-amber-500 font-bold">{testScore}</span> out of {activeShortcutsList.length}.
                  </p>
                </div>

                {/* Score rating feedback text */}
                <span className="text-[11px] font-mono tracking-widest text-[#f59e0b] block uppercase">
                  {testScore === activeShortcutsList.length ? '🌟 EXCELLENT KEYBOARD PRO!' : '👍 GREAT TRY, LOG GAPS REPEATED!'}
                </span>

                <div className="flex gap-2 justify-center pt-2">
                  <button
                    onClick={resetShortcutTrial}
                    className="bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs px-4 py-2 font-bold rounded-lg hover:bg-slate-300/60"
                  >
                    Back to List
                  </button>
                  <button
                    onClick={() => { setTestFinished(false); setCurrentTestIndex(0); setTestScore(0); }}
                    className="bg-amber-500 text-slate-950 text-xs px-4 py-2 font-bold rounded-lg hover:bg-amber-600"
                  >
                    Retry Assessment
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-between items-center text-[10px] font-semibold text-slate-400 font-mono">
                  <span>QUESTION {currentTestIndex + 1} OF {activeShortcutsList.length}</span>
                  <span className="text-green-500 text-right">Correct: {testScore}</span>
                </div>

                <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-150 dark:border-slate-800 space-y-1">
                  <span className="text-[9px] uppercase font-bold text-amber-500 block">Identify Keyboard Command keys for:</span>
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {lang === 'en' 
                      ? activeShortcutsList[currentTestIndex]?.action 
                      : activeShortcutsList[currentTestIndex]?.actionHi}
                  </p>
                </div>

                {/* Options list */}
                <div className="grid grid-cols-1 gap-2.5 pt-2">
                  {getTestOptions(activeShortcutsList[currentTestIndex]?.keys).map((opt) => {
                    const isSelected = selectedUserShortcutOption === opt;
                    const isCorrect = opt === activeShortcutsList[currentTestIndex]?.keys;
                    
                    let bgStyle = "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800";
                    if (selectedUserShortcutOption) {
                      if (isSelected) {
                        bgStyle = isCorrect
                          ? "bg-green-500/15 border-green-500 text-green-600 dark:text-green-400"
                          : "bg-red-500/15 border-red-500 text-red-600 dark:text-red-400";
                      } else if (isCorrect) {
                        bgStyle = "bg-green-500/15 border-green-500 text-green-600 dark:text-green-400";
                      }
                    }

                    return (
                      <button
                        key={opt}
                        disabled={selectedUserShortcutOption !== null}
                        onClick={() => handleTestAnswer(opt)}
                        className={`text-left p-3 rounded-xl border text-xs font-mono font-bold transition-all focus:outline-none flex justify-between items-center ${bgStyle}`}
                      >
                        <span>{opt}</span>
                        {selectedUserShortcutOption && isCorrect && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                      </button>
                    );
                  })}
                </div>

                {selectedUserShortcutOption && (
                  <button
                    onClick={handleNextShortcutTest}
                    className="w-full bg-blue-900 dark:bg-amber-500 hover:bg-slate-900 text-white dark:text-slate-950 font-bold p-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5"
                  >
                    <span>{currentTestIndex + 1 === activeShortcutsList.length ? 'View Final Score' : 'Next Question'}</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}


      {/* ---------------------------------------------------------
          SUBTAB 2: CODING SANDBOX (HTML/CSS VIEW)
      --------------------------------------------------------- */}
      {activeSubTab === 'codelab' && (
        <div id="sub-codelab-module" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Code Editor block */}
          <div className="lg:col-span-6 col-span-1 border border-slate-150 dark:border-slate-800/70 bg-white dark:bg-slate-900 rounded-2xl shadow-md p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h4 className="font-outfit font-bold text-sm sm:text-base text-slate-850 dark:text-white flex items-center gap-2">
                  <Code className="h-5 w-5 text-blue-500" />
                  <span>Interactive HTML & Inline-CSS Code Editor</span>
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Write custom markup or pick quick templates.</p>
              </div>

              <div className="flex gap-1">
                <button
                  onClick={() => setSandboxCode(DEFAULT_HTML)}
                  className="p-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-950 hover:dark:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-400 hover:text-amber-500 transition-colors"
                  title="Reset base code"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Quick Template Insert links */}
            <div className="flex flex-wrap gap-2 text-[10px] bg-slate-50 dark:bg-slate-950 p-2.5 rounded-xl border border-slate-150 dark:border-slate-800">
              <span className="text-slate-400 pr-1 select-none font-mono font-bold self-center">Templates:</span>
              <button 
                onClick={() => loadCodingSnippet('card')} 
                className="bg-white dark:bg-slate-800 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 hover:border-amber-400 font-bold"
              >
                Glowing Card
              </button>
              <button 
                onClick={() => loadCodingSnippet('gradient')} 
                className="bg-white dark:bg-slate-800 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 hover:border-amber-400 font-bold"
              >
                Mesh Gradient
              </button>
              <button 
                onClick={() => loadCodingSnippet('table')} 
                className="bg-white dark:bg-slate-800 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 hover:border-amber-400 font-bold"
              >
                Data Table Struct
              </button>
            </div>

            {/* Code Textarea field */}
            <div className="relative font-mono text-xs">
              <textarea
                value={sandboxCode}
                onChange={(e) => setSandboxCode(e.target.value)}
                rows={13}
                className="w-full bg-slate-950 text-emerald-400 border border-slate-800 p-4 rounded-xl leading-relaxed font-mono focus:outline-none focus:ring-1 focus:ring-amber-500 outline-none scrollbar-thin shadow-inner block"
                spellCheck="false"
              />
            </div>

            {/* Run Button triggers with success sound effect mock */}
            <div className="flex items-center justify-between">
              <p className="text-[10px] text-slate-400 italic">Pre-loaded with CSS custom variables.</p>
              
              <div className="flex gap-2">
                <button
                  onClick={handleRunCode}
                  className="bg-green-600 hover:bg-green-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-1"
                >
                  <Play className="h-3.5 w-3.5" />
                  <span>{labels.runCode}</span>
                </button>
              </div>
            </div>

            {runSuccessBanner && (
              <div className="p-2.5 bg-green-500/10 border border-green-500/20 text-green-500 text-[11px] font-semibold rounded-xl text-center flex items-center justify-center gap-1 animate-pulse">
                <CheckCircle2 className="h-4 w-4" />
                <span>Compiler completed successfully. Render updated below!</span>
              </div>
            )}
          </div>

          {/* Sandbox live Render screen */}
          <div className="lg:col-span-6 col-span-1 border border-slate-150 dark:border-slate-800/70 bg-white dark:bg-slate-900 rounded-2xl shadow-md p-6 flex flex-col justify-between">
            <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
              <h4 className="font-outfit font-bold text-sm text-slate-850 dark:text-white flex items-center gap-1.5">
                <Monitor className="h-4.5 w-4.5 text-amber-500 animate-pulse" />
                <span>HTML/CSS Sandboxed Render Output Screen</span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">Real-time localized container frame visualization.</p>
            </div>

            {/* Visual Screen frame block */}
            <div className="my-4 flex-grow bg-slate-50 dark:bg-slate-950 border-2 border-dashed border-slate-205 dark:border-slate-805 rounded-xl min-h-[300px] flex flex-col relative overflow-hidden">
              <iframe
                id="sandbox-render-iframe"
                title="Sushil Sir Code Lab Render Output"
                sandbox="allow-scripts"
                srcDoc={outputIframeContent}
                className="w-full flex-grow border-none focus:outline-none bg-white font-sans"
              />
            </div>

            <div className="p-3 bg-blue-500/5 rounded-xl border border-blue-500/10 text-[10px] text-slate-400 leading-relaxed flex gap-2">
              <Info className="h-4 w-4 text-blue-500 shrink-0 mt-0.5" />
              <p>
                Sushil Sir’s Academy utilizes secure front-end HTML frameworks. By testing inline styles and script triggers, students grasp physical structure and logical instructions simultaneously.
              </p>
            </div>
          </div>
        </div>
      )}


      {/* ---------------------------------------------------------
          SUBTAB 3: AI PROMPT CONSTRUCTOR ENGINE
      --------------------------------------------------------- */}
      {activeSubTab === 'prompt' && (
        <div id="sub-prompt-module" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Parameter Tuning panel */}
          <div className="lg:col-span-6 col-span-1 border border-slate-150 dark:border-slate-800/70 p-6 bg-white dark:bg-slate-900 rounded-2xl shadow-md space-y-5">
            <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
              <h4 className="font-outfit font-bold text-sm sm:text-base text-slate-850 dark:text-white flex items-center gap-2">
                <Sliders className="h-5 w-5 text-amber-500 animate-spin-slow" />
                <span>Configure Prompt Variables</span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">Optimize model responses by specifying perfect context parameters.</p>
            </div>

            <div className="space-y-4">
              {/* Persona selection dropdown matrix */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-350 mb-1.5 uppercase tracking-wide">
                  1. Target System Persona
                </label>
                <div className="grid grid-cols-2 gap-2 text-[11px] font-medium">
                  {rolesCatalog.map(role => (
                    <button
                      key={role.name}
                      onClick={() => setPromptRole(role.name)}
                      className={`text-left p-2.5 rounded-xl border transition-all ${
                        promptRole === role.name
                          ? 'border-amber-500 bg-amber-500/5 text-amber-600 dark:text-amber-400 font-bold'
                          : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:border-slate-300'
                      }`}
                    >
                      <span>{role.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Targeted Study Goal Input */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-350 mb-1.5 uppercase tracking-wide">
                  2. Scholastic Subject Goal
                </label>
                <input
                  type="text"
                  placeholder="e.g. Derive Coulomb Law in dielectric constant sheets"
                  value={promptGoal}
                  onChange={(e) => setPromptGoal(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-202 dark:border-slate-802 p-2.5 rounded-xl text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              {/* Target Quality Output tone option */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-350 mb-1.5 uppercase tracking-wide">
                  3. Content Detail constraints
                </label>
                <select
                  value={promptQuality}
                  onChange={(e) => setPromptQuality(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-202 dark:border-slate-802 p-2.5 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none"
                >
                  <option value="Highly technical with formula breakdowns & real-world metaphors">Highly technical with formula breakdowns & real-world metaphors</option>
                  <option value="Simple conversational explanations for complete absolute beginners">Simple conversational explanations for complete absolute beginners</option>
                  <option value="Critically dry and structure-oriented for India civil exams">Critically dry and structure-oriented for India civil exams</option>
                  <option value="Only clean boilerplate modules with descriptive inline code comments">Only clean boilerplate modules with descriptive inline code comments</option>
                </select>
              </div>

              {/* Formatting Mandates options */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-350 mb-1.5 uppercase tracking-wide">
                  4. Output Format
                </label>
                <input
                  type="text"
                  value={promptFormat}
                  onChange={(e) => setPromptFormat(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-202 dark:border-slate-802 p-2.5 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Prompt result & clipboard */}
          <div className="lg:col-span-6 col-span-1 border border-slate-150 dark:border-slate-800/70 p-6 bg-slate-50 dark:bg-slate-950 rounded-2xl shadow-md flex flex-col justify-between">
            <div className="pb-3 border-b border-slate-200 dark:border-slate-850 flex justify-between items-center">
              <div>
                <h4 className="font-outfit font-bold text-sm text-slate-850 dark:text-white flex items-center gap-1.5">
                  <Sparkles className="h-4.5 w-4.5 text-amber-500" />
                  <span>Interactive Compiled LLM Prompt</span>
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Use this prompt inside ChatGPT or Google Gemini to fetch high precision responses.</p>
              </div>

              <button
                onClick={handleCopyPrompt}
                className="p-1.5 bg-white dark:bg-slate-900 hover:bg-slate-100 hover:dark:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-500 hover:text-amber-500 flex items-center gap-1 text-[11px] font-bold shadow duration-150"
              >
                {copyFeedback ? <Check className="h-3.5 w-3.5 text-green-500" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copyFeedback ? labels.copied : 'Copy'}</span>
              </button>
            </div>

            {/* Generated display workspace */}
            <div className="my-4 flex-grow bg-slate-950 text-amber-400 border border-slate-850 p-4 rounded-xl leading-relaxed text-xs font-mono scrollbar-none whitespace-pre-wrap select-all">
              {generatedPromptValue}
            </div>

            <div className="p-3 bg-orange-105 rounded-xl border border-orange-500/10 text-[10px] text-orange-850 dark:text-orange-400 leading-relaxed font-sans flex gap-2">
              <Info className="h-4 w-4 shrink-0 mt-0.5" />
              <p>
                Prompt Engineering is a primary computer course tool in 2026. Structuring objectives, system constraints, format mandates and checks protects models from hallucinations.
              </p>
            </div>
          </div>
        </div>
      )}


      {/* ---------------------------------------------------------
          SUBTAB 4: HARDWARE COMPONENT DIAGRAM EXPLORER
      --------------------------------------------------------- */}
      {activeSubTab === 'hardware' && (
        <div id="sub-hardware-module" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Interactive visual layout diagram */}
          <div className="lg:col-span-6 col-span-1 border border-slate-150 dark:border-slate-800/70 p-6 bg-white dark:bg-slate-900 rounded-2xl shadow-md space-y-4">
            <div>
              <h4 className="font-outfit font-bold text-sm sm:text-base text-slate-850 dark:text-white flex items-center gap-2">
                <Cpu className="h-5 w-5 text-indigo-500" />
                <span>Interative Motherboard & Hardware Topology map</span>
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">Click core electronic chips to discover their functional computing metrics.</p>
            </div>

            {/* Simulated interactive physical board layout */}
            <div className="relative bg-slate-950 rounded-2xl aspect-video border border-slate-850 p-8 flex flex-col justify-between overflow-hidden select-none">
              
              {/* Overlay styling elements */}
              <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:16px_16px]" />
              <div className="absolute top-2 right-2 text-[8px] font-mono text-slate-500">PCM_BOARD_V2.1</div>

              {/* Grid map with hotspots */}
              <div className="relative h-full w-full grid grid-cols-12 grid-rows-6 gap-2">
                
                {/* 1. CPU Heat Sink Spot */}
                <div 
                  onClick={() => setSelectedHardware('cpu')}
                  className={`col-span-4 row-span-4 col-start-2 row-start-2 rounded-xl flex flex-col items-center justify-center cursor-pointer transition-all border-2 ${
                    selectedHardware === 'cpu' 
                      ? 'border-amber-500 bg-amber-500/10 shadow-[0_0_15px_rgba(245,158,11,0.25)] scale-102' 
                      : 'border-slate-800 bg-slate-900 hover:border-slate-600'
                  }`}
                >
                  <Cpu className="h-7 w-7 text-amber-500" />
                  <span className="text-[9px] font-bold font-mono tracking-widest uppercase mt-1 text-slate-300">PROCESSOR</span>
                </div>

                {/* 2. RAM Dimm spots */}
                <div 
                  onClick={() => setSelectedHardware('ram')}
                  className={`col-span-2 row-span-4 col-start-7 row-start-2 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-all border ${
                    selectedHardware === 'ram' 
                      ? 'border-amber-500 bg-amber-500/10 scale-102 font-bold' 
                      : 'border-slate-805 bg-slate-905 hover:border-slate-600'
                  }`}
                >
                  <div className="w-1.5 h-16 bg-slate-700 rounded-full shrink-0 flex flex-col justify-between p-0.5">
                    <div className="h-3 w-full bg-amber-400 rounded-full" />
                    <div className="h-3 w-full bg-amber-400 rounded-full" />
                  </div>
                  <span className="text-[8px] font-mono tracking-widest mt-1 text-slate-300">DIMM_RAM</span>
                </div>

                {/* 3. PCIe NVMe SSD Spot */}
                <div 
                  onClick={() => setSelectedHardware('ssd')}
                  className={`col-span-4 row-span-2 col-start-8 row-start-2 rounded-lg flex items-center justify-center gap-2 cursor-pointer transition-all border ${
                    selectedHardware === 'ssd' 
                      ? 'border-amber-500 bg-amber-500/10 scale-102 font-bold' 
                      : 'border-slate-800 bg-slate-900 hover:border-slate-600'
                  }`}
                >
                  <Layers className="h-5 w-5 text-indigo-400" />
                  <span className="text-[8px] font-mono uppercase tracking-widest text-slate-300">M.2 SSD ROM</span>
                </div>

                {/* 4. GPU Peripheral Slot */}
                <div 
                  onClick={() => setSelectedHardware('gpu')}
                  className={`col-span-10 row-span-1 col-start-2 row-start-6 rounded-lg flex items-center justify-center gap-2 cursor-pointer transition-all border ${
                    selectedHardware === 'gpu' 
                      ? 'border-amber-500 bg-amber-500/10 scale-102 font-bold' 
                      : 'border-slate-800 bg-slate-900 hover:border-slate-600'
                  }`}
                >
                  <Monitor className="h-4.5 w-4.5 text-blue-400" />
                  <span className="text-[8px] font-mono uppercase tracking-widest text-slate-300">PCI Express Graphics slot</span>
                </div>

                {/* 5. Motherboard Chips */}
                <div 
                  onClick={() => setSelectedHardware('motherboard')}
                  className={`col-span-2 row-span-2 col-start-10 row-start-4 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-all border ${
                    selectedHardware === 'motherboard' 
                      ? 'border-amber-500 bg-amber-500/10 scale-102 font-bold' 
                      : 'border-slate-800 bg-slate-900 hover:border-slate-600'
                  }`}
                >
                  <div className="p-1 text-[8px] font-mono uppercase tracking-tight text-slate-400">CHIPST</div>
                </div>

              </div>
            </div>
          </div>

          {/* Informational description panel */}
          <div className="lg:col-span-6 col-span-1 border border-slate-150 dark:border-slate-800/70 p-6 bg-slate-50 dark:bg-slate-950 rounded-2xl shadow-md flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-[9px] uppercase font-mono tracking-widest text-amber-500 font-bold block">
                COMPUTING DIAGNOSTICS & HARDWARE MATRIX
              </span>
              <h4 className="text-lg font-bold text-slate-900 dark:text-white font-outfit border-b border-slate-200 dark:border-slate-850 pb-2">
                {hardwareDetail.name}
              </h4>
              
              <div className="space-y-4 pt-2">
                <div>
                  <span className="text-[10px] uppercase font-mono text-slate-400 block font-bold">Primary Function</span>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-sans mt-0.5">
                    {hardwareDetail.role}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] uppercase font-mono text-slate-400 block font-bold">Standard Benchmarking Metrics</span>
                  <p className="text-xs text-indigo-700 dark:text-amber-400 leading-relaxed font-mono mt-0.5">
                    {hardwareDetail.benchmark}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-3 bg-blue-500/5 rounded-xl border border-blue-500/10 text-[10px] text-slate-400 leading-relaxed mt-6 flex gap-1.5">
              <Info className="h-4.5 w-4.5 text-blue-500 shrink-0 mt-0.5" />
              <p>
                Discovering PC hardware allows scholars to easily clear IT literacy tests and set up programming configurations.
              </p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
