/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  PlusCircle, 
  FileText, 
  Video, 
  Award, 
  BookOpen, 
  Users, 
  BarChart, 
  CheckCircle, 
  Send, 
  Trash2, 
  Plus, 
  Search, 
  Sliders, 
  Layers, 
  ShieldAlert, 
  Clock, 
  Calendar,
  AlertCircle,
  FileSpreadsheet,
  UserCheck
} from 'lucide-react';
import { Course, StudyNote, MCQTest, TestResult, UserProfile, TestQuestion } from '../types';
import { firebaseService, SystemNotification } from '../firebaseService';

interface AdminDashboardProps {
  lang: 'en' | 'hi';
  currentUser?: UserProfile | null;
}

export default function AdminDashboard({ lang, currentUser }: AdminDashboardProps) {
  const isAuthorized = currentUser?.email?.toLowerCase().trim() === 'pcmplusacademy@gmail.com';

  if (!isAuthorized) {
    return (
      <div id="access-denied-view" className="max-w-xl mx-auto my-12 p-8 bg-white dark:bg-slate-900 border border-red-200 dark:border-red-950/55 rounded-2xl shadow-xl text-center space-y-6 animate-fade-in">
        <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-905">
          <ShieldAlert className="h-8 w-8 text-red-500" />
        </div>
        <div className="space-y-2">
          <h3 className="text-xl font-outfit font-bold text-slate-900 dark:text-white">Access Denied</h3>
          <p className="text-sm font-semibold text-red-600 dark:text-red-400">
            Access Denied: Only the Official PCM Plus Academy Administrator can access this panel.
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto leading-relaxed">
            Your current account credentials are not permitted to manage academy courses, notes, tests, students, or system broadcasts.
          </p>
        </div>
      </div>
    );
  }

  // Navigation internal tabs
  const [activeWorkflow, setActiveWorkflow] = useState<'analytics' | 'courses' | 'notes' | 'tests' | 'students'>('analytics');
  
  // Dynamic Lists fetched from Firebase/Cache
  const [courses, setCourses] = useState<Course[]>([]);
  const [notes, setNotes] = useState<StudyNote[]>([]);
  const [tests, setTests] = useState<MCQTest[]>([]);
  const [studentsList, setStudentsList] = useState<UserProfile[]>([]);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [notifications, setNotifications] = useState<SystemNotification[]>([]);
  
  // Status messages
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(true);

  // --- FORM FIELDS STATE ---
  
  // 1. Course creation form
  const [newCourseTitle, setNewCourseTitle] = useState('');
  const [newCourseDesc, setNewCourseDesc] = useState('');
  const [newCourseSubject, setNewCourseSubject] = useState('Physics');
  const [newCourseExam, setNewCourseExam] = useState('JEE');
  const [newCourseBanner, setNewCourseBanner] = useState('');

  // 2. Video insertion form
  const [selectedCourseForVideo, setSelectedCourseForVideo] = useState('');
  const [lecTitle, setLecTitle] = useState('');
  const [lecDuration, setLecDuration] = useState('45 mins');
  const [lecYtUrl, setLecYtUrl] = useState('');

  // 3. Notes publication form
  const [noteTitle, setNoteTitle] = useState('');
  const [noteSubject, setNoteSubject] = useState('Physics');
  const [noteCategory, setNoteCategory] = useState('JEE');
  const [noteChapter, setNoteChapter] = useState('');
  const [noteMarkdown, setNoteMarkdown] = useState('');
  const [notePdfUrl, setNotePdfUrl] = useState('');

  // 4. Test Series maker form
  const [testTitle, setTestTitle] = useState('');
  const [testSubject, setTestSubject] = useState('Physics');
  const [testCategory, setTestCategory] = useState('JEE');
  const [testDuration, setTestDuration] = useState(45);
  const [questionsList, setQuestionsList] = useState<TestQuestion[]>([]);
  
  // Question addition temporary state
  const [tempQuestionText, setTempQuestionText] = useState('');
  const [tempOptA, setTempOptA] = useState('');
  const [tempOptB, setTempOptB] = useState('');
  const [tempOptC, setTempOptC] = useState('');
  const [tempOptD, setTempOptD] = useState('');
  const [tempCorrectIndex, setTempCorrectIndex] = useState(0); // index 0-3
  const [tempExplanation, setTempExplanation] = useState('');

  // 5. Broadcast alerts form
  const [notifEnMessage, setNotifEnMessage] = useState('');
  const [notifHiMessage, setNotifHiMessage] = useState('');
  const [notifSeverity, setNotifSeverity] = useState<'info' | 'warning' | 'success'>('info');

  // Search/Filter helper states
  const [studentSearch, setStudentSearch] = useState('');
  const [resultSearch, setResultSearch] = useState('');

  // Load everything on mount
  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const coreCourses = await firebaseService.getCourses();
      const coreNotes = await firebaseService.getNotes();
      const coreTests = await firebaseService.getTests();
      const coreStudents = await firebaseService.getStudents();
      const coreResults = await firebaseService.getTestResults();
      const coreNotifs = await firebaseService.getNotifications();

      setCourses(coreCourses);
      setNotes(coreNotes);
      setTests(coreTests);
      setStudentsList(coreStudents);
      setTestResults(coreResults);
      setNotifications(coreNotifs);

      if (coreCourses.length > 0) {
        setSelectedCourseForVideo(coreCourses[0].id);
      }
    } catch (err) {
      console.error("Failed loading administrative data", err);
      setErrorMsg("Failed loading database information. Operating in secure offline buffer mode.");
    } finally {
      setLoading(false);
    }
  };

  const showToastSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(''), 5000);
  };

  // --- SUBMISSIONS HANDLERS ---

  // A. Create Course
  const handleCreateCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCourseTitle || !newCourseSubject) return;

    const courseId = `course_${newCourseSubject.toLowerCase().trim()}_${Date.now().toString(36)}`;
    const freshCourse: Course = {
      id: courseId,
      title: newCourseTitle,
      description: newCourseDesc || 'No summary description supplied for this course syllabus.',
      subject: newCourseSubject,
      examType: newCourseExam,
      bannerUrl: newCourseBanner || 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80&w=600',
      lectures: [],
      createdAt: new Date().toISOString()
    };

    try {
      await firebaseService.saveCourse(freshCourse);
      setCourses(prev => [freshCourse, ...prev]);
      showToastSuccess(`New Course "${newCourseTitle}" created and synchronized in Firestore!`);
      
      // Reset form fields
      setNewCourseTitle('');
      setNewCourseDesc('');
      setNewCourseBanner('');
    } catch (err) {
      setErrorMsg("Course creation failed. Inspect connectivity.");
    }
  };

  // B. Append Video Lecture
  const handleAddVideoToCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lecTitle || !lecYtUrl || !selectedCourseForVideo) return;

    // Extract genuine YouTube Video ID
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = lecYtUrl.match(regExp);
    const ytId = (match && match[2].length === 11) ? match[2] : lecYtUrl.trim();

    const target = courses.find(c => c.id === selectedCourseForVideo);
    if (!target) return;

    const freshLec = {
      id: `lec_${Date.now().toString(36)}`,
      title: lecTitle,
      duration: lecDuration,
      youtubeId: ytId
    };

    const updatedCourse: Course = {
      ...target,
      lectures: [...target.lectures, freshLec]
    };

    try {
      await firebaseService.saveCourse(updatedCourse);
      setCourses(prev => prev.map(c => c.id === target.id ? updatedCourse : c));
      showToastSuccess(`Video Lecture "${lecTitle}" successfully uploaded to "${target.title}"!`);
      
      setLecTitle('');
      setLecYtUrl('');
    } catch (err) {
      setErrorMsg("Failed uploading YouTube video packet.");
    }
  };

  // C. Upload Notes
  const handlePublishNotes = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle || !noteChapter || !noteMarkdown) return;

    const freshNote: StudyNote = {
      id: `note_${Date.now().toString(36)}`,
      title: noteTitle,
      subject: noteSubject,
      category: noteCategory,
      chapter: noteChapter,
      contentMarkdown: noteMarkdown,
      pdfUrl: notePdfUrl || undefined,
      viewsCount: 0
    };

    try {
      await firebaseService.saveNote(freshNote);
      setNotes(prev => [freshNote, ...prev]);
      showToastSuccess(`Study Chapter Notes "${noteTitle}" cataloged successfully with PDF download attachment.`);
      
      setNoteTitle('');
      setNoteChapter('');
      setNoteMarkdown('');
      setNotePdfUrl('');
    } catch (err) {
      setErrorMsg("Failed cataloging chapter notes.");
    }
  };

  // D. Handle Test Question Accumulation
  const addQuestionToBuilder = () => {
    if (!tempQuestionText || !tempOptA || !tempOptB) {
      alert("At least the Question and Option A/B are mandatory.");
      return;
    }

    const freshQ: TestQuestion = {
      id: `q_${Date.now()}_${questionsList.length}`,
      question: tempQuestionText,
      options: [tempOptA, tempOptB, tempOptC || 'N/A', tempOptD || 'N/A'].filter(o => o !== ''),
      correctIndex: tempCorrectIndex,
      explanation: tempExplanation || 'Direct academic solution.'
    };

    setQuestionsList(prev => [...prev, freshQ]);
    
    // Reset temp question fields
    setTempQuestionText('');
    setTempOptA('');
    setTempOptB('');
    setTempOptC('');
    setTempOptD('');
    setTempExplanation('');
  };

  // E. Save full MCQ assessment series
  const handleSaveTestSeries = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testTitle || questionsList.length === 0) {
      alert("Assessment requires a title and at least one structured question.");
      return;
    }

    const freshTest: MCQTest = {
      id: `test_${testCategory.toLowerCase()}_${Date.now().toString(36)}`,
      title: testTitle,
      subject: testSubject,
      category: testCategory,
      durationMinutes: Number(testDuration) || 45,
      questions: questionsList
    };

    try {
      await firebaseService.saveTest(freshTest);
      setTests(prev => [freshTest, ...prev]);
      showToastSuccess(`MCQ Mock Test Series "${testTitle}" of ${questionsList.length} questions successfully created. Check assessment terminal!`);
      
      setTestTitle('');
      setQuestionsList([]);
    } catch (err) {
      setErrorMsg("Failed creating interactive MCQ Test.");
    }
  };

  // F. Dispatch Notification
  const handleDispatchNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifEnMessage) return;

    try {
      await firebaseService.sendNotification(notifEnMessage, notifHiMessage || notifEnMessage, notifSeverity);
      const updatedNotifs = await firebaseService.getNotifications();
      setNotifications(updatedNotifs);
      showToastSuccess("Administrative broadcast notification sent successfully!");
      
      setNotifEnMessage('');
      setNotifHiMessage('');
    } catch (err) {
      setErrorMsg("Failed broadcasting message alerts.");
    }
  };

  // G. Delete Notification
  const handleDeleteNotification = async (id: string) => {
    try {
      await firebaseService.clearNotification(id);
      setNotifications(prev => prev.filter(n => n.id !== id));
      showToastSuccess("Broadcast alert message removed.");
    } catch (err) {
      setErrorMsg("Failed clearing system notification.");
    }
  };

  // --- STATS COMPILING HELPERS ---
  const totalSubmissions = testResults.length;
  const certifiedStudents = studentsList.filter(student => {
    const records = testResults.filter(r => r.userId === student.uid);
    return records.some(r => r.score >= 80);
  }).length;
  
  const averageScore = totalSubmissions > 0 
    ? Math.round(testResults.reduce((acc, r) => acc + r.score, 0) / totalSubmissions)
    : 0;

  // Filters students and results list
  const filteredStudents = studentsList.filter(s => 
    s.name.toLowerCase().includes(studentSearch.toLowerCase()) || 
    s.email.toLowerCase().includes(studentSearch.toLowerCase())
  );

  const filteredResults = testResults.filter(r => 
    r.userName.toLowerCase().includes(resultSearch.toLowerCase()) || 
    r.testTitle.toLowerCase().includes(resultSearch.toLowerCase())
  );

  const labels = {
    en: {
      head: "PCM Administrative Control Command",
      tagline: "Dynamic Cloud Studio Dashboard for Sushil Pandey Sir’s academic catalog, PDFs, MCQ tests, live notifications & enrolled scholars.",
      metricsTitle: "Academy Status Indicators",
      recentSub: "Recent Assessed Mock scorecards",
      broadcastTitle: "Send Broadcast Notification Banner",
      uploadVideo: "Upload YouTube Video Lecture",
      addCourse: "Add Interactive Lecture Course",
      uploadNotes: "Upload Chapter Study Notes PDF",
      testsBuilder: "Create Interactive MCQ Mock series"
    },
    hi: {
      head: "पीसीएम प्रशासनिक नियंत्रण केंद्र",
      tagline: "सुशील पांडेय सर के शैक्षणिक कैटलॉग, पीडीएफ, मॉक टेस्ट, लाइव सूचनाओं और नामांकित छात्रों के सुचारू संचालन का डैशबोर्ड।",
      metricsTitle: "अकादमी स्थिति संकेतक",
      recentSub: "हाल के मॉक स्कोरकार्ड सबमिशन",
      broadcastTitle: "नया और तत्काल संदेश प्रसारित करें",
      uploadVideo: "यूट्यूब वीडियो लेक्चर अपलोड करें",
      addCourse: "नया एचडी लेक्चर कोर्स जोड़ें",
      uploadNotes: "अध्याय अध्ययन नोट्स पीडीएफ अपलोड करें",
      testsBuilder: "संबद्ध बहुविकल्पीय मॉक टेस्ट सीरीज बनाएं"
    }
  }[lang];

  return (
    <div id="admin-unified-panel" className="space-y-6">
      {/* Page Header */}
      <div className="bg-gradient-to-r from-slate-905 via-indigo-950 to-emerald-950 p-6 rounded-2xl text-white border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 h-40 w-40 bg-indigo-500/10 rounded-full blur-2xl"></div>
        <div className="absolute left-1/3 bottom-0 h-24 w-24 bg-emerald-500/5 rounded-full blur-xl"></div>
        
        <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 px-3 py-1 rounded">
          Sushil Pandey Sir • Lead Administrator Mode
        </span>
        <h2 className="text-2xl font-outfit font-bold mt-2.5 tracking-tight">{labels.head}</h2>
        <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">{labels.tagline}</p>
      </div>

      {/* Global Alerts Feed */}
      {successMsg && (
        <div id="toast-success-banner" className="p-4 bg-emerald-50 dark:bg-emerald-950/20 border-l-4 border-emerald-500 text-emerald-700 dark:text-emerald-300 text-xs rounded-r-xl flex items-center gap-2.5 shadow-sm transition-all animate-fade-in">
          <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0" />
          <span className="font-medium">{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div id="toast-error-banner" className="p-4 bg-rose-50 dark:bg-rose-950/10 border-l-4 border-rose-500 text-rose-700 dark:text-rose-300 text-xs rounded-r-xl flex items-center gap-2.5 shadow-sm">
          <AlertCircle className="h-5 w-5 text-rose-600 shrink-0" />
          <span className="font-medium">{errorMsg}</span>
        </div>
      )}

      {/* HORIZONTAL ADMIN SECTIONS NAVIGATION */}
      <div className="flex items-center space-x-1.5 overflow-x-auto pb-1.5 border-b border-slate-200 dark:border-slate-800 scrollbar-none">
        <button
          onClick={() => setActiveWorkflow('analytics')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-300 flex items-center gap-2 ${
            activeWorkflow === 'analytics'
              ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-950 shadow-md transform -translate-y-0.5'
              : 'text-slate-650 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <BarChart className="h-4 w-4" />
          <span>{lang === 'hi' ? 'एनालिटिक्स एवं सूचनाएं' : 'Analytics & Broadway Alerts'}</span>
        </button>

        <button
          onClick={() => setActiveWorkflow('courses')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-300 flex items-center gap-2 ${
            activeWorkflow === 'courses'
              ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-950 shadow-md transform -translate-y-0.5'
              : 'text-slate-650 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Video className="h-4 w-4" />
          <span>{lang === 'hi' ? 'कोर्स एवं यूट्यूब वीडियो' : 'Courses & Videos'}</span>
        </button>

        <button
          onClick={() => setActiveWorkflow('notes')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-300 flex items-center gap-2 ${
            activeWorkflow === 'notes'
              ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-950 shadow-md transform -translate-y-0.5'
              : 'text-slate-650 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <FileText className="h-4 w-4" />
          <span>{lang === 'hi' ? 'चैप्टर हैंडआउट्स PDF' : 'Notes & Study Booklets'}</span>
        </button>

        <button
          onClick={() => setActiveWorkflow('tests')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-300 flex items-center gap-2 ${
            activeWorkflow === 'tests'
              ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-950 shadow-md transform -translate-y-0.5'
              : 'text-slate-650 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Award className="h-4 w-4" />
          <span>{lang === 'hi' ? 'मॉक टेस्ट निर्माता' : 'Mock Test Maker'}</span>
        </button>

        <button
          onClick={() => setActiveWorkflow('students')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-300 flex items-center gap-2 ${
            activeWorkflow === 'students'
              ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-950 shadow-md transform -translate-y-0.5'
              : 'text-slate-650 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>{lang === 'hi' ? 'छात्र एवं परिणाम स्कोर' : 'Student & Results Deck'}</span>
        </button>
      </div>

      {loading ? (
        <div className="p-12 text-center text-slate-500">
          <Layers className="h-8 w-8 animate-spin mx-auto text-amber-500 mb-3" />
          <p className="text-xs font-mono">Synchronizing control logs with Firestore Database...</p>
        </div>
      ) : (
        <div id="admin-main-interface-body" className="space-y-6">
          
          {/* ==================== WORKFLOW A: ANALYTICS & BROADCAST ALERT ==================== */}
          {activeWorkflow === 'analytics' && (
            <div className="space-y-6 animate-fade-in">
              {/* Aggregation scorecard boards */}
              <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-md">
                <h3 className="font-outfit font-bold text-sm text-slate-950 dark:text-white mb-4 flex items-center gap-2">
                  <BarChart className="h-4.5 w-4.5 text-amber-500" />
                  <span>{labels.metricsTitle} (Live Firestore count)</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800/60 p-4 rounded-xl flex items-center space-x-3.5">
                    <div className="bg-blue-100 dark:bg-blue-950 text-blue-900 dark:text-amber-500 p-3 rounded-xl border border-blue-200">
                      <Users className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Aspirants Registered</span>
                      <span className="text-xl font-bold font-outfit text-slate-900 dark:text-slate-100">{studentsList.length}</span>
                    </div>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800/60 p-4 rounded-xl flex items-center space-x-3.5">
                    <div className="bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 p-3 rounded-xl border border-amber-200">
                      <BookOpen className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Active Courses</span>
                      <span className="text-xl font-bold font-outfit text-slate-900 dark:text-slate-100">{courses.length}</span>
                    </div>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800/60 p-4 rounded-xl flex items-center space-x-3.5">
                    <div className="bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 p-3 rounded-xl border border-emerald-200">
                      <Award className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Interactive Mocks</span>
                      <span className="text-xl font-bold font-outfit text-slate-900 dark:text-slate-100">{tests.length}</span>
                    </div>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800/60 p-4 rounded-xl flex items-center space-x-3.5">
                    <div className="bg-purple-100 dark:bg-purple-950/40 text-purple-600 p-3 rounded-xl border border-purple-200">
                      <FileSpreadsheet className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Test Average Score</span>
                      <span className="text-xl font-bold font-outfit text-slate-900 dark:text-slate-100">{averageScore}%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Grid with broadcast notification form and active alerts list */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4">
                  <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-lg">
                    <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                      <Send className="h-4.5 w-4.5 text-indigo-500" />
                      <span>{labels.broadcastTitle}</span>
                    </h4>

                    <form onSubmit={handleDispatchNotification} className="space-y-3.5">
                      <div>
                        <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                          Notification Text (English)
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. 🚨 Live session starting in 15 minutes! Join Sushil Sir."
                          value={notifEnMessage}
                          onChange={(e) => setNotifEnMessage(e.target.value)}
                          className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-blue-900"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                          हिंदी अनुवाद (Optional)
                        </label>
                        <input
                          type="text"
                          placeholder="उदा. 🚨 लाइव क्लास 15 मिनट में शुरू हो रही है! शामिल हों।"
                          value={notifHiMessage}
                          onChange={(e) => setNotifHiMessage(e.target.value)}
                          className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-blue-900"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                            Severity Level
                          </label>
                          <select
                            value={notifSeverity}
                            onChange={(e) => setNotifSeverity(e.target.value as any)}
                            className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-800 dark:text-slate-100"
                          >
                            <option value="info">Info Accent (Blue)</option>
                            <option value="warning">Warning Alert (Yellow/Amber)</option>
                            <option value="success">Success Spark (Green)</option>
                          </select>
                        </div>

                        <div className="flex items-end">
                          <button
                            type="submit"
                            className="w-full bg-slate-900 hover:bg-slate-800 dark:bg-amber-500 dark:hover:bg-amber-600 dark:text-slate-950 text-white font-bold py-2.5 rounded-xl text-xs transition-colors flex items-center justify-center gap-2 shadow-sm"
                          >
                            <Send className="h-3.5 w-3.5" />
                            <span>Broadcast Now</span>
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl relative">
                  <h4 className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-3">
                    Active System Broadcasts ({notifications.length})
                  </h4>
                  <div className="space-y-3 max-h-[220px] overflow-y-auto scrollbar-none">
                    {notifications.length === 0 ? (
                      <p className="text-[11px] text-slate-500 font-mono">No notifications currently active.</p>
                    ) : (
                      notifications.map(n => (
                        <div key={n.id} className="p-3 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl space-y-1 relative group">
                          <button
                            onClick={() => handleDeleteNotification(n.id)}
                            className="absolute top-2 right-2 text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded"
                            title="Delete Broadcast Alert"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                          <p className="text-[11px] font-sans text-slate-800 dark:text-slate-200 leading-snug pr-5">
                            {n.text}
                          </p>
                          {n.textHi && n.textHi !== n.text && (
                            <p className="text-[10px] font-sans text-slate-400 leading-snug">
                              {n.textHi}
                            </p>
                          )}
                          <div className="text-[9px] font-mono text-slate-400 mt-2 flex justify-between">
                            <span className="uppercase font-bold text-amber-500">{n.type}</span>
                            <span>{new Date(n.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================== WORKFLOW B: COURSE CATALOGUE & VIDEOS ==================== */}
          {activeWorkflow === 'courses' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in">
              {/* Form 1: Add New Course */}
              <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-lg">
                <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                  <Layers className="h-5 w-5 text-indigo-500" />
                  <span>{labels.addCourse}</span>
                </h4>

                <form onSubmit={handleCreateCourse} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Course / Batch Title
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Target JEE Main & Advanced 2027: Ultimate Physics"
                      value={newCourseTitle}
                      onChange={(e) => setNewCourseTitle(e.target.value)}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Syllabus & Course Description
                    </label>
                    <textarea
                      placeholder="Specify chapter highlights, batch start date, and board exam targets."
                      value={newCourseDesc}
                      onChange={(e) => setNewCourseDesc(e.target.value)}
                      rows={3}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-slate-800 dark:text-slate-100 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                        Academic Subject
                      </label>
                      <select
                        value={newCourseSubject}
                        onChange={(e) => setNewCourseSubject(e.target.value)}
                        className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-850 dark:text-slate-100"
                      >
                        <option value="Physics">Physics (भौतिकी)</option>
                        <option value="Chemistry">Chemistry (रसायन शास्त्र)</option>
                        <option value="Mathematics">Mathematics (गणित)</option>
                        <option value="Modern History">Modern History (इतिहास)</option>
                        <option value="Computer Skills">Computer Skills (कम्प्यूटर ज्ञान)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                        Target Category Group
                      </label>
                      <select
                        value={newCourseExam}
                        onChange={(e) => setNewCourseExam(e.target.value)}
                        className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-850 dark:text-slate-100"
                      >
                        <option value="JEE">JEE Mains / Adv</option>
                        <option value="NEET">NEET Medical</option>
                        <option value="UPSC">UPSC Civils</option>
                        <option value="Class 12">Class 12th Board</option>
                        <option value="Class 11">Class 11th Science</option>
                        <option value="Computer Courses">Computer Certificate</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Illustration Cover URL (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Unsplash URL"
                      value={newCourseBanner}
                      onChange={(e) => setNewCourseBanner(e.target.value)}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-slate-800 dark:text-slate-100"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-slate-900 hover:bg-slate-850 dark:bg-emerald-500 dark:hover:bg-emerald-600 dark:text-slate-900 text-white font-bold py-2.5 rounded-xl text-xs transition-colors shadow-sm"
                  >
                    Deploy New Dynamic Course
                  </button>
                </form>
              </div>

              {/* Form 2: Add YouTube Video Lectures */}
              <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-lg">
                <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                  <Video className="h-5 w-5 text-amber-500" />
                  <span>{labels.uploadVideo}</span>
                </h4>

                <form onSubmit={handleAddVideoToCourse} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Associate Course Batch
                    </label>
                    <select
                      value={selectedCourseForVideo}
                      onChange={(e) => setSelectedCourseForVideo(e.target.value)}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-705 p-3 rounded-xl text-slate-850 dark:text-slate-300"
                      required
                    >
                      {courses.map(c => (
                        <option key={c.id} value={c.id}>{c.title} [{c.examType}]</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Lecture Video Title
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. L4: Photoelectric Effect Numericals & Derivations"
                      value={lecTitle}
                      onChange={(e) => setLecTitle(e.target.value)}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-slate-800 dark:text-slate-100 focus:outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                        Lecture Estimated Duration
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. 50 mins"
                        value={lecDuration}
                        onChange={(e) => setLecDuration(e.target.value)}
                        className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-800 dark:text-slate-100"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                        YouTube Link or Video ID
                      </label>
                      <input
                        type="text"
                        placeholder="https://www.youtube.com/watch?v=..."
                        value={lecYtUrl}
                        onChange={(e) => setLecYtUrl(e.target.value)}
                        className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-705 p-2.5 rounded-xl text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-slate-900 hover:bg-slate-855 dark:bg-amber-500 dark:hover:bg-amber-600 dark:text-slate-950 text-white font-bold py-2.5 rounded-xl text-xs transition-colors shadow-sm"
                  >
                    Broadcast Video Lecture Live
                  </button>
                </form>

                {/* Video previews box info */}
                <div className="mt-4 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                  <p className="text-[10px] text-slate-500 leading-relaxed font-sans">
                    <strong>Note:</strong> YouTube video links are automatically parsed to extract standard embedding. These appear dynamically inside Course Handouts to registered students on checkout.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ==================== WORKFLOW C: CHAPTER HANDOUTS PDF & STUDY NOTATIONS ==================== */}
          {activeWorkflow === 'notes' && (
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-lg max-w-4xl mx-auto animate-fade-in">
              <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <FileText className="h-5 w-5 text-indigo-500" />
                <span>{labels.uploadNotes}</span>
              </h4>

              <form onSubmit={handlePublishNotes} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Notes / Handout Title
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Electric Charges, Coulomb’s Law Revision Sheet"
                      value={noteTitle}
                      onChange={(e) => setNoteTitle(e.target.value)}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-slate-800 dark:text-slate-100"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Chapter Number or Designation
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Chapter 1: Electrostatics"
                      value={noteChapter}
                      onChange={(e) => setNoteChapter(e.target.value)}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-slate-800 dark:text-slate-100"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Subject
                    </label>
                    <select
                      value={noteSubject}
                      onChange={(e) => setNoteSubject(e.target.value)}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-800 dark:text-slate-200"
                    >
                      <option value="Physics">Physics</option>
                      <option value="Chemistry">Chemistry</option>
                      <option value="Mathematics">Mathematics</option>
                      <option value="General Studies">General Studies</option>
                      <option value="Computer Skills">Computer Skills</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Associated Target
                    </label>
                    <select
                      value={noteCategory}
                      onChange={(e) => setNoteCategory(e.target.value)}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-800 dark:text-slate-200"
                    >
                      <option value="JEE">JEE Prep</option>
                      <option value="NEET">NEET Prep</option>
                      <option value="UPSC">UPSC Civil Services</option>
                      <option value="Class 12">Class 12 Boards</option>
                      <option value="Class 11">Class 11 Boards</option>
                      <option value="Computer Courses">Computer Basics</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      PDF Download Link / Drive Attachment URL
                    </label>
                    <input
                      type="text"
                      placeholder="https://drive.google.com/file/d/.../view"
                      value={notePdfUrl}
                      onChange={(e) => setNotePdfUrl(e.target.value)}
                      className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Notes Full Text Body (Markdown & LaTeX Math formulas supported)
                  </label>
                  <textarea
                    placeholder="Enter equations, theories and study materials. HTML/Markdown elements are completely styled for responsive reading."
                    value={noteMarkdown}
                    onChange={(e) => setNoteMarkdown(e.target.value)}
                    rows={8}
                    className="w-full font-mono text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3.5 rounded-xl text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-900"
                    required
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="bg-slate-900 dark:bg-amber-500 hover:bg-slate-805 dark:text-slate-950 font-bold px-6 py-3 rounded-xl text-xs text-white transition-all shadow-md"
                  >
                    Publish Study Booklet Notes
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* ==================== WORKFLOW D: ASSESSMENT MCQ TEST MAKER ==================== */}
          {activeWorkflow === 'tests' && (
            <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
              <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-lg">
                <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                  <Award className="h-5 w-5 text-indigo-500" />
                  <span>{labels.testsBuilder}</span>
                </h4>

                <form onSubmit={handleSaveTestSeries} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-2">
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                        Mock Exam Series Title
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. JEE Main Mock Physics Test 05 (Aspirants Assessment)"
                        value={testTitle}
                        onChange={(e) => setTestTitle(e.target.value)}
                        className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-3 rounded-xl text-slate-800 dark:text-slate-100"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                        Duration (Minutes)
                      </label>
                      <input
                        type="number"
                        min="1"
                        placeholder="e.g. 45"
                        value={testDuration}
                        onChange={(e) => setTestDuration(Number(e.target.value))}
                        className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-705 p-3 rounded-xl text-slate-00 dark:text-slate-100"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                        Academic Subject
                      </label>
                      <select
                        value={testSubject}
                        onChange={(e) => setTestSubject(e.target.value)}
                        className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-800 dark:text-slate-200"
                      >
                        <option value="Physics">Physics</option>
                        <option value="Chemistry">Chemistry</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="General Studies">General Knowledge</option>
                        <option value="Computer Basics">Computer Science</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                        Syllabus Cateogry Group
                      </label>
                      <select
                        value={testCategory}
                        onChange={(e) => setTestCategory(e.target.value)}
                        className="w-full text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-850 dark:text-slate-200"
                      >
                        <option value="JEE">JEE Main Series</option>
                        <option value="NEET">NEET Medical Series</option>
                        <option value="UPSC">UPSC Civil Series</option>
                        <option value="Class 12">Class 12 boards</option>
                        <option value="Computer Courses">Computer Certificate</option>
                      </select>
                    </div>
                  </div>

                  {/* SUB QUESTION ACCUMULATION BUILDER PANEL */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl relative space-y-3.5">
                    <h5 className="text-xs font-bold text-slate-700 dark:text-slate-350 flex items-center justify-between">
                      <span>Add Multiple Choice Question (#{questionsList.length + 1})</span>
                      <span className="font-mono text-[10px] text-amber-500 font-bold bg-amber-500/10 px-2 py-0.5 rounded">TEST MAKER WORKBENCH</span>
                    </h5>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase">Question Statement (Hindi/English)</label>
                      <input
                        type="text"
                        placeholder="e.g. Find the magnetic force on a charge particle flowing..."
                        value={tempQuestionText}
                        onChange={(e) => setTempQuestionText(e.target.value)}
                        className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-750 p-2.5 rounded-xl text-slate-900 dark:text-slate-100"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500">Option A</label>
                        <input
                          type="text"
                          placeholder="First option choice"
                          value={tempOptA}
                          onChange={(e) => setTempOptA(e.target.value)}
                          className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-750 p-2 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500">Option B</label>
                        <input
                          type="text"
                          placeholder="Second option choice"
                          value={tempOptB}
                          onChange={(e) => setTempOptB(e.target.value)}
                          className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-750 p-2 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500">Option C</label>
                        <input
                          type="text"
                          placeholder="Third option choice"
                          value={tempOptC}
                          onChange={(e) => setTempOptC(e.target.value)}
                          className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-750 p-2 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500">Option D</label>
                        <input
                          type="text"
                          placeholder="Fourth option choice"
                          value={tempOptD}
                          onChange={(e) => setTempOptD(e.target.value)}
                          className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-750 p-2 rounded-lg"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                      <div>
                        <label className="block text-[10px] font-semibold text-slate-500 mb-1">Correct Option Answer</label>
                        <select
                          value={tempCorrectIndex}
                          onChange={(e) => setTempCorrectIndex(Number(e.target.value))}
                          className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 p-2.5 rounded-xl text-slate-800 dark:text-slate-100"
                        >
                          <option value={0}>Option A is Correct</option>
                          <option value={1}>Option B is Correct</option>
                          <option value={2}>Option C is Correct</option>
                          <option value={3}>Option D is Correct</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-semibold text-slate-500 mb-1">Step Solution & Explanation</label>
                        <input
                          type="text"
                          placeholder="Provide numerical steps or formula derivations."
                          value={tempExplanation}
                          onChange={(e) => setTempExplanation(e.target.value)}
                          className="w-full text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-750 p-2.5 rounded-xl text-slate-800 dark:text-slate-100"
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={addQuestionToBuilder}
                      className="w-full bg-slate-800 hover:bg-slate-750 text-white font-semibold py-2 rounded-lg text-xs flex items-center justify-center gap-1.5"
                    >
                      <Plus className="h-4 w-4 text-emerald-400" />
                      <span>Append Question to Test Batch</span>
                    </button>
                  </div>

                  {/* Active questions batch review */}
                  {questionsList.length > 0 && (
                    <div className="p-4 bg-indigo-500/5 rounded-xl border border-indigo-500/10 space-y-2">
                      <span className="text-[10px] tracking-wider uppercase font-bold text-indigo-400">
                        Queued Questions in Current Series ({questionsList.length})
                      </span>
                      <div className="max-h-24 overflow-y-auto space-y-1 scrollbar-none">
                        {questionsList.map((q, idx) => (
                          <div key={q.id} className="text-[11px] text-slate-600 dark:text-slate-400 flex justify-between font-mono">
                            <span>Q{idx+1}. {q.question.substring(0, 60)}...</span>
                            <span className="text-emerald-500 font-bold">Answer Index: {q.correctIndex}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-slate-900 hover:bg-slate-850 dark:bg-emerald-500 dark:hover:bg-emerald-600 dark:text-slate-900 text-white font-bold py-3 rounded-xl text-xs transition-colors shadow-md"
                  >
                    Deploy New Dynamic MCQ Test Series
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* ==================== WORKFLOW E: REGISTERED STUDENTS & RESULTS SCORE CARDS ==================== */}
          {activeWorkflow === 'students' && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* 1. Student list manager */}
                <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-md">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                    <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                      <Users className="h-5 w-5 text-indigo-500" />
                      <span>Manage Registered Students ({studentsList.length})</span>
                    </h4>
                    
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Search student profile..."
                        value={studentSearch}
                        onChange={(e) => setStudentSearch(e.target.value)}
                        className="w-full sm:w-44 text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 py-1.5 pl-7 pr-3 rounded-lg focus:outline-none placeholder:text-slate-400"
                      />
                      <Search className="h-3.5 w-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    </div>
                  </div>

                  <div className="overflow-x-auto max-h-[400px] scrollbar-none">
                    <table className="w-full text-left text-[11px] font-sans border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-bold uppercase tracking-wider text-[9px]">
                          <th className="py-2.5">Name</th>
                          <th className="py-2.5">Email Address</th>
                          <th className="py-2.5">Registration Info</th>
                          <th className="py-2.5">Access Level</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                        {filteredStudents.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="py-12 text-center text-slate-550 font-mono">No students match selection.</td>
                          </tr>
                        ) : (
                          filteredStudents.map(student => {
                            const dateStr = student.createdAt 
                              ? new Date(student.createdAt).toLocaleDateString() 
                              : "Ongoing Sandbox";
                            return (
                              <tr key={student.uid} className="hover:bg-slate-50 dark:hover:bg-slate-950/20 transition-all font-mono">
                                <td className="py-3 font-sans font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                                  <div className="h-6 w-6 rounded-full bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 flex items-center justify-center font-bold text-[10px]">
                                    {student.name.charAt(0)}
                                  </div>
                                  <span>{student.name}</span>
                                </td>
                                <td className="py-3 text-slate-600 dark:text-slate-400">{student.email}</td>
                                <td className="py-3 text-slate-500 flex items-center gap-1 text-[10px]">
                                  <Calendar className="h-3 w-3" />
                                  <span>{dateStr}</span>
                                </td>
                                <td className="py-3 font-bold">
                                  <span className={`px-2 py-0.5 rounded text-[10px] ${
                                    student.role === 'admin' 
                                      ? 'bg-amber-400/10 text-amber-500 border border-amber-500/30' 
                                      : 'bg-emerald-500/10 text-emerald-500'
                                  }`}>
                                    {student.role.toUpperCase()}
                                  </span>
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 2. Results scorecard list */}
                <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-md">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                    <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5 animate-pulse">
                      <FileSpreadsheet className="h-5 w-5 text-emerald-500" />
                      <span>{labels.recentSub} ({testResults.length})</span>
                    </h4>

                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Filter scorecard..."
                        value={resultSearch}
                        onChange={(e) => setResultSearch(e.target.value)}
                        className="w-full sm:w-44 text-xs bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 py-1.5 pl-7 pr-3 rounded-lg focus:outline-none placeholder:text-slate-400"
                      />
                      <Search className="h-3.5 w-3.5 text-slate-400 absolute left-2.5 top-2.5 animate-pulse" />
                    </div>
                  </div>

                  <div className="overflow-y-auto max-h-[400px] space-y-3 scrollbar-none pr-1">
                    {filteredResults.length === 0 ? (
                      <p className="py-12 text-center text-slate-500 text-xs font-mono">No student marks compiled yet.</p>
                    ) : (
                      filteredResults.map(r => {
                        const isCert = r.score >= 80;
                        return (
                          <div key={r.id} className="p-3 bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-850 rounded-xl space-y-2 hover:border-emerald-500/20 transition-all">
                            <div className="flex justify-between items-center text-[10px]">
                              <span className="font-bold text-indigo-500 flex items-center gap-1 text-[11px] font-sans">
                                <UserCheck className="h-3.5 w-3.5" />
                                {r.userName}
                              </span>
                              <span className="text-slate-400 flex items-center gap-1 font-mono">
                                <Clock className="h-3 w-3" />
                                {new Date(r.takenAt).toLocaleDateString()}
                              </span>
                            </div>

                            <div>
                              <h5 className="text-[11px] font-bold text-slate-905 dark:text-slate-250 font-sans leading-tight">
                                {r.testTitle}
                              </h5>
                              <p className="text-[9px] uppercase tracking-wider font-bold text-amber-500/80 font-mono mt-0.5">
                                Exam Series Level: {r.category}
                              </p>
                            </div>

                            <div className="flex justify-between items-center border-t border-slate-200 dark:border-slate-850 pt-2 text-[11px]">
                              <div className="font-mono space-x-2 text-slate-550">
                                <span>Correct: <strong className="text-emerald-500">{r.correctCount}</strong></span>
                                <span>Wrong: <strong className="text-rose-500">{r.wrongCount}</strong></span>
                                <span>Total Qs: <strong>{r.totalQuestions}</strong></span>
                              </div>

                              <div className="flex items-center gap-1.5">
                                {isCert && (
                                  <Award className="h-4 w-4 text-amber-505" title="Qualified for Academy Honors" />
                                )}
                                <span className={`font-mono font-bold px-2 py-0.5 rounded ${
                                  r.score >= 80 
                                    ? 'bg-emerald-500/10 text-emerald-500' 
                                    : r.score >= 50 
                                      ? 'bg-amber-400/10 text-amber-500' 
                                      : 'bg-rose-500/10 text-rose-500'
                                }`}>
                                  Score: {r.score}%
                                </span>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

              </div>
            </div>
          )}

        </div>
      )}
    </div>
  );
}
