/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Flame, 
  Coffee, 
  Award, 
  Volume2, 
  VolumeX, 
  Timer, 
  ChevronRight,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  Clock,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FocusTimerProps {
  lang: 'en' | 'hi';
}

type TimerMode = 'work' | 'break' | 'longBreak';

export default function FocusTimer({ lang }: FocusTimerProps) {
  const [mode, setMode] = useState<TimerMode>('work');
  const [isPlaying, setIsPlaying] = useState(false);
  
  // Default durations in seconds
  const [workDuration, setWorkDuration] = useState(25 * 60);
  const [breakDuration, setBreakDuration] = useState(5 * 60);
  const [longBreakDuration, setLongBreakDuration] = useState(15 * 60);
  
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [initialTime, setInitialTime] = useState(25 * 60);
  const [isMuted, setIsMuted] = useState(false);
  
  // Focus stats persisted locally
  const [completedSessions, setCompletedSessions] = useState(0);
  const [totalFocusMinutes, setTotalFocusMinutes] = useState(0);
  
  // Sound generation audio context ref
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Load and store stats from localStorage
  useEffect(() => {
    try {
      const savedCount = localStorage.getItem('pcm_focus_sessions_count');
      const savedMinutes = localStorage.getItem('pcm_focus_minutes_total');
      if (savedCount) setCompletedSessions(parseInt(savedCount, 10));
      if (savedMinutes) setTotalFocusMinutes(parseInt(savedMinutes, 10));
    } catch (e) {
      console.warn("Storage access restricted.", e);
    }
  }, []);

  // Update timer whenever mode changes
  useEffect(() => {
    setIsPlaying(false);
    let duration = 25 * 60;
    if (mode === 'work') duration = workDuration;
    else if (mode === 'break') duration = breakDuration;
    else if (mode === 'longBreak') duration = longBreakDuration;
    
    setTimeLeft(duration);
    setInitialTime(duration);
  }, [mode, workDuration, breakDuration, longBreakDuration]);

  // Main countdown effect loop
  useEffect(() => {
    let intervalId: any = null;
    if (isPlaying) {
      intervalId = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(intervalId);
            handleSessionComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (intervalId) clearInterval(intervalId);
    }
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isPlaying]);

  // Audio synthesizer for pristine bell sound
  const playSessionEndChime = () => {
    if (isMuted) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      // Elegant double melody chime
      const playTone = (freq: number, start: number, duration: number) => {
        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        osc.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, start);
        
        // Attack/decay envelope
        gainNode.gain.setValueAtTime(0, start);
        gainNode.gain.linearRampToValueAtTime(0.3, start + 0.05);
        gainNode.gain.exponentialRampToValueAtTime(0.001, start + duration);
        
        osc.start(start);
        osc.stop(start + duration);
      };

      const now = ctx.currentTime;
      if (mode === 'work') {
        // High upbeat melody for work end
        playTone(523.25, now, 1.2); // C5
        playTone(659.25, now + 0.2, 1.2); // E5
        playTone(783.99, now + 0.4, 1.5); // G5
      } else {
        // Low cozy sound for break end
        playTone(392.00, now, 1.0); // G4
        playTone(329.63, now + 0.25, 1.2); // E4
      }
    } catch (err) {
      console.warn("AudioContext tone blocked or unsupported in sandbox.", err);
    }
  };

  const handleSessionComplete = () => {
    setIsPlaying(false);
    playSessionEndChime();

    if (mode === 'work') {
      const mins = Math.floor(initialTime / 60);
      const newSessions = completedSessions + 1;
      const newMins = totalFocusMinutes + mins;
      
      setCompletedSessions(newSessions);
      setTotalFocusMinutes(newMins);
      
      try {
        localStorage.setItem('pcm_focus_sessions_count', newSessions.toString());
        localStorage.setItem('pcm_focus_minutes_total', newMins.toString());
      } catch (e) {
        // Safe fail
      }

      // Automatically transition to break
      setMode('break');
    } else {
      // Transition back to study sessions
      setMode('work');
    }
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const resetTimer = () => {
    setIsPlaying(false);
    setTimeLeft(initialTime);
  };

  const changeDuration = (amountMinutes: number) => {
    if (isPlaying) return;
    
    if (mode === 'work') {
      const next = Math.max(1, Math.min(180, Math.round(workDuration / 60) + amountMinutes));
      setWorkDuration(next * 60);
    } else if (mode === 'break') {
      const next = Math.max(1, Math.min(60, Math.round(breakDuration / 60) + amountMinutes));
      setBreakDuration(next * 60);
    } else {
      const next = Math.max(1, Math.min(90, Math.round(longBreakDuration / 60) + amountMinutes));
      setLongBreakDuration(next * 60);
    }
  };

  // Human countdown presentation
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  // SVG circular outline progress
  const percentage = initialTime > 0 ? (timeLeft / initialTime) * 100 : 0;
  const strokeDashoffset = 282.6 - (282.6 * percentage) / 100;

  const quotesMap = {
    en: [
      "Keep sketching those free body diagrams under Sushil Sir's formula guides!",
      "Laser focus yields pristine academic results. Just 25 minutes of deep study!",
      "Break complex JEE questions into smaller sub-challenges. You've got this!",
      "Class 11 & 12 Board success is built step-by-step, session-by-session.",
      "Stay curious, turn off distractions, let's learn deeply right now!"
    ],
    hi: [
      "सुशील सर के मार्गदर्शन में भौतिकी और गणित के सूत्रों को ध्यान से समझें!",
      "एकाग्रता ही सफलता की कुंजी है। सिर्फ 25 मिनट का गहरा और शांत अध्ययन करें!",
      "जटिल प्रश्नों को छोटे हिस्सों में विभाजित करें। आप इसे निश्चित ही कर सकते हैं!",
      "कक्षा 11वीं और 12वीं की परीक्षा में सफलता निरंतर अभ्यास से ही संभव है।",
      "सभी ध्यान भटकाने वाली चीजों को बंद कर दें और पूरे मन से अध्ययन करें!"
    ]
  }[lang];

  // Pick a semi-random quote based on minutes
  const activeQuoteIdx = (Math.floor(totalFocusMinutes / 5) + completedSessions) % quotesMap.length;
  const quoteToShow = quotesMap[activeQuoteIdx];

  const themeColors = {
    work: {
      accent: 'text-amber-500',
      progress: 'stroke-amber-500',
      bgLight: 'bg-amber-500/10',
      glow: 'shadow-amber-500/10',
      border: 'border-amber-500/20'
    },
    break: {
      accent: 'text-emerald-500',
      progress: 'stroke-emerald-500',
      bgLight: 'bg-emerald-500/10',
      glow: 'shadow-emerald-500/10',
      border: 'border-emerald-500/20'
    },
    longBreak: {
      accent: 'text-blue-500',
      progress: 'stroke-blue-500',
      bgLight: 'bg-blue-500/10',
      glow: 'shadow-blue-500/10',
      border: 'border-blue-500/20'
    }
  }[mode];

  const labels = {
    en: {
      studyBlock: "Work Mode",
      breakBlock: "Short Break",
      longBreak: "Long Break",
      totalFocMins: "Focus Minutes",
      sessionDone: "Blocks Cleared",
      reset: "Reset",
      adjust: "Adjust Time",
      stats: "Today's Study Streak",
      motivation: "PCM Focus Catalyst"
    },
    hi: {
      studyBlock: "अध्ययन काल",
      breakBlock: "लघु विश्राम",
      longBreak: "दीर्घ विश्राम",
      totalFocMins: "कुल एकाग्र मिनट",
      sessionDone: "सत्र पूर्ण",
      reset: "रीसेट",
      adjust: "समय बदलें",
      stats: "आज का अध्ययन रिपोर्ट",
      motivation: "मनोवैज्ञानिक संबल"
    }
  }[lang];

  return (
    <div id="pomodoro-focus-card" className={`bg-white dark:bg-slate-900 border ${themeColors.border} p-5 rounded-2xl shadow-lg space-y-4 transition-all duration-300`}>
      {/* Timer Header Title */}
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center space-x-2">
          <Timer className={`h-4.5 w-4.5 ${themeColors.accent} animate-pulse`} />
          <h4 className="font-outfit font-bold text-xs uppercase tracking-wider text-slate-800 dark:text-slate-200">
            {lang === 'hi' ? 'स्मार्ट फोकस टाइमर' : 'Pomodoro Study Timer'}
          </h4>
        </div>
        
        <button
          onClick={() => setIsMuted(!isMuted)}
          className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition-colors"
          title={isMuted ? "Unmute alert bell" : "Mute alert bell"}
        >
          {isMuted ? <VolumeX className="h-4 w-4 text-rose-450" /> : <Volume2 className="h-4 w-4" />}
        </button>
      </div>

      {/* Mode selectors */}
      <div className="grid grid-cols-3 gap-1 bg-slate-50 dark:bg-slate-950 p-1 rounded-xl border border-slate-100 dark:border-slate-800">
        <button
          onClick={() => setMode('work')}
          className={`py-1.5 px-1 text-[10px] rounded-lg font-bold transition-all text-center ${
            mode === 'work' 
              ? 'bg-amber-500 text-slate-950 shadow-sm' 
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          {labels.studyBlock}
        </button>
        <button
          onClick={() => setMode('break')}
          className={`py-1.5 px-1 text-[10px] rounded-lg font-bold transition-all text-center ${
            mode === 'break' 
              ? 'bg-emerald-500 text-slate-950 shadow-sm' 
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          {labels.breakBlock}
        </button>
        <button
          onClick={() => setMode('longBreak')}
          className={`py-1.5 px-1 text-[10px] rounded-lg font-bold transition-all text-center ${
            mode === 'longBreak' 
              ? 'bg-blue-500 text-slate-950 shadow-sm' 
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          {labels.longBreak}
        </button>
      </div>

      {/* Main clock stage face */}
      <div className="flex flex-col items-center justify-center py-3 relative">
        <div className="relative h-32 w-32 flex items-center justify-center">
          {/* Circular progress SVG */}
          <svg className="absolute inset-0 transform -rotate-90" viewBox="0 0 100 100">
            <circle 
              cx="50" 
              cy="50" 
              r="45" 
              className="stroke-slate-100 dark:stroke-slate-800" 
              strokeWidth="4" 
              fill="transparent" 
            />
            <circle 
              cx="50" 
              cy="50" 
              r="45" 
              className={`${themeColors.progress} transition-all duration-300`} 
              strokeWidth="4.5" 
              fill="transparent" 
              strokeLinecap="round" 
              strokeDasharray="282.6" 
              strokeDashoffset={strokeDashoffset} 
            />
          </svg>

          {/* Core countdown numerical layout */}
          <div className="text-center z-10">
            <span className="text-2xl font-mono font-bold text-slate-800 dark:text-slate-100 tracking-tight block">
              {formatTime(timeLeft)}
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full capitalize font-semibold ${themeColors.bgLight} ${themeColors.accent}`}>
              {mode === 'work' ? (lang === 'hi' ? 'भौतिक' : 'Study') : (lang === 'hi' ? 'विश्राम' : 'Rest')}
            </span>
          </div>
        </div>

        {/* Adjust manual timings control triggers */}
        {!isPlaying && (
          <div className="mt-3 flex items-center space-x-1 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-805 px-2 py-1 rounded-lg">
            <span className="text-[9px] text-slate-400 font-bold tracking-tight uppercase mr-2">{labels.adjust}:</span>
            <button
              onClick={() => changeDuration(-5)}
              className="h-5 w-5 rounded bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-[10px] font-bold flex items-center justify-center transition-colors text-slate-700 dark:text-slate-300"
              title="-5 minutes"
            >
              -
            </button>
            <span className="text-[10px] px-1 font-bold text-slate-600 dark:text-slate-300">
              {Math.round(initialTime / 60)}m
            </span>
            <button
              onClick={() => changeDuration(5)}
              className="h-5 w-5 rounded bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-[10px] font-bold flex items-center justify-center transition-colors text-slate-700 dark:text-slate-300"
              title="+5 minutes"
            >
              +
            </button>
          </div>
        )}
      </div>

      {/* Main play controllers triggers layout */}
      <div className="flex items-center justify-center space-x-2">
        <button
          onClick={togglePlay}
          className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs transition-all duration-300 flex items-center justify-center gap-1 w-full text-slate-950 ${
            isPlaying 
              ? 'bg-rose-500 hover:bg-rose-600 hover:scale-101 text-white shadow-lg' 
              : mode === 'work' ? 'bg-amber-550 hover:bg-amber-600 hover:scale-101 shadow-lg shadow-amber-500/10'
              : mode === 'break' ? 'bg-emerald-500 hover:bg-emerald-600 hover:scale-101 shadow-md'
              : 'bg-blue-500 hover:bg-blue-600 hover:scale-101 shadow-md'
          }`}
        >
          {isPlaying ? (
            <>
              <Pause className="h-4.5 w-4.5 fill-current" />
              <span>{lang === 'hi' ? 'रोकें' : 'Pause'}</span>
            </>
          ) : (
            <>
              <Play className="h-4.5 w-4.5 fill-current" />
              <span>{lang === 'hi' ? 'प्रारंभ' : 'Start Focus'}</span>
            </>
          )}
        </button>

        <button
          onClick={resetTimer}
          className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 hover:bg-slate-100 dark:bg-slate-950 dark:hover:bg-slate-850 text-slate-500 hover:text-slate-800 dark:hover:text-amber-400 transition-all duration-300"
          title={labels.reset}
        >
          <RotateCcw className="h-4.5 w-4.5" />
        </button>
      </div>

      {/* Mini Motivational Line */}
      <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-850 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-1 opacity-10">
          <Sparkles className="h-8 w-8 text-amber-500" />
        </div>
        <span className="text-[9px] uppercase tracking-wider font-bold text-slate-400 block mb-1">
          {labels.motivation}
        </span>
        <p className="text-[10px] text-slate-600 dark:text-slate-300 italic leading-snug">
          "{quoteToShow}"
        </p>
      </div>

      {/* Focus statistics list */}
      <div className="p-3.5 bg-gradient-to-r from-slate-905 to-indigo-955 rounded-xl text-white border border-slate-800 shadow-sm flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Flame className="h-4.5 w-4.5 text-amber-400 animate-bounce" />
          <div>
            <span className="text-[8px] uppercase font-bold text-indigo-305 block">
              {labels.stats}
            </span>
            <span className="text-[10px] text-indigo-150 font-semibold block leading-tight">
              {completedSessions} {labels.sessionDone}
            </span>
          </div>
        </div>
        <div className="text-right">
          <span className="text-sm font-bold font-mono text-amber-400">
            {totalFocusMinutes}
          </span>
          <span className="text-[8px] text-slate-300 block -mt-1 font-medium">{labels.totalFocMins}</span>
        </div>
      </div>
    </div>
  );
}
