/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { StudyNote, UserProfile } from '../types';
import { SEED_NOTES } from '../data';
import { Search, Download, Bookmark, BookmarkCheck, FileText, Sparkles, Filter, ExternalLink } from 'lucide-react';
import { firebaseService } from '../firebaseService';
import FocusTimer from './FocusTimer';

interface NotesViewerProps {
  currentUser: UserProfile | null;
  onBookmarkChanged: (noteId: string, isBookmarked: boolean) => void;
  lang: 'en' | 'hi';
  initialSubjectFilter?: string; // Trigger from navigation subject clicks
  activeNoteId?: string | null;
}

export default function NotesViewer({ currentUser, onBookmarkChanged, lang, initialSubjectFilter, activeNoteId }: NotesViewerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState(initialSubjectFilter || 'All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activeNote, setActiveNote] = useState<StudyNote | null>(null);
  const [notesList, setNotesList] = useState<StudyNote[]>([]);
  const [loading, setLoading] = useState(true);

  // Load dynamic lists on mount
  useEffect(() => {
    const fetchDynamics = async () => {
      try {
        const dNotes = await firebaseService.getNotes();
        setNotesList(dNotes);
      } catch (err) {
        console.warn("Retrying direct SEED handouts.", err);
        setNotesList(SEED_NOTES);
      } finally {
        setLoading(false);
      }
    };
    fetchDynamics();
  }, []);

  // Sync active study note from search trigger
  useEffect(() => {
    if (activeNoteId && notesList.length > 0) {
      const match = notesList.find(n => n.id === activeNoteId);
      if (match) {
        setActiveNote(match);
      }
    }
  }, [activeNoteId, notesList]);

  useEffect(() => {
    if (initialSubjectFilter) {
      setSelectedSubject(initialSubjectFilter);
    }
  }, [initialSubjectFilter]);

  const subjects = ['All', 'Physics', 'Chemistry', 'Mathematics', 'Biology', 'History', 'Polity', 'Computer Knowledge'];
  const categories = ['All', 'Class 10', 'Class 11', 'Class 12', 'UPSC', 'JEE', 'NEET', 'Computer Courses'];

  const filteredNotes = notesList.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          note.chapter.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          note.contentMarkdown.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = selectedSubject === 'All' || note.subject === selectedSubject;
    const matchesCategory = selectedCategory === 'All' || note.category === selectedCategory;
    return matchesSearch && matchesSubject && matchesCategory;
  });

  const labels = {
    en: {
      searchPlaceholder: "Search chapter wise study sheets & handouts...",
      readBtn: "Study Handout",
      downloadPdf: "Download PDF Draft",
      subject: "Subject",
      level: "Academic Target",
      views: "readers study-guided",
      bookmark: "Add to Bookmarks",
      bookmarked: "Bookmarked Note",
      suggestAi: "Let PM Plus AI explain this chapter in full depth",
      noNotes: "No notes found matching current categories. Try changing the academic filter."
    },
    hi: {
      searchPlaceholder: "अध्यायवार अध्ययन पत्रक और नोट्स खोजें...",
      readBtn: "नोट्स पढ़ें",
      downloadPdf: "पीडीएफ डाउनलोड करें",
      subject: "विषय",
      level: "शैक्षणिक स्तर",
      views: "छात्रों द्वारा पढ़ा गया",
      bookmark: "बुकमार्क करें",
      bookmarked: "बुकमार्क किया गया",
      suggestAi: "पीएम प्लस एआई को यह अध्याय समझाने दें",
      noNotes: "इस श्रेणी में कोई नोट्स नहीं मिले। कृपया अन्य फ़िल्टर चुनें।"
    }
  }[lang];

  return (
    <div id="notes-viewer-root" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Filtering sidebar panel */}
      <div className="space-y-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-md space-y-4">
          <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Filter className="h-4.5 w-4.5 text-amber-500" />
            <span>Academic Handout Filters</span>
          </h4>

          {/* Subject list */}
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-widest block mb-2">{labels.subject}</label>
            <div className="flex flex-wrap gap-1.5">
              {subjects.map(s => (
                <button
                  key={s}
                  onClick={() => setSelectedSubject(s)}
                  className={`text-xs px-3 py-1.5 rounded-lg border font-medium transition-all ${
                    selectedSubject === s
                      ? 'bg-blue-950 text-white border-blue-950'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-blue-950'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Level selection */}
          <div className="pt-2">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-widest block mb-1.5">{labels.level}</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 focus:outline-none focus:ring-1 focus:ring-blue-900 text-slate-800 dark:text-slate-200"
            >
              {categories.map(c => (
                <option key={c} value={c}>{c === 'All' ? 'All Exam Categories' : c}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Selected Reading details preview */}
        {activeNote && (
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-5 space-y-3">
            <div className="flex items-center space-x-2">
              <Sparkles className="h-5 w-5 text-amber-500 shrink-0" />
              <h5 className="font-outfit font-semibold text-xs text-amber-800 dark:text-amber-400">PCM Plus AI Quick Study Tip:</h5>
            </div>
            <p className="text-xs text-slate-605 dark:text-slate-300 leading-relaxed italic">
              "Master this chapter's standard derivations first, then proceed to high-confidence numerical variables in the MCQ mock tests. Write complex formulas down thrice!"
            </p>
          </div>
        )}

        {/* Pomodoro Focus Study Timer */}
        <FocusTimer lang={lang} />
      </div>

      {/* Main Handout Display Container */}
      <div className="lg:col-span-2 space-y-4">
        {/* Search bar inside notes list */}
        <div className="relative">
          <Search className="absolute left-3.5 top-3.5 h-5 w-5 text-slate-400" />
          <input
            type="text"
            placeholder={labels.searchPlaceholder}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl py-3 pl-11 pr-4 text-sm text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-900"
          />
        </div>

        {activeNote ? (
          /* Active Markdown Reader Board */
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex justify-between items-center pb-4 border-b border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setActiveNote(null)}
                className="text-xs font-bold text-blue-900 dark:text-amber-400 hover:underline"
              >
                ← Back to Chapter Index
              </button>
              
              <div className="flex gap-2">
                {/* PDF Downloader Link */}
                {activeNote.pdfUrl && (
                  <a
                    href={activeNote.pdfUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-amber-500 hover:bg-amber-600 text-white text-[11px] px-3.5 py-1.5 rounded-lg font-bold flex items-center gap-1.5 shadow transition-colors"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>{labels.downloadPdf}</span>
                  </a>
                )}

                {/* Bookmark trigger */}
                {currentUser && (
                  <button
                    onClick={() => {
                      const isBookmarked = currentUser.bookmarks?.includes(activeNote.id) || false;
                      onBookmarkChanged(activeNote.id, !isBookmarked);
                    }}
                    className="p-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
                  >
                    {currentUser.bookmarks?.includes(activeNote.id) ? (
                      <BookmarkCheck className="h-4.5 w-4.5 text-amber-600" />
                    ) : (
                      <Bookmark className="h-4.5 w-4.5 text-slate-400" />
                    )}
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-amber-600 dark:text-amber-400">
                {activeNote.subject} • {activeNote.category}
              </span>
              <h3 className="text-xl font-outfit font-bold text-slate-900 dark:text-white leading-snug">
                {activeNote.title}
              </h3>
              <p className="text-xs text-slate-400">Chapter: {activeNote.chapter}</p>
            </div>

            {/* Note Markdown Content Rendering Render with graceful text wrapping style */}
            <div className="prose dark:prose-invert max-w-none text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-sans space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
              {activeNote.contentMarkdown.split('\n\n').map((paragraph, i) => {
                if (paragraph.startsWith('###')) {
                  return <h3 key={i} className="text-base font-outfit font-bold text-blue-950 dark:text-amber-400 mt-5 mb-2">{paragraph.replace('###', '')}</h3>;
                }
                if (paragraph.startsWith('####')) {
                  return <h4 key={i} className="text-sm font-outfit font-semibold text-slate-900 dark:text-slate-100 mt-4 mb-2">{paragraph.replace('####', '')}</h4>;
                }
                if (paragraph.startsWith('*') || paragraph.startsWith('-')) {
                  return (
                    <ul key={i} className="list-disc pl-5 my-2 space-y-1">
                      {paragraph.split('\n').map((item, idy) => (
                        <li key={idy} className="text-xs">{item.replace(/^[\s*-]+/, '')}</li>
                      ))}
                    </ul>
                  );
                }
                if (paragraph.startsWith('>') || paragraph.startsWith('$$')) {
                  return <blockquote key={i} className="border-l-4 border-amber-500 pl-4 py-1 bg-amber-500/5 my-3 italic text-slate-600 dark:text-slate-400">{paragraph.replace(/^[\s*>]+/, '')}</blockquote>;
                }
                return <p key={i} className="my-2">{paragraph}</p>;
              })}
            </div>
          </div>
        ) : (
          /* Grid Index List view */
          <div className="space-y-3">
            {filteredNotes.map(note => {
              const bookmarked = currentUser?.bookmarks?.includes(note.id) || false;

              return (
                <div
                  key={note.id}
                  id={`note-item-${note.id}`}
                  className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 rounded-xl flex items-center justify-between shadow-sm hover:shadow-md hover:border-amber-500/40 transition-all group"
                >
                  <div className="flex items-start space-x-3.5 min-w-0">
                    <div className="bg-amber-100 dark:bg-amber-950 p-2.5 rounded-xl border border-amber-200 dark:border-amber-900 shrink-0">
                      <FileText className="h-5 w-5 text-amber-700 dark:text-amber-500" />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] uppercase font-mono font-bold tracking-wider text-amber-600">
                          {note.subject}
                        </span>
                        <span className="text-[9px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-1.5 py-0.5 rounded">
                          {note.category}
                        </span>
                      </div>
                      <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mt-1 truncate group-hover:text-amber-500 transition-colors">
                        {note.title}
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">{labels.level}: {note.category} • Chapter: {note.chapter}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 shrink-0 ml-3">
                    <button
                      onClick={() => setActiveNote(note)}
                      className="text-[11px] text-blue-900 dark:text-amber-400 font-bold hover:underline"
                    >
                      {labels.readBtn}
                    </button>

                    {currentUser && (
                      <button
                        onClick={() => onBookmarkChanged(note.id, !bookmarked)}
                        className="p-1 hover:bg-slate-50 dark:hover:bg-slate-800 rounded"
                      >
                        {bookmarked ? (
                          <BookmarkCheck className="h-4.5 w-4.5 text-amber-600" />
                        ) : (
                          <Bookmark className="h-4.5 w-4.5 text-slate-300" />
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}

            {filteredNotes.length === 0 && (
              <div className="bg-white dark:bg-slate-900 text-center p-12 rounded-2xl max-w-sm mx-auto shadow border border-slate-100 dark:border-slate-800">
                <FileText className="h-10 w-10 text-slate-200 mx-auto mb-2" />
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium leading-relaxed">{labels.noNotes}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
