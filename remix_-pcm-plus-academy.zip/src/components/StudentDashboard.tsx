/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { UserProfile, StudyNote, MCQTest, TestResult } from '../types';
import { SEED_NOTES, SEED_TESTS } from '../data';
import { Award, BookOpen, Clock, FileText, CheckCircle2, Bookmark, BarChart3, GraduationCap, Printer, ExternalLink, Sparkles } from 'lucide-react';

interface StudentDashboardProps {
  currentUser: UserProfile;
  lang: 'en' | 'hi';
  onGoToTab: (tab: string, itemFilter?: string) => void;
}

export default function StudentDashboard({ currentUser, lang, onGoToTab }: StudentDashboardProps) {
  const [activeCertificationId, setActiveCertificationId] = useState<string | null>(null);

  // Sync saved bookmarks with full objects
  const bookmarkedObjects = (currentUser.bookmarks || [])
    .map(id => SEED_NOTES.find(n => n.id === id))
    .filter((n): n is StudyNote => !!n);

  // Sample static test scorecards as direct student logs
  const studentResults: TestResult[] = [
    {
      id: "res1",
      userId: currentUser.uid,
      userName: currentUser.name,
      testId: "test_jee_phys_1",
      testTitle: "JEE Electromagnetism & Field Theory - Practice Test 1",
      category: "JEE",
      score: 66,
      correctCount: 2,
      wrongCount: 1,
      totalQuestions: 3,
      takenAt: "2026-06-15T15:00:00Z"
    },
    {
      id: "res2",
      userId: currentUser.uid,
      userName: currentUser.name,
      testId: "test_comp_js_1",
      testTitle: "Computer Knowledge: JavaScript & Web Dev Basics",
      category: "Computer Courses",
      score: 100,
      correctCount: 1,
      wrongCount: 0,
      totalQuestions: 1,
      takenAt: "2026-06-16T08:30:00Z"
    }
  ];

  // Eligible certifications (scoring 100% on any category qualifies for a golden PCM Certificate!)
  const qualifiedCerts = studentResults.filter(r => r.score >= 80);

  const labels = {
    en: {
      profileHeader: "Student Performance Deck",
      scorecard: "Mock Scoring Analytics",
      progressTitle: "Course Syllabus Coverage Mode",
      bookmarks: "Your Fast-Reference Bookmarks",
      certificates: "Earned Academy Certificates",
      completedLec: "lectures studied",
      viewCertificate: "Inspect Certificate",
      printCert: "Download Certificate File",
      noCerts: "Complete any Mock Test in the Test Series with a score of 80% or higher to unlock Sushil Sir's signed certificate!",
      noBookmarks: "No bookmarks set yet. Explore Notes and add bookmarks for instant revision access."
    },
    hi: {
      profileHeader: "छात्र प्रदर्शन डैशबोर्ड",
      scorecard: "मॉक परीक्षा स्कोर विश्लेषण",
      progressTitle: "कोर्स पाठ्यक्रम कवरेज",
      bookmarks: "त्वरित अध्ययन बुकमार्क",
      certificates: "अर्जित अकादमी प्रमाण पत्र",
      completedLec: "लेक्चर पूरे किए",
      viewCertificate: "प्रमाण पत्र देखें",
      printCert: "प्रमाण पत्र डाउनलोड करें",
      noCerts: "सुशील सर द्वारा हस्ताक्षरित अकादमी प्रमाणपत्र प्राप्त करने के लिए किसी भी मॉक टेस्ट में 80% से अधिक स्कोर लाएं!",
      noBookmarks: "अभी तक कोई बुकमार्क सेट नहीं किया गया है। तुरंत रीविज़न के लिए नोट्स पर जाएं।"
    }
  }[lang];

  return (
    <div id="student-dashboard" className="space-y-6">
      <div className="flex items-center space-x-4 pb-4 border-b border-slate-150 dark:border-slate-800">
        <div className="bg-gradient-to-tr from-amber-500 to-amber-600 rounded-full h-12 w-12 flex items-center justify-center border-2 border-white shadow text-white font-bold font-outfit text-xl uppercase">
          {currentUser.name.charAt(0)}
        </div>
        <div>
          <h3 className="text-xl font-outfit font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>{currentUser.name}</span>
            <span className="text-xs font-bold uppercase tracking-wider bg-blue-950 text-amber-400 px-2 py-0.5 rounded border border-amber-400/30">
              {currentUser.role}
            </span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">{currentUser.email}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Course Coverage & Bookmark items columns */}
        <div className="lg:col-span-2 space-y-6">
          {/* Coverages progress panel */}
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-md">
            <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <BarChart3 className="h-4.5 w-4.5 text-amber-500" />
              <span>{labels.progressTitle}</span>
            </h4>

            {currentUser.progress && Object.keys(currentUser.progress).length > 0 ? (
              <div className="space-y-4">
                {Object.entries(currentUser.progress).map(([courseId, percent]) => (
                  <div key={courseId} className="space-y-1.5 text-xs">
                    <div className="flex justify-between items-center text-slate-700 dark:text-slate-300">
                      <span className="font-medium truncate max-w-[280px]">Course ID: {courseId.replace(/_/g, ' ')}</span>
                      <span className="font-mono font-bold text-amber-600">{percent}%</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-gradient-to-r from-blue-900 via-blue-950 to-amber-500 h-full rounded-full transition-all" style={{ width: `${percent}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 py-3 italic">
                {lang === 'hi' 
                  ? 'नामांकित पाठ्यक्रमों में सीखने की शुरुआत करें, आपकी प्रगति रेटिंग यहाँ प्रदर्शित होगी!' 
                  : 'Start studying in the Courses section to trace your academic coverage levels here!'}
              </p>
            )}
          </div>

          {/* Bookmarked hand-outs list */}
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-md">
            <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <Bookmark className="h-4.5 w-4.5 text-amber-500 font-bold" />
              <span>{labels.bookmarks}</span>
            </h4>

            {bookmarkedObjects.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {bookmarkedObjects.map(note => (
                  <div
                    key={note.id}
                    onClick={() => onGoToTab('notes', note.subject)}
                    className="p-3 border border-slate-105 rounded-xl hover:border-amber-500/40 cursor-pointer transition-colors bg-slate-50/50 dark:bg-slate-850 flex items-center justify-between group"
                  >
                    <div className="min-w-0 pr-2">
                      <span className="text-[9px] uppercase font-bold text-amber-600">{note.subject}</span>
                      <p className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate group-hover:text-amber-500 transition-colors">
                        {note.title}
                      </p>
                    </div>
                    <ExternalLink className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-xs text-slate-500 leading-relaxed font-sans">{labels.noBookmarks}</div>
            )}
          </div>

          {/* Test scores scoreboard history logs grid */}
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-md">
            <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <Award className="h-4.5 w-4.5 text-amber-500" />
              <span>{labels.scorecard}</span>
            </h4>

            <div className="space-y-3">
              {studentResults.map((res, i) => (
                <div key={i} className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-105 dark:border-slate-800 rounded-xl flex items-center justify-between text-xs">
                  <div className="min-w-0 pr-3">
                    <span className="text-[10px] bg-blue-900/10 text-blue-950 dark:bg-blue-950/40 dark:text-amber-400 px-2 py-0.2 rounded font-mono font-semibold uppercase">{res.category}</span>
                    <p className="font-semibold text-slate-900 dark:text-slate-200 mt-1 truncate">{res.testTitle}</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Taken on: {new Date(res.takenAt).toLocaleDateString()}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className={`text-sm font-bold block ${res.score >= 80 ? 'text-green-600' : 'text-amber-600'}`}>
                      {res.score}%
                    </span>
                    <span className="text-[10px] text-slate-400 font-semibold uppercase">Grade Rate</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Certificates column */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-lg">
            <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-amber-500" />
              <span>{labels.certificates}</span>
            </h4>

            {qualifiedCerts.length > 0 ? (
              <div className="space-y-3">
                {qualifiedCerts.map((cert, k) => (
                  <div key={k} className="p-4 bg-gradient-to-tr from-blue-950 to-indigo-950 text-white rounded-xl border border-amber-400/30 relative">
                    <div className="absolute right-3 top-3 opacity-10">
                      <GraduationCap className="h-12 w-12" />
                    </div>
                    
                    <span className="text-[9px] uppercase font-mono font-bold text-amber-400 tracking-widest block">PCM Academy Verified</span>
                    <h5 className="font-outfit font-bold text-xs mt-1 truncate">{cert.testTitle}</h5>
                    <p className="text-[10px] text-slate-300 mt-1">Conferred upon: {currentUser.name}</p>

                    <button
                      onClick={() => setActiveCertificationId(cert.id)}
                      className="mt-4 w-full bg-amber-500 hover:bg-amber-600 text-white font-bold text-[10px] uppercase tracking-wider py-1.5 rounded transition-all flex items-center justify-center gap-1 shadow-md"
                    >
                      <Printer className="h-3.5 w-3.5" />
                      <span>{labels.viewCertificate}</span>
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center p-4">
                <p className="text-xs text-slate-500 leading-relaxed font-sans">{labels.noCerts}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* PopUp visual printable certification framework */}
      {activeCertificationId && (() => {
        const matchingResult = qualifiedCerts.find(r => r.id === activeCertificationId);
        if (!matchingResult) return null;

        return (
          <div className="fixed inset-0 bg-black/70 backdrop-blur z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border-4 border-amber-500 select-none shadow-2xl max-w-xl w-full text-center relative font-sans space-y-6">
              <button
                onClick={() => setActiveCertificationId(null)}
                className="absolute right-4 top-4 text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>

              <div className="border-2 border-slate-100 dark:border-slate-800 p-6 space-y-4">
                <span className="text-amber-600 text-xs font-mono font-bold tracking-widest uppercase block">
                  PCM Plus Academy by Sushil Pandey
                </span>
                <span className="text-[10px] uppercase font-mono tracking-widest text-slate-400">
                  - Learn Today, Lead Tomorrow -
                </span>

                <div className="py-2">
                  <h3 className="text-2xl font-outfit font-bold text-blue-950">Certificate of Scholar Merit</h3>
                </div>

                <p className="text-xs text-slate-500">This certifies that elite student</p>
                <p className="text-lg font-outfit font-bold text-slate-900 dark:text-white underline">{currentUser.name}</p>
                <p className="text-xs text-slate-500">has successfully completed the assessment curriculum for</p>
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 uppercase">{matchingResult.testTitle}</p>
                
                <p className="text-xs text-slate-500">with a performance score of <strong className="text-amber-600">{matchingResult.score}%</strong></p>

                <div className="flex justify-between items-center pt-8 border-t border-slate-100 dark:border-slate-800/80">
                  <div className="text-left">
                    <p className="text-[9px] text-slate-400">Date Conferred</p>
                    <p className="text-[10px] font-semibold text-slate-700">{new Date(matchingResult.takenAt).toLocaleDateString()}</p>
                  </div>

                  <div className="text-center">
                    <p className="text-[11px] font-serif italic text-blue-900">Sushil Pandey</p>
                    <p className="text-[9px] uppercase tracking-wider text-slate-400">Academy Lead Signature</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => window.print()}
                  className="w-full bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs py-2.5 rounded-xl transition-colors shadow flex items-center justify-center gap-1"
                >
                  <Printer className="h-4 w-4" />
                  <span>{labels.printCert}</span>
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
