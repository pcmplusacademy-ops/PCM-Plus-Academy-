/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BlogArticle } from '../types';
import { SEED_BLOGS } from '../data';
import { BookOpen, Sparkles, User, Calendar, Tag, ChevronRight, GraduationCap } from 'lucide-react';

interface BlogSystemProps {
  lang: 'en' | 'hi';
  activeBlogId?: string | null;
}

export default function BlogSystem({ lang, activeBlogId }: BlogSystemProps) {
  const [activeBlog, setActiveBlog] = useState<BlogArticle | null>(null);

  // Focus specific blog post from click in header search
  React.useEffect(() => {
    if (activeBlogId) {
      const match = SEED_BLOGS.find(b => b.id === activeBlogId);
      if (match) {
        setActiveBlog(match);
      }
    }
  }, [activeBlogId]);

  const labels = {
    en: {
      headerTitle: "Academy Blog & Career Guidance",
      headerDesc: "Get direct, highly effective strategy worksheets from Sushil Pandey Sir on how to conquer competitive syllabi.",
      by: "Published by",
      readMore: "Read Strategy Sheet",
      tag: "Category Filter",
      back: "← Back to Blog Index",
      motivation: "Sushil Sir's Word of Courage:"
    },
    hi: {
      headerTitle: "अकादमी ब्लॉग और करियर मार्गदर्शन",
      headerDesc: "सुशील पांडेय सर से सीधे प्रतियोगी परीक्षाओं में सफलता प्राप्त करने के अचूक नुस्खे और रणनीतियां जाने।",
      by: "लेखक",
      readMore: "पूरी रणनीति पढ़ें",
      tag: "श्रेणी",
      back: "← ब्लॉग इंडेक्स पर वापस जाएं",
      motivation: "सुशील सर के प्रेरणा शब्द:"
    }
  }[lang];

  return (
    <div id="blog-system-root" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Editorial space */}
      <div className="lg:col-span-2 space-y-4">
        {activeBlog ? (
          /* Active full screen reader template */
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-6 rounded-2xl shadow-xl space-y-4">
            <button
              onClick={() => setActiveBlog(null)}
              className="text-xs font-bold text-blue-900 dark:text-amber-400 hover:underline"
            >
              {labels.back}
            </button>

            <div className="flex items-center space-x-1 mt-2">
              <span className="text-[10px] bg-amber-500/10 text-amber-600 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
                {activeBlog.category}
              </span>
            </div>

            <h3 className="text-xl font-outfit font-bold text-slate-900 dark:text-white leading-normal">
              {activeBlog.title}
            </h3>

            <div className="flex items-center space-x-4 text-xs text-slate-400 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-1">
                <User className="h-3.5 w-3.5 text-slate-400" />
                <span>By: {activeBlog.authorName}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" />
                <span>{new Date(activeBlog.createdAt).toLocaleDateString()}</span>
              </div>
            </div>

            {/* Content markup parsing block */}
            <div className="prose dark:prose-invert max-w-none text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-sans space-y-3 pt-3">
              {activeBlog.contentMarkdown.split('\n\n').map((para, idz) => {
                if (para.startsWith('###')) {
                  return <h3 key={idz} className="text-base font-outfit font-bold text-blue-950 dark:text-amber-400 mt-5 mb-2">{para.replace('###', '')}</h3>;
                }
                if (para.startsWith('####')) {
                  return <h4 key={idz} className="text-sm font-outfit font-semibold text-slate-900 dark:text-slate-100 mt-4 mb-2">{para.replace('####', '')}</h4>;
                }
                if (para.startsWith('*') || para.startsWith('-')) {
                  return (
                    <ul key={idz} className="list-disc pl-5 my-2 space-y-1">
                      {para.split('\n').map((li, idx2) => (
                        <li key={idx2} className="text-xs">{li.replace(/^[\s*-]+/, '')}</li>
                      ))}
                    </ul>
                  );
                }
                return <p key={idz} className="my-2">{para}</p>;
              })}
            </div>
          </div>
        ) : (
          /* Blog Grid Catalog */
          <div className="space-y-4">
            {SEED_BLOGS.map(blog => (
              <div
                key={blog.id}
                id={`blog-card-${blog.id}`}
                className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between group"
              >
                <div>
                  <div className="flex justify-between items-center text-xs text-slate-400 mb-2">
                    <span className="text-[10px] bg-blue-950/5 text-blue-900 font-bold px-2 py-0.5 rounded">
                      {blog.category}
                    </span>
                    <span>{new Date(blog.createdAt).toLocaleDateString()}</span>
                  </div>

                  <h4 className="text-sm font-outfit font-bold text-slate-900 dark:text-white group-hover:text-blue-950 dark:group-hover:text-amber-400 transition-colors">
                    {blog.title}
                  </h4>
                  
                  <p className="text-xs text-slate-500 mt-2 line-clamp-2">
                    {blog.contentMarkdown.replace(/[#*>\-\[\]`]/g, '').substring(0, 160)}...
                  </p>
                </div>

                <div className="mt-4 pt-3.5 border-t border-slate-50 dark:border-slate-800/80 flex justify-between items-center">
                  <span className="text-[10px] text-slate-400">{labels.by}: {blog.authorName}</span>
                  <button
                    onClick={() => setActiveBlog(blog)}
                    className="text-xs font-bold text-blue-900 dark:text-amber-400 hover:underline flex items-center gap-0.5"
                  >
                    <span>{labels.readMore}</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Inspirational Sidebar quoting Pandey Sir's thoughts! */}
      <div className="space-y-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-2xl shadow-lg space-y-4">
          <div className="flex items-center space-x-2">
            <Sparkles className="h-4.5 w-4.5 text-amber-500" />
            <span className="text-xs uppercase tracking-wider font-bold text-slate-800 dark:text-slate-200">{labels.motivation}</span>
          </div>

          <p className="text-xs italic text-slate-600 dark:text-slate-350 leading-relaxed font-sans bg-amber-500/5 p-4 rounded-xl border border-amber-500/20">
            "We build champions, not just scorers. Keep your focus on the basic core principles of standard Mathematics and Physics. Your analytical mind will pave paths for the rest of your life!"
          </p>

          <div className="flex items-center space-x-3 pt-2">
            <div className="h-10 w-10 bh-slate-100 rounded-full bg-blue-900 flex items-center justify-center border-2 border-amber-500 font-bold text-white text-xs">
              S P
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-slate-100">Sushil Pandey Sir</p>
              <p className="text-[10px] text-slate-400">Founder & Academic Lead</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
