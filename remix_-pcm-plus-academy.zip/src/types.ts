/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
  progress?: Record<string, number>; // courseId -> progress rate (0-100)
  bookmarks?: string[]; // bookmarked note IDs
  createdAt: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  subject: string;
  examType: string; // 'Class 10' | 'Class 11' | 'Class 12' | 'JEE' | 'NEET' | 'UPSC' | 'SSC' | 'Banking' | 'Railway' | 'Computer Courses'
  classLevel?: string;
  bannerUrl: string;
  videoUrl?: string; // Showcase video preview
  lectures: Lecture[];
  createdAt: string;
}

export interface Lecture {
  id: string;
  title: string;
  duration: string;
  youtubeId: string; // For real YouTube embedding!
}

export interface StudyNote {
  id: string;
  title: string;
  subject: string;
  category: string; // Course category
  chapter: string;
  contentMarkdown: string;
  pdfUrl?: string; // Standard PDF download link
  viewsCount: number;
}

export interface TestQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface MCQTest {
  id: string;
  title: string;
  subject: string;
  category: string;
  durationMinutes: number;
  questions: TestQuestion[];
}

export interface TestResult {
  id: string;
  userId: string;
  userName: string;
  testId: string;
  testTitle: string;
  category: string;
  score: number;
  correctCount: number;
  wrongCount: number;
  totalQuestions: number;
  takenAt: string;
}

export interface CurrentAffairsBulletin {
  id: string;
  title: string;
  content: string;
  type: 'daily' | 'weekly' | 'monthly';
  publishedAt: string;
}

export interface BlogArticle {
  id: string;
  title: string;
  contentMarkdown: string;
  authorName: string;
  category: string;
  createdAt: string;
}

export interface SupportChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}
